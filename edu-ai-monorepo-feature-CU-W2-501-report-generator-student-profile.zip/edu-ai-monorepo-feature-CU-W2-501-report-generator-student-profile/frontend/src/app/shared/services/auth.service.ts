import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { UserProfile, UserRole } from '../models/user.model';

/**
 * Temporary mock auth service.
 * TODO: Replace with the Auth0-backed service from core/ once wired up.
 * This service must NOT be used in production — it exists solely to
 * unblock RBAC navigation development during the scaffolding phase.
 */
@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly currentUser: UserProfile = {
    name: 'Demo User',
    email: 'demo@school.edu',
    role: 'counselor',
    avatarInitials: 'DU',
  };

  /** Returns the full profile of the authenticated user. */
  getCurrentUser(): Observable<UserProfile> {
    return of(this.currentUser);
  }

  /** Returns the role of the authenticated user synchronously. */
  getUserRole(): UserRole {
    return this.currentUser.role;
  }
}
