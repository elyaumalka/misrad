import { Injectable } from '@angular/core';
import { NavLink, UserRole } from '../models/user.model';

const ALL_NAV_LINKS: NavLink[] = [
  {
    label: 'Chatbot',
    route: '/chatbot',
    icon: '🤖',
    roles: ['teacher', 'admin', 'staff'],
  },
  {
    label: 'Dashboard',
    route: '/dashboard',
    icon: '📊',
    roles: ['teacher', 'admin'],
  },
  {
    label: 'Create Report',
    route: '/report-generator',
    icon: '📝',
    roles: ['teacher', 'admin'],
  },
  {
    label: 'Risk Report',
    route: '/risk-report',
    icon: '⚠️',
    roles: ['counselor', 'admin'],
  },
  {
    label: 'Student Profile',
    route: '/student-profile',
    icon: '👤',
    roles: ['counselor', 'admin'],
  },
];

@Injectable({ providedIn: 'root' })
export class NavigationService {
  /**
   * Returns the navigation links visible to a given role.
   * @param role - The authenticated user's role.
   */
  getLinksForRole(role: UserRole): NavLink[] {
    return ALL_NAV_LINKS.filter((link) => link.roles.includes(role));
  }
}
