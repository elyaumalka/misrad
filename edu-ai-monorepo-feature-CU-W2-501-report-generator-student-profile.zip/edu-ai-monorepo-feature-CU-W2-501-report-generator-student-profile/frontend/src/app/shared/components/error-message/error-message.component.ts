import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

/**
 * Displays a user-friendly error message.
 *
 * IMPORTANT: Only pass sanitized, human-readable text via `message`.
 * Never pass raw error objects, stack traces, HTTP error bodies, or
 * server log output — this component must never expose internal details.
 */
@Component({
  selector: 'app-error-message',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './error-message.component.html',
  styleUrl: './error-message.component.scss',
})
export class ErrorMessageComponent {
  /** A user-friendly error description. Must not contain technical details. */
  @Input({ required: true }) message!: string;

  /** Optional action label for a retry button. Omit to hide the button. */
  @Input() retryLabel = '';

  isVisible = true;

  /** Dismisses the error banner. */
  dismiss(): void {
    this.isVisible = false;
  }
}
