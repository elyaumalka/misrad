import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-kpi-card',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './kpi-card.component.html',
  styleUrl: './kpi-card.component.scss',
})
export class KpiCardComponent {
  /** The label describing the metric (e.g. "Total Reports"). */
  @Input({ required: true }) title!: string;

  /** The metric value to display (e.g. 15 or "98%"). */
  @Input({ required: true }) value!: string | number;

  /** Optional icon displayed above the value. */
  @Input() icon = '';
}
