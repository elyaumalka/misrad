export type UserRole = 'teacher' | 'counselor' | 'admin' | 'staff';

export interface UserProfile {
  name: string;
  email: string;
  role: UserRole;
  avatarInitials: string;
}

export interface NavLink {
  label: string;
  route: string;
  icon: string;
  roles: UserRole[];
}
