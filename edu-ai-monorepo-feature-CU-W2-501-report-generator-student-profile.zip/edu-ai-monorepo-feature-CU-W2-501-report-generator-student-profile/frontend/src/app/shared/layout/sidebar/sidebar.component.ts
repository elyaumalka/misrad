import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavigationComponent } from '../navigation/navigation.component';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, NavigationComponent],
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.scss',
})
export class SidebarComponent {
  isCollapsed = false;

  /** Toggles the sidebar between expanded and collapsed states. */
  toggleCollapse(): void {
    this.isCollapsed = !this.isCollapsed;
  }
}
