import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { NavigationComponent } from './navigation.component';
import { AuthService } from '../../services/auth.service';
import { NavigationService } from '../../services/navigation.service';
import { UserRole } from '../../models/user.model';

describe('NavigationComponent — RBAC', () => {
  let fixture: ComponentFixture<NavigationComponent>;

  function setup(role: UserRole): void {
    const mockAuthService = jasmine.createSpyObj<AuthService>('AuthService', [
      'getUserRole',
      'getCurrentUser',
    ]);
    mockAuthService.getUserRole.and.returnValue(role);

    TestBed.configureTestingModule({
      imports: [NavigationComponent],
      providers: [
        { provide: AuthService, useValue: mockAuthService },
        NavigationService,
        provideRouter([]),
      ],
    });

    fixture = TestBed.createComponent(NavigationComponent);
    fixture.detectChanges();
  }

  function getLinkLabels(): string[] {
    const elements: NodeListOf<Element> =
      fixture.nativeElement.querySelectorAll('[data-testid="nav-link"]');
    return Array.from(elements).map((el) =>
      (el.textContent ?? '').replace(/\s+/g, ' ').trim(),
    );
  }

  // ── staff ────────────────────────────────────────────────────────────────

  describe('staff role', () => {
    beforeEach(() => setup('staff'));

    it('should render exactly one link', () => {
      expect(getLinkLabels().length).toBe(1);
    });

    it('should render only the Chatbot link', () => {
      expect(getLinkLabels()[0]).toContain('Chatbot');
    });

    it('should NOT render Dashboard', () => {
      expect(getLinkLabels().some((l) => l.includes('Dashboard'))).toBeFalse();
    });

    it('should NOT render Student Profile', () => {
      expect(
        getLinkLabels().some((l) => l.includes('Student Profile')),
      ).toBeFalse();
    });
  });

  // ── teacher ───────────────────────────────────────────────────────────────

  describe('teacher role', () => {
    beforeEach(() => setup('teacher'));

    it('should render exactly three links', () => {
      expect(getLinkLabels().length).toBe(3);
    });

    it('should NOT render Student Profile', () => {
      expect(
        getLinkLabels().some((l) => l.includes('Student Profile')),
      ).toBeFalse();
    });

    it('should NOT render Risk Report', () => {
      expect(
        getLinkLabels().some((l) => l.includes('Risk Report')),
      ).toBeFalse();
    });

    it('should render Chatbot, Dashboard, and Create Report', () => {
      const labels = getLinkLabels();
      expect(labels.some((l) => l.includes('Chatbot'))).toBeTrue();
      expect(labels.some((l) => l.includes('Dashboard'))).toBeTrue();
      expect(labels.some((l) => l.includes('Create Report'))).toBeTrue();
    });
  });

  // ── counselor ─────────────────────────────────────────────────────────────

  describe('counselor role', () => {
    beforeEach(() => setup('counselor'));

    it('should render exactly two links', () => {
      expect(getLinkLabels().length).toBe(2);
    });

    it('should render Risk Report and Student Profile', () => {
      const labels = getLinkLabels();
      expect(labels.some((l) => l.includes('Risk Report'))).toBeTrue();
      expect(labels.some((l) => l.includes('Student Profile'))).toBeTrue();
    });

    it('should NOT render Dashboard', () => {
      expect(getLinkLabels().some((l) => l.includes('Dashboard'))).toBeFalse();
    });
  });

  // ── admin ─────────────────────────────────────────────────────────────────

  describe('admin role', () => {
    beforeEach(() => setup('admin'));

    it('should render all 5 links', () => {
      expect(getLinkLabels().length).toBe(5);
    });

    it('should include all navigation items', () => {
      const labels = getLinkLabels();
      expect(labels.some((l) => l.includes('Chatbot'))).toBeTrue();
      expect(labels.some((l) => l.includes('Dashboard'))).toBeTrue();
      expect(labels.some((l) => l.includes('Create Report'))).toBeTrue();
      expect(labels.some((l) => l.includes('Risk Report'))).toBeTrue();
      expect(labels.some((l) => l.includes('Student Profile'))).toBeTrue();
    });
  });
});
