import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { NavigationService } from '../../services/navigation.service';
import { NavLink } from '../../models/user.model';

@Component({
  selector: 'app-navigation',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  templateUrl: './navigation.component.html',
})
export class NavigationComponent implements OnInit {
  navLinks: NavLink[] = [];

  constructor(
    private readonly authService: AuthService,
    private readonly navigationService: NavigationService,
  ) {}

  ngOnInit(): void {
    const role = this.authService.getUserRole();
    this.navLinks = this.navigationService.getLinksForRole(role);
  }
}
