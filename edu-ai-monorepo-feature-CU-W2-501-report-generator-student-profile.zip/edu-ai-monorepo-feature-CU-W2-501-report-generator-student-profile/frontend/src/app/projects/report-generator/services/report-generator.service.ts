import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GenerateReportResponse, ReportRequest } from '../models/report-request.model';

export interface PdfSummaryResponse {
  bullets: string[];
}

const API_BASE = 'http://localhost:3000/report-generator';

@Injectable({ providedIn: 'root' })
export class ReportGeneratorService {
  constructor(private readonly http: HttpClient) {}

  /**
   * Sends a PDF file to the backend for text extraction and AI summarization.
   * Returns an observable of 3–5 Hebrew bullet points.
   */
  summarizePdf(file: File): Observable<PdfSummaryResponse> {
    const formData = new FormData();
    formData.append('file', file);
    return this.http.post<PdfSummaryResponse>(`${API_BASE}/summarize-pdf`, formData);
  }

  /**
   * Sends the complete report form data to the backend.
   * The backend selects a template-specific OpenAI prompt and returns a Hebrew draft.
   */
  generateReport(data: ReportRequest): Observable<GenerateReportResponse> {
    return this.http.post<GenerateReportResponse>(`${API_BASE}/generate`, data);
  }
}
