export type TemplateType = 'A' | 'B' | 'C' | 'D' | 'E';

export interface TemplateField {
  controlName: string;
  label: string;
  placeholder: string;
  rows: number;
}

export interface TemplateConfig {
  value: TemplateType;
  label: string;
  labelHe: string;
  /** Tone hint passed to future AI prompt logic. */
  tone: string;
  fields: TemplateField[];
}

export interface GenerateReportResponse {
  draft: string;
}

export interface ReportRequest {
  studentName: string;
  className: string;
  templateType: TemplateType;
  strengths: string;
  challenges: string;
  actionsTaken: string;
  narrative?: string;
  // Template A
  contactDetails?: string;
  academicSuccesses?: string;
  homeRecommendations?: string;
  // Template B
  gradeDetails?: string;
  socialFunctioning?: string;
  teamMeetingSummary?: string;
  // Template C
  learningBarriers?: string;
  unusualEvents?: string;
  referralReason?: string;
  // Template D
  specificAchievement?: string;
  teacherQuote?: string;
  excellenceField?: string;
  // Template E
  measurableGoals?: string;
  timelines?: string;
  incidentResponses?: string;
}
