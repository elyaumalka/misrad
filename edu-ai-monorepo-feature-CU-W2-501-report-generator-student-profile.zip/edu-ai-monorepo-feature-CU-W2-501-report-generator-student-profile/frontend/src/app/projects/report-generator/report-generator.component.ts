import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { HeaderComponent } from '../../shared/layout/header/header.component';
import { SidebarComponent } from '../../shared/layout/sidebar/sidebar.component';
import { LoadingSpinnerComponent } from '../../shared/components/loading-spinner/loading-spinner.component';
import { ErrorMessageComponent } from '../../shared/components/error-message/error-message.component';
import { ReportRequest, TemplateConfig, TemplateField, TemplateType } from './models/report-request.model';
import { ReportGeneratorService } from './services/report-generator.service';

const MAX_FILE_SIZE_MB = 5;
const MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024;
const MAX_TEXT_LENGTH = 1000;

const TEMPLATE_CONFIGS: Record<TemplateType, TemplateConfig> = {
  A: {
    value: 'A', label: 'תבנית א׳', labelHe: 'מכתב עדכון להורים', tone: 'רשמי ומלוטש',
    fields: [
      { controlName: 'contactDetails', label: 'פרטי התקשרות', placeholder: 'טלפון, אימייל ושעות זמינות...', rows: 3 },
      { controlName: 'academicSuccesses', label: 'הצלחות לימודיות', placeholder: 'תארו הצלחות בולטות בלימודים...', rows: 4 },
      { controlName: 'homeRecommendations', label: 'המלצות לבית', placeholder: 'המלצות להורים לתמיכה בבית...', rows: 4 },
    ],
  },
  B: {
    value: 'B', label: 'תבנית ב׳', labelHe: 'סיכום פדגוגי פנימי', tone: 'מקצועי ומפורט',
    fields: [
      { controlName: 'gradeDetails', label: 'פירוט ציונים', placeholder: 'פרטו את הציונים בכל מקצוע...', rows: 4 },
      { controlName: 'socialFunctioning', label: 'תפקוד חברתי', placeholder: 'תארו את התפקוד החברתי של התלמיד...', rows: 4 },
      { controlName: 'teamMeetingSummary', label: 'סיכום ישיבות צוות', placeholder: 'עיקרי הדיון בישיבות הצוות...', rows: 4 },
    ],
  },
  C: {
    value: 'C', label: 'תבנית ג׳', labelHe: 'הפניה ליועץ', tone: 'ענייני ודחוף',
    fields: [
      { controlName: 'learningBarriers', label: 'חסמים לימודיים', placeholder: 'תארו את החסמים המשפיעים על הלמידה...', rows: 4 },
      { controlName: 'unusualEvents', label: 'אירועים חריגים', placeholder: 'תארו אירועים חריגים רלוונטיים...', rows: 3 },
      { controlName: 'referralReason', label: 'סיבת ההפניה', placeholder: 'הסבירו מדוע נדרשת ההפניה ליועץ...', rows: 4 },
    ],
  },
  D: {
    value: 'D', label: 'תבנית ד׳', labelHe: 'מכתב הצטיינות', tone: 'חם ומעורר השראה',
    fields: [
      { controlName: 'specificAchievement', label: 'הישג ספציפי', placeholder: 'תארו את ההישג שבגינו ניתן המכתב...', rows: 4 },
      { controlName: 'teacherQuote', label: 'ציטוט מורה', placeholder: 'ציטוט מעורר השראה מהמורה על התלמיד...', rows: 3 },
      { controlName: 'excellenceField', label: 'תחום הצטיינות', placeholder: 'באיזה תחום התלמיד מצטיין?', rows: 2 },
    ],
  },
  E: {
    value: 'E', label: 'תבנית ה׳', labelHe: 'תוכנית התערבות התנהגותית', tone: 'מובנה ומעשי',
    fields: [
      { controlName: 'measurableGoals', label: 'יעדים מדידים', placeholder: 'פרטו את היעדים הניתנים למדידה...', rows: 4 },
      { controlName: 'timelines', label: 'לוחות זמנים', placeholder: 'הגדירו לוחות זמנים לכל יעד...', rows: 3 },
      { controlName: 'incidentResponses', label: 'דרכי תגובה לאירועים', placeholder: 'תארו כיצד יש להגיב לאירועים שונים...', rows: 4 },
    ],
  },
};

@Component({
  selector: 'app-report-generator',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    HeaderComponent,
    SidebarComponent,
    LoadingSpinnerComponent,
    ErrorMessageComponent,
  ],
  templateUrl: './report-generator.component.html',
  styleUrls: ['./report-generator.component.scss'],
})
export class ReportGeneratorComponent implements OnInit, OnDestroy {
  reportForm!: FormGroup;
  isLoading = false;
  errorMessage = '';
  selectedFile: File | null = null;
  fileError = '';
  pdfLoading = false;
  pdfError = '';
  currentTemplateFields: TemplateField[] = [];

  generatedDraft = '';
  draftCopied = false;

  readonly TEMPLATE_CONFIGS = TEMPLATE_CONFIGS;
  readonly TEMPLATE_KEYS = Object.keys(TEMPLATE_CONFIGS) as TemplateType[];

  private subscription = new Subscription();

  constructor(
    private fb: FormBuilder,
    private reportGeneratorService: ReportGeneratorService,
  ) {}

  ngOnInit(): void {
    this.initForm();
    this.listenToTemplateChanges();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  private initForm(): void {
    const textValidators = [
      Validators.required,
      Validators.maxLength(MAX_TEXT_LENGTH),
    ];
    this.reportForm = this.fb.group({
      studentName: ['', [Validators.required]],
      className: ['', [Validators.required]],
      templateType: ['' as TemplateType | '', [Validators.required]],
      strengths: ['', textValidators],
      challenges: ['', textValidators],
      actionsTaken: ['', textValidators],
      narrative: ['', [Validators.maxLength(MAX_TEXT_LENGTH)]],
    });
  }

  private listenToTemplateChanges(): void {
    const sub = this.reportForm.get('templateType')!.valueChanges.subscribe(
      (type: TemplateType | '') => this.applyTemplateFields(type)
    );
    this.subscription.add(sub);
  }

  private applyTemplateFields(type: TemplateType | ''): void {
    this.removeTemplateFields();
    if (!type || !TEMPLATE_CONFIGS[type]) {
      return;
    }
    const config = TEMPLATE_CONFIGS[type];
    for (const field of config.fields) {
      this.reportForm.addControl(
        field.controlName,
        this.fb.control('', [Validators.required, Validators.maxLength(MAX_TEXT_LENGTH)])
      );
    }
    this.currentTemplateFields = config.fields;
  }

  private removeTemplateFields(): void {
    for (const field of this.currentTemplateFields) {
      this.reportForm.removeControl(field.controlName);
    }
    this.currentTemplateFields = [];
  }

  /** Returns the config for the currently selected template, or null if none selected. */
  get selectedTemplateConfig(): TemplateConfig | null {
    const type = this.reportForm.get('templateType')?.value as TemplateType | '';
    return type ? TEMPLATE_CONFIGS[type] : null;
  }

  /** Returns true when the given control is touched and invalid. */
  isFieldInvalid(controlName: string): boolean {
    const control = this.reportForm.get(controlName);
    return !!(control?.invalid && control.touched);
  }

  /** Returns the current character count for a form control. */
  charCount(controlName: string): number {
    const value = this.reportForm.get(controlName)?.value as string;
    return value?.length ?? 0;
  }

  /** Validates the selected PDF, stores it, and triggers AI summarization. */
  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0] ?? null;
    this.fileError = '';
    this.pdfError = '';
    this.selectedFile = null;

    if (!file) {
      return;
    }
    if (file.type !== 'application/pdf') {
      this.fileError = 'ניתן לצרף קבצי PDF בלבד.';
      return;
    }
    if (file.size > MAX_FILE_SIZE_BYTES) {
      this.fileError = `הקובץ חורג ממגבלת ${MAX_FILE_SIZE_MB} MB.`;
      return;
    }
    this.selectedFile = file;
    this.summarizePdf(file);
  }

  /** Sends the PDF to the backend and populates the narrative field with bullet points. */
  private summarizePdf(file: File): void {
    this.pdfLoading = true;
    this.pdfError = '';
    this.reportForm.get('narrative')?.setValue('');

    const sub = this.reportGeneratorService.summarizePdf(file).subscribe({
      next: (res) => {
        this.reportForm.get('narrative')?.setValue(res.bullets.join('\n'));
        this.pdfLoading = false;
      },
      error: () => {
        this.pdfError = 'שגיאה בעיבוד המסמך. ניתן למלא את הנרטיב ידנית.';
        this.pdfLoading = false;
      },
    });
    this.subscription.add(sub);
  }

  /** Clears the currently selected file and narrative. */
  clearFile(): void {
    this.selectedFile = null;
    this.fileError = '';
    this.pdfError = '';
    this.reportForm.get('narrative')?.setValue('');
  }

  /** Marks all fields touched to surface validation errors, then submits if valid. */
  onSubmit(): void {
    if (this.reportForm.invalid) {
      this.reportForm.markAllAsTouched();
      return;
    }
    this.isLoading = true;
    this.errorMessage = '';
    this.generatedDraft = '';

    const payload: ReportRequest = this.reportForm.value as ReportRequest;
    const sub = this.reportGeneratorService.generateReport(payload).subscribe({
      next: (res) => {
        this.generatedDraft = res.draft;
        this.isLoading = false;
      },
      error: () => {
        this.errorMessage = 'שגיאה בייצור הדוח. אנא נסו שוב.';
        this.isLoading = false;
      },
    });
    this.subscription.add(sub);
  }

  /** Copies the generated draft to the clipboard. */
  copyDraft(): void {
    navigator.clipboard.writeText(this.generatedDraft).then(() => {
      this.draftCopied = true;
      setTimeout(() => { this.draftCopied = false; }, 2000);
    });
  }

  /**
   * Exports the draft as a .doc file (HTML-encoded, openable by Microsoft Word).
   * Note: the docx npm library is not yet installed — using an HTML-as-doc approach
   * as a drop-in. Bring the docx library request to the project lead for a richer export.
   */
  exportToWord(): void {
    const templateLabel = this.selectedTemplateConfig?.labelHe ?? 'דוח';
    const htmlContent =
      `<html><head><meta charset="UTF-8"></head>` +
      `<body dir="rtl" style="font-family:Arial,sans-serif;font-size:12pt;line-height:1.8;">` +
      `<h2>${templateLabel}</h2>` +
      this.generatedDraft
        .split('\n')
        .map((line) => `<p>${line}</p>`)
        .join('') +
      `</body></html>`;

    const blob = new Blob([htmlContent], { type: 'application/msword' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `${templateLabel}.doc`;
    anchor.click();
    URL.revokeObjectURL(url);
  }

  /** Resets the form and all component state. */
  onReset(): void {
    this.removeTemplateFields();
    this.reportForm.reset();
    this.selectedFile = null;
    this.fileError = '';
    this.pdfError = '';
    this.pdfLoading = false;
    this.errorMessage = '';
    this.isLoading = false;
    this.generatedDraft = '';
    this.draftCopied = false;
  }
}
