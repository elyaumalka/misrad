# Branch Changes — `feature/report-generator-student-profile`

**Branch:** `feature/report-generator-student-profile`
**Date:** 2026-03-19
**Scope:** Frontend shared infrastructure + API contract documentation

---

## What Was Done

This branch lays the **shared UI foundation** required by the Report Generator (Project 4)
and Student Profile (Project 5) features, plus a complete API contract document for both modules.

> **Backend note:** No backend code was changed in this branch.
> The backend controllers and services remain as the original scaffold.

---

## 1. New File — `docs/api-contracts.md`

A full API contract document defining the interface between Frontend and Backend for both modules.

**What it covers:**
- Authentication scheme (Auth0 Bearer JWT)
- RBAC table — which roles can access which endpoints
- Full TypeScript data models (`ReportRequest`, `ReportResponse`, `StudentProfileResponse`, `ApiErrorResponse`)
- Endpoint specifications with request/response examples and all error codes
- PDF handling policy (in-memory only, immediate buffer purge, never written to disk)
- Error response standard (no stack traces, no raw ORM errors, consistent envelope shape)

**Who should read it:** Every developer working on Project 4 or Project 5, both frontend and backend.

---

## 2. New Shared Components

All three components live in `frontend/src/app/shared/components/` and are **standalone Angular components**.

### `KpiCardComponent` — `shared/components/kpi-card/`

Displays a single metric card with an optional icon, a title, and a value.

| Input | Type | Required | Description |
|-------|------|----------|-------------|
| `title` | `string` | Yes | Label for the metric (e.g. "Total Reports") |
| `value` | `string \| number` | Yes | The metric value (e.g. 15 or "98%") |
| `icon` | `string` | No | Emoji or icon shown above the value |

**Usage:**
```html
<app-kpi-card icon="📝" title="Total Reports" value="15"></app-kpi-card>
```

---

### `LoadingSpinnerComponent` — `shared/components/loading-spinner/`

Displays an animated spinner with an optional status message below it.

| Input | Type | Required | Description |
|-------|------|----------|-------------|
| `message` | `string` | No | Text shown below the spinner (default: "Processing, please wait…") |

**Usage:**
```html
<app-loading-spinner message="Generating AI report, please wait…"></app-loading-spinner>
```

---

### `ErrorMessageComponent` — `shared/components/error-message/`

Displays a user-friendly error banner. Has a dismiss button always and an optional retry button.

> **Important:** Only pass sanitized human-readable text via `message`.
> Never pass raw error objects, stack traces, or HTTP error bodies.

| Input | Type | Required | Description |
|-------|------|----------|-------------|
| `message` | `string` | Yes | User-friendly error text |
| `retryLabel` | `string` | No | Label for the retry button — omit to hide the button |

**Usage:**
```html
<app-error-message
  message="We could not generate the report. Please try again later."
  retryLabel="Try Again"
></app-error-message>
```

---

## 3. New Shared Layout Components

Located in `frontend/src/app/shared/layout/`.

### `HeaderComponent` — `shared/layout/header/`

Application top bar. Fetches the current user profile via `AuthService` on init and displays it.
Depends on: `AuthService`, `UserProfile`.

### `SidebarComponent` — `shared/layout/sidebar/`

Collapsible left sidebar. Contains `NavigationComponent` inside it.
Has a `toggleCollapse()` method and an `isCollapsed` state property.

### `NavigationComponent` — `shared/layout/navigation/`

Renders the navigation links for the sidebar.
Reads the user role and filters links through `NavigationService`.

---

## 4. New Shared Services

Located in `frontend/src/app/shared/services/`.

### `AuthService` — `auth.service.ts`

> **This is a temporary mock — it must be replaced with the Auth0-backed service from `core/` before any real feature is merged.**

Provides two methods:
- `getCurrentUser(): Observable<UserProfile>` — returns the current user profile as an observable
- `getUserRole(): UserRole` — returns the user's role synchronously

The mock returns a hardcoded `counselor` role user named "Demo User" so that RBAC navigation can be developed and tested before Auth0 is wired up.

### `NavigationService` — `navigation.service.ts`

Provides role-based navigation link filtering:
- `getLinksForRole(role: UserRole): NavLink[]` — returns only the links the given role is allowed to see

**RBAC nav link matrix:**

| Link | `teacher` | `counselor` | `admin` | `staff` |
|------|:---------:|:-----------:|:-------:|:-------:|
| Chatbot | ✅ | ❌ | ✅ | ✅ |
| Dashboard | ✅ | ❌ | ✅ | ❌ |
| Create Report | ✅ | ❌ | ✅ | ❌ |
| Risk Report | ❌ | ✅ | ✅ | ❌ |
| Student Profile | ❌ | ✅ | ✅ | ❌ |

> **Note:** Frontend navigation filtering is client-side only and is not a security measure.
> The backend guard is the authoritative access control layer.

---

## 5. New Shared Model — `user.model.ts`

Located in `frontend/src/app/shared/models/`.

Defines three exported types used across the shared layer:

```typescript
type UserRole = 'teacher' | 'counselor' | 'admin' | 'staff';

interface UserProfile {
  name: string;
  email: string;
  role: UserRole;
  avatarInitials: string;
}

interface NavLink {
  label: string;
  route: string;
  icon: string;
  roles: UserRole[];
}
```

---

## 6. Modified Files

### `shared/services/index.ts`
Added barrel exports for the two new services:
```typescript
export * from './auth.service';
export * from './navigation.service';
```

### `home/home.component.ts`
Updated to use `SystemStatusService` to display the last sync time and status on the home screen.
Also updated the `navCards` array to include all 5 projects with their correct routes.

### `projects/report-generator/report-generator.component.ts` + `.html`
**Temporary showcase page** — this is NOT the final implementation.
The component currently renders `HeaderComponent`, `SidebarComponent`, `KpiCardComponent`,
`LoadingSpinnerComponent`, and `ErrorMessageComponent` together so the team can visually
verify the shared components render correctly before the real form is built.
The comment `// TODO: Temporary showcase — remove once AppShellComponent is integrated` marks it clearly.

---

## How to Test

1. Run the frontend: `cd frontend && ng serve --host 0.0.0.0`
2. Open `http://localhost:4200`
3. Navigate to **Create Report** (`/report-generator`) to see the shared component showcase
4. Check that the sidebar, header, KPI cards, loading spinner, and error message all render correctly
5. Review `docs/api-contracts.md` and confirm it matches your understanding of the feature

---

## Notes for Reviewers

- The `AuthService` in `shared/services/` is a **mock only** — it must not be used in production and must be replaced before the project is considered done
- The backend scaffold files (`report-generator.controller.ts`, `student-profile.controller.ts`, etc.) were **not changed** — they remain as the original empty scaffold
- The `docs/api-contracts.md` is the single source of truth for the API — any deviations in implementation must go through a change request first
