# API Contract Documentation
## Report Generator & Student Profile Modules

| Field         | Value                                              |
|---------------|----------------------------------------------------|
| Module        | `CU-W1-501` — Report Generator & Student Profile   |
| Version       | 1.0.0                                              |
| Status        | Draft — pending backend review                     |
| Last Updated  | 2026-03-18                                         |
| Architecture  | Stateless — no student data is persisted per request |
| Auth Scheme   | Bearer JWT issued by Auth0                         |

> This document is the single source of truth for both Frontend and Backend developers.
> Any deviation from this contract must go through a formal change request.

---

## Table of Contents

1. [Authentication](#1-authentication)
2. [RBAC — Role-Based Access Control](#2-rbac--role-based-access-control)
3. [Data Models](#3-data-models)
4. [Endpoints](#4-endpoints)
   - [POST /api/reports/generate](#41-post-apireportsgenerate)
   - [GET /api/students/{id}/profile](#42-get-apistudentsidprofile)
5. [Security & Data Privacy Policy](#5-security--data-privacy-policy)
6. [Error Response Standard](#6-error-response-standard)

---

## 1. Authentication

All endpoints require a valid JWT in the `Authorization` header:

```
Authorization: Bearer <token>
```

- Tokens are issued exclusively by Auth0.
- A missing or expired token returns `401 Unauthorized` before any business logic runs.
- The JWT payload must include a `role` claim matching one of: `admin`, `teacher`, `counselor`, `staff`.

---

## 2. RBAC — Role-Based Access Control

### Endpoint Access Matrix

| Endpoint                        | `admin` | `teacher` | `counselor` | `staff` |
|---------------------------------|:-------:|:---------:|:-----------:|:-------:|
| `POST /api/reports/generate`    | ✅      | ✅        | ✅          | ❌      |
| `GET /api/students/{id}/profile`| ✅      | ❌        | ✅ *        | ❌      |

> \* `counselor` can only access profiles of students assigned to them.

### Feature Access by Role

| Feature                  | `admin` | `teacher` | `counselor` | `staff` |
|--------------------------|:-------:|:---------:|:-----------:|:-------:|
| Chatbot                  | ✅      | ✅        | ✅          | ✅      |
| Dashboard                | ✅      | ✅        | ❌          | ❌      |
| Create Report            | ✅      | ✅        | ✅          | ❌      |
| Risk Report              | ✅      | ❌        | ✅          | ❌      |
| Student Profile          | ✅      | ❌        | ✅ *        | ❌      |

### Enforcement Layers

Access control is enforced at **two independent layers**. Both must be in place:

1. **Backend Guard** — `@Roles(...)` decorator on the NestJS controller method.
   The guard validates the JWT `role` claim and rejects unauthorized requests
   with `403` before any service or database call is made.

2. **Frontend Navigation** — `NavigationService.getLinksForRole(role)` filters
   visible routes client-side. An unauthorized user will not see the link, but
   this alone is not sufficient security — the backend guard is authoritative.

---

## 3. Data Models

### 3.1 Report Request

```typescript
/**
 * Payload sent to POST /api/reports/generate.
 * Content-Type: multipart/form-data
 */
interface ReportRequest {
  /** Anonymized student token — never a real name or national ID. */
  studentId: string;

  /** One of the five approved report templates. */
  templateType: 'A' | 'B' | 'C' | 'D' | 'E';

  /** Observed academic and behavioral strengths (1–1000 chars). */
  strengths: string;

  /** Observed academic and behavioral challenges (1–1000 chars). */
  challenges: string;

  /** Recommended follow-up actions (1–1000 chars). */
  actionsTaken: string;

  /**
   * Optional supplementary PDF (max 5 MB).
   * Processed in memory only — never written to disk.
   * Purged immediately after AI summary is generated.
   */
  pdfFile?: File;
}
```

### 3.2 Report Response

```typescript
/**
 * Response from POST /api/reports/generate.
 */
interface ReportResponse {
  /** UUID v4 identifier for the generated report. */
  reportId: string;

  /** Template used for this report. */
  templateType: 'A' | 'B' | 'C' | 'D' | 'E';

  /**
   * AI-generated summary — 3 to 5 key points derived from the
   * form data and (if provided) the PDF content.
   */
  aiDraft: {
    summary: [string, string, string, ...string[]]; // min 3, max 5
    suggestedTitle: string;
    tone: 'supportive' | 'neutral' | 'urgent';
  };

  /** ISO 8601 timestamp of generation. */
  generatedAt: string;
}
```

### 3.3 Student Profile Response

```typescript
/**
 * Response from GET /api/students/{id}/profile.
 */
interface StudentProfileResponse {
  /** Anonymized student token. */
  studentId: string;

  /** Computed risk classification. */
  riskLevel: 'low' | 'medium' | 'high';

  /** Attendance percentage (0–100). */
  attendanceRate: number;

  /** Weighted grade average (0–100). */
  gradeAverage: number;

  /** Up to 5 most recent reports for this student. */
  recentReports: Array<{
    reportId: string;
    templateType: 'A' | 'B' | 'C' | 'D' | 'E';
    createdAt: string;
    summary: string[];
  }>;

  /**
   * AI-generated insights. May be null if the AI service is unavailable —
   * the endpoint must degrade gracefully and never return 500 for this alone.
   */
  aiInsights: {
    trends: string[];
    recommendations: string[];
    focusAreas: string[];
  } | null;
}
```

### 3.4 API Error Response

```typescript
/**
 * Standard error envelope returned on all 4xx / 5xx responses.
 * Stack traces, ORM errors, and raw exception messages are NEVER included.
 */
interface ApiErrorResponse {
  statusCode: number;
  /** User-friendly message safe to display in the UI. */
  message: string;
  /** Machine-readable error code for frontend error handling logic. */
  errorCode: string;
  /** ISO 8601 timestamp. */
  timestamp: string;
}
```

**Example:**
```json
{
  "statusCode": 403,
  "message": "You do not have permission to access this resource.",
  "errorCode": "FORBIDDEN_ROLE",
  "timestamp": "2026-03-18T10:00:00.000Z"
}
```

---

## 4. Endpoints

### 4.1 POST /api/reports/generate

#### Purpose

Generates one of the five report types (A–E) based on structured educator input
and optional PDF context, using AI to produce a draft report with 3–5 key points.
Each request is fully self-contained (stateless architecture).

#### Authorization

| Role        | Access        |
|-------------|---------------|
| `admin`     | ✅ Allowed    |
| `teacher`   | ✅ Allowed    |
| `counselor` | ✅ Allowed    |
| `staff`     | ❌ 403 Forbidden |

#### Request

**Method:** `POST`
**URL:** `/api/reports/generate`
**Content-Type:** `multipart/form-data`

| Field          | Type     | Required | Constraints                       | Description                           |
|----------------|----------|----------|-----------------------------------|---------------------------------------|
| `studentId`    | `string` | Yes      | Anonymized token, non-empty       | Subject student identifier            |
| `templateType` | `string` | Yes      | `A` \| `B` \| `C` \| `D` \| `E`  | Report template                       |
| `strengths`    | `string` | Yes      | 1–1000 characters                 | Observed student strengths            |
| `challenges`   | `string` | Yes      | 1–1000 characters                 | Observed student challenges           |
| `actionsTaken` | `string` | Yes      | 1–1000 characters                 | Recommended follow-up actions         |
| `pdfFile`      | `file`   | No       | `application/pdf`, max 5 MB       | Supplementary document for AI context |

#### Response — 200 OK

```json
{
  "reportId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "templateType": "B",
  "aiDraft": {
    "summary": [
      "Student demonstrates strong verbal participation in class.",
      "Written assignments show inconsistent quality week over week.",
      "Peer collaboration skills are notably above grade average."
    ],
    "suggestedTitle": "Progress Report — Term 2",
    "tone": "supportive"
  },
  "generatedAt": "2026-03-18T10:00:00.000Z"
}
```

#### Error Responses

| Code | `errorCode`           | Reason                                             |
|------|-----------------------|----------------------------------------------------|
| 400  | `VALIDATION_ERROR`    | Missing required fields or invalid `templateType`  |
| 401  | `UNAUTHENTICATED`     | Missing or expired JWT                             |
| 403  | `FORBIDDEN_ROLE`      | `staff` role attempted access                      |
| 413  | `PDF_TOO_LARGE`       | PDF exceeds the 5 MB limit                         |
| 422  | `PDF_PARSE_ERROR`     | PDF is corrupt, empty, or password-protected       |
| 500  | `INTERNAL_ERROR`      | Unexpected server error — generic message only     |

---

### 4.2 GET /api/students/{id}/profile

#### Purpose

Fetches the comprehensive academic and emotional profile for a single student,
including risk classification, attendance, grades, recent reports, and
AI-generated trend insights.

#### Authorization — Restricted

> **ONLY `counselor` and `admin` roles may call this endpoint.**
> `teacher` and `staff` receive `403 Forbidden` unconditionally.

| Role        | Access                                       |
|-------------|----------------------------------------------|
| `admin`     | ✅ Allowed — all students                    |
| `counselor` | ✅ Allowed — assigned students only          |
| `teacher`   | ❌ 403 Forbidden                             |
| `staff`     | ❌ 403 Forbidden                             |

#### Request

**Method:** `GET`
**URL:** `/api/students/{id}/profile`
**Content-Type:** N/A

| Parameter | Location   | Type     | Required | Description                   |
|-----------|------------|----------|----------|-------------------------------|
| `id`      | Path       | `string` | Yes      | Anonymized student identifier |

#### Response — 200 OK

```json
{
  "studentId": "stu_token_7f3a9b",
  "riskLevel": "medium",
  "attendanceRate": 87.5,
  "gradeAverage": 74.2,
  "recentReports": [
    {
      "reportId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
      "templateType": "B",
      "createdAt": "2026-03-10T08:30:00.000Z",
      "summary": [
        "Verbal participation is strong.",
        "Written output needs structured support."
      ]
    }
  ],
  "aiInsights": {
    "trends": [
      "Attendance rate improved by 12% over the last 4 weeks."
    ],
    "recommendations": [
      "Schedule a follow-up meeting with the student's parents.",
      "Consider additional support sessions for written assignments."
    ],
    "focusAreas": ["Written expression", "Time management"]
  }
}
```

> `aiInsights` may be `null` if the AI service is temporarily unavailable.
> The endpoint must still return `200` with the remaining data.

#### Error Responses

| Code | `errorCode`        | Reason                                                    |
|------|--------------------|-----------------------------------------------------------|
| 401  | `UNAUTHENTICATED`  | Missing or expired JWT                                    |
| 403  | `FORBIDDEN_ROLE`   | `teacher` or `staff` attempted access                     |
| 404  | `NOT_FOUND`        | Student not found or caller not authorized (see note)     |
| 500  | `INTERNAL_ERROR`   | Unexpected server error — generic message only            |

> **Security Note on 404:** The server returns `404` for both "student does not
> exist" and "student exists but the counselor is not assigned to them."
> This prevents unauthorized users from enumerating valid student IDs.

---

## 5. Security & Data Privacy Policy

### 5.1 PDF Handling — Immediate Deletion Policy

> This section is **mandatory** for all backend developers implementing
> `POST /api/reports/generate`.

The uploaded PDF is **private pedagogical material** and is subject to the
following strict handling rules:

| Rule | Requirement |
|------|-------------|
| **No disk writes** | The file buffer must never be written to the filesystem at any point, including temporary directories. |
| **In-memory only** | All processing happens within the memory scope of a single HTTP request lifecycle. |
| **Immediate purge** | As soon as the AI service returns the summary, all references to the file buffer must be explicitly set to `null` and dereferenced. |
| **Finally block** | Buffer release must occur in a `finally` block to guarantee execution even if the AI call throws an error. |
| **No forwarding** | The buffer must never be passed to logging, monitoring, analytics, or caching layers. |
| **No persistence** | The PDF content must never be stored in a database, object storage (GCS/S3), or any cache. |

**Backend implementation pattern:**

```typescript
async generateReport(dto: ReportRequestDto, pdfBuffer?: Buffer): Promise<ReportResponse> {
  let buffer: Buffer | null = pdfBuffer ?? null;
  try {
    const pdfContext = buffer ? await this.pdfService.extractText(buffer) : null;
    return await this.aiService.generateDraft(dto, pdfContext);
  } finally {
    buffer = null; // Purge immediately — regardless of success or failure
  }
}
```

### 5.2 Stateless Architecture

- The server holds no student data in memory between requests.
- Each request must be fully self-contained with all required context.
- No server-side sessions, no request-scoped caches persisted beyond the response.

### 5.3 PII (Personally Identifiable Information)

- `studentId` must always be an anonymized token — never a real name, national ID, or email.
- No student identifiers may appear in server logs at any log level.
- The AI service must never receive raw PII — only anonymized tokens and textual observations.

### 5.4 Role Enforcement

- Role validation happens at the **NestJS guard level**, before any service method is called.
- Guards must read the role from the validated JWT claim — never from a request body parameter.
- Frontend-only access control (hiding links) is **not** considered sufficient security.

---

## 6. Error Response Standard

All `4xx` and `5xx` responses follow the `ApiErrorResponse` schema defined in
[Section 3.4](#34-api-error-response).

### Rules for All Error Responses

| Rule | Detail |
|------|--------|
| **No stack traces** | Exception stack traces must never appear in any API response. |
| **No ORM errors** | Raw TypeORM / Prisma error messages must never be forwarded to the client. |
| **No field echoing** | Error responses must never repeat back the values submitted in the request. |
| **No student data** | Error messages must not contain any student identifiers or profile data. |
| **Generic 500s** | All unhandled exceptions return a single generic message: `"An unexpected error occurred. Please try again later."` |
| **Consistent shape** | Every error — regardless of origin — uses the `ApiErrorResponse` envelope. |

### Frontend Contract

The frontend (`ErrorMessageComponent`) must display only the `message` field
from the error response. It must never render `statusCode`, `errorCode`,
`timestamp`, or any other field directly to the end user.
