import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ReportGeneratorModule } from './modules/report-generator/report-generator.module'; // ← add

@Module({
  imports: [ReportGeneratorModule],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
