import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsIn, IsNotEmpty, IsOptional, IsString, MaxLength } from 'class-validator';

const TEMPLATE_TYPES = ['A', 'B', 'C', 'D', 'E'] as const;
export type TemplateType = (typeof TEMPLATE_TYPES)[number];

const MAX_FIELD_LENGTH = 1000;

export class GenerateReportDto {
  @ApiProperty({ description: 'Student name' })
  @IsString()
  @IsNotEmpty()
  studentName!: string;

  @ApiProperty({ description: 'Class name' })
  @IsString()
  @IsNotEmpty()
  className!: string;

  @ApiProperty({ enum: TEMPLATE_TYPES, description: 'Report template type (A–E)' })
  @IsIn(TEMPLATE_TYPES)
  templateType!: TemplateType;

  @ApiProperty({ description: "Student's strengths" })
  @IsString()
  @IsNotEmpty()
  @MaxLength(MAX_FIELD_LENGTH)
  strengths!: string;

  @ApiProperty({ description: "Student's challenges" })
  @IsString()
  @IsNotEmpty()
  @MaxLength(MAX_FIELD_LENGTH)
  challenges!: string;

  @ApiProperty({ description: 'Actions taken so far' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(MAX_FIELD_LENGTH)
  actionsTaken!: string;

  @ApiPropertyOptional({ description: 'AI-generated narrative from uploaded PDF' })
  @IsOptional()
  @IsString()
  @MaxLength(MAX_FIELD_LENGTH)
  narrative?: string;

  // Template A
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(MAX_FIELD_LENGTH) contactDetails?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(MAX_FIELD_LENGTH) academicSuccesses?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(MAX_FIELD_LENGTH) homeRecommendations?: string;

  // Template B
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(MAX_FIELD_LENGTH) gradeDetails?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(MAX_FIELD_LENGTH) socialFunctioning?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(MAX_FIELD_LENGTH) teamMeetingSummary?: string;

  // Template C
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(MAX_FIELD_LENGTH) learningBarriers?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(MAX_FIELD_LENGTH) unusualEvents?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(MAX_FIELD_LENGTH) referralReason?: string;

  // Template D
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(MAX_FIELD_LENGTH) specificAchievement?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(MAX_FIELD_LENGTH) teacherQuote?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(MAX_FIELD_LENGTH) excellenceField?: string;

  // Template E
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(MAX_FIELD_LENGTH) measurableGoals?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(MAX_FIELD_LENGTH) timelines?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(MAX_FIELD_LENGTH) incidentResponses?: string;
}
