import {
  Body,
  Controller,
  Post,
  UploadedFile,
  UseInterceptors,
  BadRequestException,
  Get,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiBody, ApiConsumes, ApiTags } from '@nestjs/swagger';
import { ReportGeneratorService } from './report-generator.service';
import { PdfSummarizerService } from './pdf-summarizer.service';
import { GenerateReportDto } from './dto/generate-report.dto';

const MAX_FILE_SIZE_BYTES = 5 * 1024 * 1024;

@ApiTags('report-generator')
@Controller('report-generator')
export class ReportGeneratorController {
  constructor(
    private readonly service: ReportGeneratorService,
    private readonly pdfSummarizer: PdfSummarizerService,
  ) {}

  @Get()
  findAll() {
    return this.service.findAll();
  }

  /**
   * Accepts a PDF file, extracts its text in-memory, summarizes it via OpenAI,
   * and returns 3–5 Hebrew bullet points to populate the Narrative field.
   * The file buffer is purged immediately after processing.
   */
  @Post('summarize-pdf')
  @ApiConsumes('multipart/form-data')
  @UseInterceptors(
    FileInterceptor('file', {
      limits: { fileSize: MAX_FILE_SIZE_BYTES },
      fileFilter: (_req, file, cb) => {
        if (file.mimetype !== 'application/pdf') {
          return cb(new BadRequestException('Only PDF files are accepted.'), false);
        }
        cb(null, true);
      },
    }),
  )
  async summarizePdf(
    @UploadedFile() file: Express.Multer.File,
  ): Promise<{ bullets: string[] }> {
    if (!file) {
      throw new BadRequestException('No file uploaded.');
    }
    const bullets = await this.pdfSummarizer.summarize(file.buffer);
    return { bullets };
  }

  /**
   * Receives validated report form fields and generates a Hebrew report draft
   * using a template-specific OpenAI prompt. No data is persisted.
   *
   * @param dto - Validated form fields (templateType determines which prompt is used)
   * @returns An object containing the AI-generated Hebrew report draft
   */
  @Post('generate')
  @ApiBody({ type: GenerateReportDto })
  async generateReport(
    @Body() dto: GenerateReportDto,
  ): Promise<{ draft: string }> {
    return this.service.generateReport(dto);
  }
}
