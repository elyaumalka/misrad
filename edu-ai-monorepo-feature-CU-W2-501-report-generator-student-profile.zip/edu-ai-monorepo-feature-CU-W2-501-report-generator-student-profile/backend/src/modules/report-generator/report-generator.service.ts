import { Injectable, InternalServerErrorException, Logger } from '@nestjs/common';
import OpenAI from 'openai';
import * as dotenv from 'dotenv';
import { GenerateReportDto, TemplateType } from './dto/generate-report.dto';

dotenv.config();

const TEMPLATE_SYSTEM_PROMPTS: Record<TemplateType, string> = {
  A:
    'אתה עוזר פדגוגי מנוסה. כתוב מכתב עדכון רשמי ומלוטש להורי התלמיד. ' +
    'האורך: 3-4 פסקאות (כחצי עמוד עד עמוד מלא). ' +
    'התמקד בהצלחות לימודיות ובהמלצות מעשיות לתמיכה בבית. ' +
    'טון: רשמי, חם, מכבד. כתוב בעברית בלבד.',

  B:
    'אתה עוזר פדגוגי מנוסה. כתוב סיכום פדגוגי פנימי מקצועי ואובייקטיבי. ' +
    'האורך: 1-2 עמודים. ' +
    'כלול: ציונים לפי מקצועות, תפקוד חברתי, עיקרי ישיבות צוות. ' +
    'טון: מקצועי, עובדתי, תיאורי. כתוב בעברית בלבד.',

  C:
    'אתה עוזר פדגוגי מנוסה. כתוב מסמך הפניה ליועץ חינוכי. ' +
    'האורך: עמוד אחד ממוקד. ' +
    'תאר התנהגויות באופן עובדתי וניטרלי ללא שיפוטיות, כלול חסמים לימודיים ואירועים חריגים. ' +
    'טון: ענייני, ניטרלי, ממוקד. כתוב בעברית בלבד.',

  D:
    'אתה עוזר פדגוגי מנוסה. כתוב מכתב הצטיינות חגיגי ומעצים לתלמיד. ' +
    'האורך: כחצי עמוד בפורמט מכתב הוקרה. ' +
    'ציין הישגים ספציפיים וכלול ציטוט השראתי מהמורה. ' +
    'טון: חיובי, חם, חגיגי, מעצים. כתוב בעברית בלבד.',

  E:
    'אתה עוזר פדגוגי מנוסה. כתוב תוכנית התערבות התנהגותית מובנית ומעשית. ' +
    'האורך: 1-2 עמודים. ' +
    'כלול שלבים ברורים, יעדים מדידים עם לוחות זמנים, ודרכי תגובה לאירועים — רצוי בפורמט טבלה או רשימה ממוספרת. ' +
    'טון: יישומי, מובנה, מקצועי. כתוב בעברית בלבד.',
};

/**
 * Builds the structured user message sent to OpenAI from the request DTO.
 */
function buildUserMessage(dto: GenerateReportDto): string {
  const lines: string[] = [
    `שם תלמיד: ${dto.studentName}`,
    `כיתה: ${dto.className}`,
    `חוזקות: ${dto.strengths}`,
    `אתגרים: ${dto.challenges}`,
    `פעולות שננקטו: ${dto.actionsTaken}`,
  ];

  if (dto.narrative) lines.push(`נרטיב מסמך תומך: ${dto.narrative}`);

  // Template A fields
  if (dto.contactDetails) lines.push(`פרטי התקשרות: ${dto.contactDetails}`);
  if (dto.academicSuccesses) lines.push(`הצלחות לימודיות: ${dto.academicSuccesses}`);
  if (dto.homeRecommendations) lines.push(`המלצות לבית: ${dto.homeRecommendations}`);

  // Template B fields
  if (dto.gradeDetails) lines.push(`פירוט ציונים: ${dto.gradeDetails}`);
  if (dto.socialFunctioning) lines.push(`תפקוד חברתי: ${dto.socialFunctioning}`);
  if (dto.teamMeetingSummary) lines.push(`סיכום ישיבות צוות: ${dto.teamMeetingSummary}`);

  // Template C fields
  if (dto.learningBarriers) lines.push(`חסמים לימודיים: ${dto.learningBarriers}`);
  if (dto.unusualEvents) lines.push(`אירועים חריגים: ${dto.unusualEvents}`);
  if (dto.referralReason) lines.push(`סיבת ההפניה: ${dto.referralReason}`);

  // Template D fields
  if (dto.specificAchievement) lines.push(`הישג ספציפי: ${dto.specificAchievement}`);
  if (dto.teacherQuote) lines.push(`ציטוט מורה: ${dto.teacherQuote}`);
  if (dto.excellenceField) lines.push(`תחום הצטיינות: ${dto.excellenceField}`);

  // Template E fields
  if (dto.measurableGoals) lines.push(`יעדים מדידים: ${dto.measurableGoals}`);
  if (dto.timelines) lines.push(`לוחות זמנים: ${dto.timelines}`);
  if (dto.incidentResponses) lines.push(`דרכי תגובה לאירועים: ${dto.incidentResponses}`);

  return lines.join('\n');
}

@Injectable()
export class ReportGeneratorService {
  private readonly logger = new Logger(ReportGeneratorService.name);
  private readonly openai = new OpenAI({ apiKey: process.env['OPENAI_API_KEY'] });

  /** @deprecated Placeholder kept for backwards-compatible GET route. */
  findAll(): never[] {
    this.logger.log('findAll called');
    return [];
  }

  /**
   * Generates a pedagogical report draft using template-specific OpenAI prompts.
   * No student data is persisted — the draft is returned to the caller and discarded.
   *
   * @param dto - Validated form fields including template type and narrative
   * @returns An object containing the generated Hebrew report draft
   */
  async generateReport(dto: GenerateReportDto): Promise<{ draft: string }> {
    const systemPrompt = TEMPLATE_SYSTEM_PROMPTS[dto.templateType];
    const userMessage = buildUserMessage(dto);

    try {
      const response = await this.openai.chat.completions.create({
        model: 'gpt-4o',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userMessage },
        ],
        temperature: 0.5,
      });

      const draft = response.choices[0]?.message?.content?.trim() ?? '';
      if (!draft) {
        throw new InternalServerErrorException('OpenAI returned an empty response.');
      }
      return { draft };
    } catch (error: unknown) {
      this.logger.error('OpenAI report generation failed');
      if (error instanceof InternalServerErrorException) throw error;
      throw new InternalServerErrorException('Failed to generate report. Please try again.');
    }
  }
}
