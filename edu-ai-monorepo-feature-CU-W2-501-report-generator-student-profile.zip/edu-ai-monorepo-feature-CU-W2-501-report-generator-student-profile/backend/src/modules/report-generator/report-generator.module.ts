import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { ReportGeneratorController } from './report-generator.controller';
import { ReportGeneratorService } from './report-generator.service';
import { PdfSummarizerService } from './pdf-summarizer.service';
import { CorsMiddleware } from './cors.middleware';

@Module({
  controllers: [ReportGeneratorController],
  providers: [ReportGeneratorService, PdfSummarizerService],
  exports: [ReportGeneratorService, PdfSummarizerService],
})
export class ReportGeneratorModule implements NestModule {
  configure(consumer: MiddlewareConsumer): void {
    consumer.apply(CorsMiddleware).forRoutes('report-generator');
  }
}
