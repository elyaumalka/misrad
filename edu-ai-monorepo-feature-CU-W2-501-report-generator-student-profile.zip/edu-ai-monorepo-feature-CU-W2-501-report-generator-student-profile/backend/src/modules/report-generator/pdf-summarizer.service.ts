import { Injectable, InternalServerErrorException } from '@nestjs/common';
import { PDFParse } from 'pdf-parse';
import OpenAI from 'openai';
import * as dotenv from 'dotenv';

dotenv.config();

const SUMMARY_PROMPT =
  'Summarize this pedagogical document into 3-5 bullet points in Hebrew. ' +
  'Return only the bullet points, one per line, starting with "•".';

const MAX_TEXT_CHARS = 8000;

@Injectable()
export class PdfSummarizerService {
  private readonly openai = new OpenAI({ apiKey: process.env['OPENAI_API_KEY'] });

  /**
   * Extracts plain text from a PDF buffer, sends it to OpenAI, and returns
   * 3–5 Hebrew bullet-point summaries. The buffer is zeroed in a finally block
   * so no PDF data lingers in memory after the request completes.
   */
  async summarize(buffer: Buffer): Promise<string[]> {
    const parser = new PDFParse({ data: buffer });
    try {
      const result = await parser.getText();
      const text = result.text.slice(0, MAX_TEXT_CHARS).trim();
      if (!text) {
        throw new InternalServerErrorException('PDF contained no extractable text.');
      }
      return await this.callOpenAI(text);
    } finally {
      await parser.destroy();
      buffer.fill(0);
    }
  }

  /**
   * Sends the extracted text to OpenAI and returns the parsed bullet list.
   */
  private async callOpenAI(text: string): Promise<string[]> {
    const response = await this.openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: SUMMARY_PROMPT },
        { role: 'user', content: text },
      ],
      temperature: 0.3,
    });
    const content = response.choices[0]?.message?.content ?? '';
    return this.parseBullets(content);
  }

  /**
   * Splits the raw OpenAI response into a trimmed, non-empty line array.
   */
  private parseBullets(raw: string): string[] {
    return raw
      .split('\n')
      .map((line) => line.trim())
      .filter((line) => line.length > 0);
  }
}
