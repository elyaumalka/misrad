# edu-ai-monorepo

This project was generated with **Angular CLI** version 19 and **NestJS CLI** version 11, running on **Node.js** version 20.

---

## Development Server

**Frontend:**
Run `ng serve --host 0.0.0.0` from the `frontend/` directory. Navigate to `http://localhost:4200/`. The application will automatically reload if you change any of the source files.

**Backend:**
Run `npm run start:dev` from the `backend/` directory. Navigate to `http://localhost:3000/`.

**Database:**
PostgreSQL runs via Docker only. Run `docker-compose up` from the root directory to start it.

---

## Setup

```bash
# 1. Clone the repo
git clone https://github.com/SmartyAppOrg/edu-ai-monorepo.git
cd edu-ai-monorepo
git checkout develop

# 2. Copy env files
cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env

# 3. Open in VS Code → "Reopen in Container" → wait ~3 min

# 4. Run backend (Terminal 1)
cd backend && npm run start:dev

# 5. Run frontend (Terminal 2)
cd frontend && ng serve --host 0.0.0.0
```

Fill in all values marked `ask_lead` with credentials from the Project Lead.
For full setup instructions see [SETUP.md](./SETUP.md).

---

## Code Scaffolding

**Frontend:**
Run `ng generate component component-name` from the `frontend/` directory to generate a new Angular component.
You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

**Backend:**
Run `nest generate module module-name` from the `backend/` directory to generate a new NestJS module.

---

## Build

**Frontend:**
Run `ng build` from the `frontend/` directory. The build artifacts will be stored in the `dist/` directory.

**Backend:**
Run `npm run build` from the `backend/` directory. The build artifacts will be stored in the `dist/` directory.

---

## Running Unit Tests

**Frontend:**
Run `ng test` from the `frontend/` directory to execute unit tests via **Karma**.

**Backend:**
Run `npm run test` from the `backend/` directory to execute unit tests via **Jest**.

---

## Running End-to-End Tests

**Frontend:**
Run `ng e2e` from the `frontend/` directory.

**Backend:**
Run `npm run test:e2e` from the `backend/` directory.

---

## Docker

```bash
# Local dev — PostgreSQL only
docker-compose up

# Staging — do not run locally
docker-compose -f docker-compose.staging.yml up
```

> ⚠️ `docker-compose.staging.yml` is for GCP only — do not run locally.

---

## Project Structure

```
edu-ai-monorepo/
├── frontend/               ← Angular 19
│   └── src/app/
│       ├── core/           🔒 Auth, Guards, Interceptors
│       ├── shared/         ⚠️ Shared Components
│       └── projects/       ✅ Feature modules
│           ├── chatbot/
│           ├── dashboard/
│           ├── risk-report/
│           ├── report-generator/
│           └── student-profile/
├── backend/                ← NestJS 11
│   └── src/
│       ├── config/         🔒 External services config
│       ├── common/         ⚠️ Guards, Pipes, Decorators
│       └── modules/        ✅ Feature modules
│           ├── chatbot/
│           ├── dashboard/
│           ├── risk-report/
│           ├── report-generator/
│           └── student-profile/
├── database/
│   └── migrations/         🔒 Project Lead only
├── infra/                  🔒 GCP & CI/CD — do not touch
├── .devcontainer/          🔒
├── docker-compose.yml
└── docker-compose.staging.yml
```

🔒 Protected — Project Lead only | ⚠️ Shared — requires approval | ✅ Your workspace

---

## Git Workflow

Branch naming: `feature/<your-name>/CU-<task-id>-<short-description>`

```bash
# Example
git checkout -b feature/john/CU-abc123-student-dashboard
```

- Never commit directly to `main` or `develop`
- Never merge your own PR
- No ticket = No branch = No PR (ClickUp)

For full guidelines see [CLAUDE.md](./CLAUDE.md).

---

## Further Help

**Angular CLI:** Run `ng help` or check out the [Angular CLI Overview and Command Reference](https://angular.dev/tools/cli) page.

**NestJS:** Check out the [NestJS documentation](https://docs.nestjs.com) page.
