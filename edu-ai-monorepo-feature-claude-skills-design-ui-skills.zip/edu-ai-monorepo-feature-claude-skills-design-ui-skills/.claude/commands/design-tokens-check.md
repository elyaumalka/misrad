# /design-tokens-check — Full Design Consistency Report

Generate a full compliance report showing how well each component follows the project's design system defined in `styles.scss`.

## Instructions

### Step 1 — Build the design system reference map
Read `frontend/src/styles.scss` and extract:

**Color tokens:**
- `--color-primary-dark: #0D1B2A`
- `--color-primary: #1B2A3B`
- `--color-primary-light: #2E4057`
- `--color-bg: #F4F6F8`
- `--color-surface: #FFFFFF`
- `--color-success: #2E7D32`, `--color-warning: #E65100`, `--color-danger: #C62828`, `--color-info: #1565C0`
- `--color-text-primary: #0D1B2A`, `--color-text-secondary: #4A5568`, `--color-text-disabled: #A0AEC0`, `--color-text-on-dark: #FFFFFF`
- `--color-success-bg: #E8F5E9`, `--color-warning-bg: #FFF3E0`, `--color-danger-bg: #FFEBEE`
- Chart colors: `--chart-color-1` through `--chart-color-4`, `--chart-grid`, `--chart-bg`

**Spacing tokens:**
- `--space-xs: 4px`, `--space-sm: 8px`, `--space-md: 16px`, `--space-lg: 24px`, `--space-xl: 40px`

**Available utility classes (already built — no need to recreate):**
- Typography: `.ds-display`, `.ds-h1`, `.ds-h2`, `.ds-h3`, `.ds-body`, `.ds-small`
- Layout: `.ds-container`, `.ds-grid`
- Header: `.ds-header`, `.ds-header__brand`, `.ds-header__user`
- Cards: `.ds-card`, `.ds-kpi-card`, `.ds-kpi-card--success/warning/danger/info`, `.ds-kpi-card__value`, `.ds-kpi-card__label`
- Buttons: `.ds-btn-primary`, `.ds-btn-secondary`
- Badges: `.ds-badge`, `.ds-badge--success/warning/danger`
- Special: `.ds-ai-insights`, `.ds-icon-directional`

**Font:** Heebo (the only approved font)

### Step 2 — Scan all components
Scan every `.scss` and `.html` file under `frontend/src/app/` (excluding `styles.scss`).

### Step 3 — Score each component

For each component calculate a compliance score:

**Color compliance (40% of score):**
- Each `var(--color-*)` used = ✓ compliant
- Each hardcoded `#hex` / `rgb()` = ✗ violation (−5 points each)
- Suggest the nearest color token for each violation

**Font compliance (20% of score):**
- Uses `'Heebo'` or inherits = ✓
- Any other `font-family` declaration = ✗ (−10 points)

**Spacing compliance (20% of score):**
- Each `var(--space-*)` used = ✓
- Each raw `px`/`rem` value matching a token = ✗ (−3 points each)

**Utility class usage (20% of score):**
- Identify cases where the component recreates something that `.ds-card`, `.ds-btn-primary`, `.ds-badge`, etc. already provides
- Each reimplemented pattern = ✗ (−5 points), "use `.ds-card` instead"
- Identify custom `font-size` declarations that should be `.ds-h1`, `.ds-body`, etc.

### Step 4 — Output the report

```
## Design System Compliance Report
**Date:** today | **Design Authority:** frontend/src/styles.scss

---
### Component Scores
| Component | Color | Font | Spacing | Utility Classes | Total |
|-----------|-------|------|---------|-----------------|-------|
| home.component | 30% | 0% | 40% | 10% | 42% ⚠️ |
| nav-card.component | 80% | 100% | 60% | 70% | 78% 🟡 |
| app.component | 100% | 100% | 100% | 100% | 100% ✅ |

**Score Legend:** ✅ ≥90% | 🟡 70–89% | ⚠️ 50–69% | 🔴 <50%

---
### 🔴 Components Needing Urgent Attention
**home.component (42%)**

Color violations:
- Line 45: `background: linear-gradient(90deg, #667eea 0%, #764ba2 100%)`
  → Use `var(--color-primary-light)` to `var(--color-primary-dark)`
- Line 78: `color: #28a745`
  → Use `var(--color-success)`

Font violations:
- Line 12: `font-family: 'Segoe UI', Helvetica Neue`
  → Use `font-family: 'Heebo', sans-serif`

Utility class opportunities:
- The `.home-card` class reimplements `.ds-card` (border, shadow, border-radius)
  → Replace with `class="ds-card"` in the template
- Custom font-size `32px bold` → Use class `.ds-display` instead

---
### 🏆 Top 5 Easiest Wins (highest impact, lowest effort)
1. Replace `font-family: 'Segoe UI'` in `home.component.scss` → 20 points
2. Replace `#28a745` with `var(--color-success)` in 3 files → 15 points
3. Add `.ds-card` class to home cards and remove duplicate SCSS → 10 points
4. Replace `1.5rem` spacing with `var(--space-lg)` in `nav-card.component.scss` → 9 points
5. Replace `.home-btn` styles with `.ds-btn-primary` → 5 points

---
### 📊 Project-Wide Stats
- Average compliance: X%
- Most violated token: `--color-primary` (hardcoded N times)
- Most missed utility class: `.ds-card`
```

After outputting the report, offer to automatically apply the top 5 easiest wins.
