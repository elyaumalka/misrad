# /angular-component — Responsive Component Scaffolder

Generate a complete, design-system-compliant Angular component.

**Usage:**
```
/angular-component <component-name> "<description>"
```

**Examples:**
```
/angular-component student-report-card "Shows a student's grades summary with risk level badge"
/angular-component attendance-chart "Displays weekly attendance as a bar chart using Chart.js"
/angular-component risk-alert-banner "Banner shown when a student's risk score exceeds threshold"
```

## Instructions

### Step 1 — Parse the arguments
Extract:
- `componentName`: kebab-case name provided (e.g. `student-report-card`)
- `description`: what the component does (used for JSDoc and aria-label)
- Derive: `ClassName` = PascalCase (e.g. `StudentReportCard`), `selector` = `app-<componentName>`

Determine the appropriate output folder based on the name:
- Names with `student` or `profile` → `frontend/src/app/projects/student-profile/`
- Names with `dashboard` or `chart` or `kpi` → `frontend/src/app/projects/dashboard/`
- Names with `risk` or `alert` → `frontend/src/app/projects/risk-report/`
- Names with `report` or `pdf` → `frontend/src/app/projects/report-generator/`
- Names with `chat` or `bot` → `frontend/src/app/projects/chatbot/`
- Otherwise → ask the user which project folder to use

### Step 2 — Generate the TypeScript file
`<component-name>.component.ts`

Requirements:
- Standalone component (`standalone: true`)
- Imports: `CommonModule`, `RouterModule` at minimum
- All `@Input()` props must have explicit TypeScript types (no `any`)
- All `@Output()` emitters must have typed `EventEmitter<T>`
- Constructor injection uses Angular's `inject()` function
- Max 30 lines per method
- Every public method has a JSDoc comment
- Private variables use `readonly` where possible
- Use `signal()` for reactive state if applicable

Template:
```typescript
import { Component, Input, Output, EventEmitter, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

/**
 * <ClassName> — <description>
 */
@Component({
  selector: 'app-<component-name>',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './<component-name>.component.html',
  styleUrl: './<component-name>.component.scss'
})
export class <ClassName>Component {
  // @Input() and @Output() declarations here
  // component logic here
}
```

### Step 3 — Generate the HTML template
`<component-name>.component.html`

Requirements:
- Uses Bootstrap 5 grid (`row`, `col-12 col-md-6`, etc.) for responsive layout
- Uses design system utility classes: `.ds-card`, `.ds-h2`, `.ds-body`, `.ds-btn-primary`, `.ds-badge`, etc.
- Every interactive element has `aria-label` or `aria-labelledby`
- All `<img>` tags have `alt` attribute and `loading="lazy"`
- Logical heading hierarchy starting at `<h2>` (page `<h1>` comes from the route)
- RTL-safe: no hardcoded `left`/`right` inline styles
- Angular Material components used where appropriate (mat-card, mat-button, mat-icon)

### Step 4 — Generate the SCSS file
`<component-name>.component.scss`

Requirements:
- **Mobile-first** — base styles for mobile, media queries for larger screens
- **Design tokens only** — NEVER use hardcoded colors, fonts, or spacing values
- Font: inherit (Heebo is set globally)
- Colors: only `var(--color-*)` tokens
- Spacing: only `var(--space-*)` tokens
- RTL-safe: only `margin-inline-*`, `padding-inline-*`, `inset-inline-*`
- Include all 3 standard breakpoints:

```scss
:host {
  display: block;
}

.<component-name> {
  // mobile-first base styles using var(--color-*) and var(--space-*)

  @media (min-width: 768px) {
    // tablet overrides
  }

  @media (min-width: 1024px) {
    // desktop overrides
  }
}
```

- Add `:focus-visible` styles for every element that has `:hover`
- Add `@media (prefers-reduced-motion: reduce)` if animations are used

### Step 5 — Generate the spec file
`<component-name>.component.spec.ts`

Requirements:
- Uses `TestBed` with `ComponentFixture`
- Test 1: component renders without errors (`should create`)
- Test 2: a meaningful interaction or input binding test
- No external HTTP calls (mock any services with `jasmine.createSpyObj`)

### Step 6 — Output the files

Create all 4 files in the correct project folder.

Then output a summary:
```
## Component Created: <ClassName>Component

**Files created:**
- `<path>/<component-name>.component.ts`
- `<path>/<component-name>.component.html`
- `<path>/<component-name>.component.scss`
- `<path>/<component-name>.component.spec.ts`

**Design system compliance:** 100%
- Colors: all using var(--color-*) tokens ✅
- Font: inheriting Heebo globally ✅
- Spacing: all using var(--space-*) tokens ✅
- RTL-safe: logical margin/padding/inset properties ✅
- Accessibility: aria-labels and focus states present ✅
- Responsive: mobile-first with 768px and 1024px breakpoints ✅

**Next step:** Import <ClassName>Component in your module's imports array.
```
