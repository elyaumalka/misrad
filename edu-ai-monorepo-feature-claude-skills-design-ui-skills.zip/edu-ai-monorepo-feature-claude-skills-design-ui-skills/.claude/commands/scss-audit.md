# /scss-audit — SCSS Quality & Design Token Enforcer

Audit SCSS files in this Angular project for design system violations and quality issues.

## Instructions

### Step 1 — Load the design system
Read `frontend/src/styles.scss` and extract:
- All CSS custom properties: `--color-*`, `--space-*`, font declarations
- The official font: **Heebo**
- The spacing scale: `--space-xs` (4px), `--space-sm` (8px), `--space-md` (16px), `--space-lg` (24px), `--space-xl` (40px)
- All color tokens: `--color-primary-dark`, `--color-primary`, `--color-primary-light`, `--color-bg`, `--color-surface`, `--color-success`, `--color-warning`, `--color-danger`, `--color-info`, `--color-text-primary`, `--color-text-secondary`, `--color-text-disabled`, `--color-text-on-dark`

### Step 2 — Scan target files
If a file path argument was provided (e.g. `/scss-audit frontend/src/app/projects/dashboard/`), scan only that path.
Otherwise scan ALL `.scss` files under `frontend/src/app/` (excluding `styles.scss` itself).

### Step 3 — Check each file for these violations

**CRITICAL violations (must fix before PR):**
- [ ] Hardcoded color values: any `#hex`, `rgb(...)`, `rgba(...)`, `hsl(...)` — suggest the nearest `var(--color-*)` token
- [ ] Wrong font: `font-family` set to anything other than `'Heebo'`, `inherit`, or `var(--font-*)` — flag it and suggest `font-family: 'Heebo', sans-serif`
- [ ] Raw spacing that matches a token: `4px` → `var(--space-xs)`, `8px` → `var(--space-sm)`, `16px` → `var(--space-md)`, `24px` → `var(--space-lg)`, `40px` → `var(--space-xl)`. Also flag `1rem` (= 16px = `--space-md`), `1.5rem` (= 24px = `--space-lg`)

**WARNING violations (should fix):**
- [ ] SCSS nesting deeper than 3 levels — flag the selector chain
- [ ] Duplicate property in same selector block (e.g. `color` declared twice)
- [ ] `!important` usage — flag with explanation of why it's fragile
- [ ] Hardcoded `z-index` values that are not documented constants
- [ ] Missing `:focus` or `:focus-visible` state on elements that have `:hover` (keyboard accessibility)

**INFO (best practice suggestions):**
- [ ] `px` values for `font-size` — suggest `rem` or a `.ds-*` typography class
- [ ] Inline `transition` without matching `prefers-reduced-motion` media query
- [ ] BEM depth over 4 levels (readability issue)

### Step 4 — Output the report

Format:

```
## SCSS Audit Report
**Scanned:** <N> files | **Date:** today

---
### 🔴 CRITICAL — Must Fix Before PR
| File | Line | Issue | Fix |
|------|------|-------|-----|
| home.component.scss | 42 | Hardcoded color `#667eea` | Use `var(--color-primary-light)` |
| home.component.scss | 15 | Font `Segoe UI` | Use `font-family: 'Heebo', sans-serif` |

---
### 🟡 WARNINGS — Should Fix
| File | Line | Issue | Fix |
|------|------|-------|-----|
| ...  | ...  | ...   | ... |

---
### 🔵 INFO — Best Practice
| File | Line | Issue | Fix |
|------|------|-------|-----|
| ...  | ...  | ...   | ... |

---
### ✅ Summary
- Critical: X | Warnings: Y | Info: Z
- Files with no issues: [list]
```

After outputting the report, ask: "Would you like me to automatically fix the CRITICAL issues?"
