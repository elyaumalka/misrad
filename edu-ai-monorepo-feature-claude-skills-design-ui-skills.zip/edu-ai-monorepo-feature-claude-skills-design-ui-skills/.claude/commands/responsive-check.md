# /responsive-check — Responsive Design Auditor

Check Angular components for responsive design issues and RTL safety.

## Instructions

### Step 1 — Identify scope
If a path argument was provided (e.g. `/responsive-check frontend/src/app/projects/dashboard/`), scan only that path.
Otherwise scan ALL component `.scss` and `.html` files under `frontend/src/app/`.

The project uses these standard breakpoints (from `styles.scss`):
- **1024px** — tablet landscape / 2-column grid
- **768px** — tablet portrait / 1-column, reduced padding
- **480px** — mobile / minimal spacing

The project is **RTL (right-to-left)** — Hebrew language. This affects directional CSS.

### Step 2 — SCSS checks

**CRITICAL — Layout breaks on mobile:**
- [ ] Fixed `width: <px>` on containers that should be fluid (`%`, `vw`, `max-width`)
- [ ] Fixed `height: <px>` on containers that contain dynamic text (use `min-height` instead)
- [ ] `overflow: hidden` without a responsive alternative (hides content on small screens)
- [ ] `white-space: nowrap` on text that could overflow

**CRITICAL — RTL violations (this app is Hebrew/RTL):**
- [ ] `margin-left` or `margin-right` — replace with `margin-inline-start` / `margin-inline-end`
- [ ] `padding-left` or `padding-right` — replace with `padding-inline-start` / `padding-inline-end`
- [ ] `left: <value>` or `right: <value>` in positioned elements — replace with `inset-inline-start` / `inset-inline-end`
- [ ] `text-align: left` — replace with `text-align: start`
- [ ] `text-align: right` — replace with `text-align: end`
- [ ] `border-left` / `border-right` — replace with `border-inline-start` / `border-inline-end`
- [ ] `float: left` / `float: right` — replace with logical equivalents or flex

**WARNING — Responsive best practices:**
- [ ] Media queries that don't use the standard breakpoints (1024px, 768px, 480px) — flag non-standard values
- [ ] `flex` or `grid` containers without a responsive `@media` override
- [ ] `font-size` in `px` on text elements (should be `rem` to respect browser zoom)
- [ ] `gap` values in `px` that should use `var(--space-*)` tokens

**WARNING — Images:**
- [ ] `<img>` elements without `max-width: 100%` in their SCSS
- [ ] `<img>` elements without `object-fit: cover` or `contain` when inside a fixed container

### Step 3 — HTML template checks

**CRITICAL:**
- [ ] `<img>` without `loading="lazy"` (performance on mobile)
- [ ] Inline `style="width: Xpx"` (bypasses responsive CSS)

**WARNING:**
- [ ] Bootstrap grid columns without responsive variants: `class="col-6"` with no `col-md-12` or `col-sm-12` sibling
- [ ] `d-flex` without a responsive `flex-column` or `flex-wrap` variant
- [ ] Tables without `table-responsive` wrapper (horizontal scroll on mobile)

### Step 4 — Output the report

```
## Responsive Design Report
**Scanned:** <N> SCSS files, <M> HTML templates

---
### 🔴 CRITICAL — Layout Breaking Issues
| File | Line | Issue | Fix |
|------|------|-------|-----|

---
### 🔴 CRITICAL — RTL Violations
| File | Line | Violation | RTL-Safe Replacement |
|------|------|-----------|----------------------|

---
### 🟡 WARNINGS
| File | Line | Issue | Fix |
|------|------|-------|-----|

---
### ✅ Summary
- Critical layout: X | RTL violations: Y | Warnings: Z
- Fully responsive components: [list]
```

After the report, ask: "Would you like me to fix the RTL violations automatically?"
