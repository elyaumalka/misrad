# Claude Commands — Team Guide

This folder contains **custom Claude commands** (also called skills or slash commands) built specifically for this project. They give Claude a set of instructions that is tailored to our codebase, design system, and conventions — so instead of explaining the rules each time, you just run a command.

## What is a Claude command?

A Claude command is a file in `.claude/commands/` written in Markdown. When you type `/command-name` inside Claude Code (the AI assistant in your terminal or IDE), Claude reads that file and follows the instructions inside it automatically.

Think of each command as a specialized task that Claude knows how to run for this project.

## How to run any command

Type the command name at the start of your message in Claude Code:

```
/command-name
```

Some commands also accept arguments (a path, a component name, etc.). These are shown in each section below.

---

## Commands in this directory

### 1. `/angular-component` — Generate a new Angular component

**File:** `angular-component.md`

**What it does:**
Creates a complete, ready-to-use Angular component for you — four files at once: the TypeScript class, the HTML template, the SCSS styles, and a test file. The generated component follows all project rules automatically: design tokens, accessibility attributes, responsive breakpoints, RTL-safe CSS, and JSDoc comments.

**Why use it:**
Setting up a new component by hand requires remembering many rules at once (standalone component, no hardcoded colors, correct folder, aria-labels, mobile-first SCSS, etc.). This command handles all of that for you in one step.

**How to run it:**
```
/angular-component <component-name> "<description>"
```

- `<component-name>` — the name of the component in kebab-case
- `"<description>"` — a short sentence explaining what the component does

**Examples:**
```
/angular-component student-report-card "Shows a student's grades summary with risk level badge"
/angular-component attendance-chart "Displays weekly attendance as a bar chart"
/angular-component risk-alert-banner "Banner shown when a student's risk score exceeds threshold"
```

**What to expect:**
Claude will create 4 files in the correct project folder (it figures out the folder from your component name). It will then print a summary confirming that colors, fonts, spacing, RTL, accessibility, and responsiveness are all compliant.

---

### 2. `/a11y-check` — Accessibility audit

**File:** `a11y-check.md`

**What it does:**
Scans all Angular HTML templates and SCSS files for accessibility problems. It checks for missing alt text, unlabeled buttons and inputs, broken keyboard navigation, missing focus styles, and issues specific to Hebrew/RTL apps (like missing `dir` attributes and `lang="he"`).

**Why use it:**
This is a school platform used by teachers and students — some of whom may use screen readers or keyboard-only navigation. Accessibility issues are easy to miss during development, and this command catches them before they reach code review.

**How to run it:**

Scan everything:
```
/a11y-check
```

Scan a specific folder only:
```
/a11y-check frontend/src/app/projects/risk-report/
```

**What to expect:**
A structured report with three severity levels:
- **CRITICAL** — blockers that prevent users from accessing content (missing alt text, unlabeled inputs, no focus style)
- **WARNINGS** — issues that degrade the experience (heading hierarchy, aria-live regions)
- **RTL/Hebrew specific** — issues unique to the Hebrew language context

Claude will offer to fix the critical issues automatically after showing the report.

---

### 3. `/design-tokens-check` — Design system compliance report

**File:** `design-tokens-check.md`

**What it does:**
Reads the design system defined in `frontend/src/styles.scss` and then scans every component to check how well it follows the rules. It gives each component a score based on four criteria: color token usage, font compliance, spacing token usage, and use of pre-built utility classes.

**Why use it:**
The design system provides ready-made colors, spacing values, buttons, cards, and badges. When developers hardcode values or recreate something that already exists (like writing custom card styles instead of using `.ds-card`), the UI becomes inconsistent and harder to maintain. This command finds those gaps.

**How to run it:**
```
/design-tokens-check
```

No arguments needed — it always scans the entire frontend.

**What to expect:**
A table showing a score per component (e.g. `78% 🟡`), followed by a detailed breakdown of every violation — with the exact line, the wrong value, and the correct token to use instead. At the end, Claude lists the **top 5 easiest wins**: the changes that give the biggest improvement for the least effort. Claude will offer to apply those fixes automatically.

---

### 4. `/responsive-check` — Responsive layout and RTL audit

**File:** `responsive-check.md`

**What it does:**
Checks all component SCSS and HTML for two categories of problems:
1. **Responsive layout issues** — things that will break on smaller screens, like fixed pixel widths on containers, missing media queries, or tables without a scrollable wrapper.
2. **RTL violations** — CSS properties that assume a left-to-right layout (`margin-left`, `padding-right`, `text-align: left`, etc.) that need to be replaced with logical properties so the app works correctly in Hebrew.

**Why use it:**
This project is a Hebrew-language app, meaning text and layout flow from right to left. Using directional CSS properties (`left`, `right`, `margin-left`, etc.) instead of logical properties (`inline-start`, `inline-end`) causes visual bugs that are easy to overlook in development but break the layout in production. This command finds all of them.

**How to run it:**

Scan everything:
```
/responsive-check
```

Scan a specific folder only:
```
/responsive-check frontend/src/app/projects/dashboard/
```

**What to expect:**
A report split into three sections:
- **Critical layout issues** — things that will cause broken layouts on mobile
- **Critical RTL violations** — directional CSS that needs to be replaced with logical equivalents
- **Warnings** — best-practice issues like non-standard breakpoints or missing responsive variants

Claude will offer to fix the RTL violations automatically after showing the report.

---

### 5. `/scss-audit` — SCSS quality and token enforcement

**File:** `scss-audit.md`

**What it does:**
Audits every SCSS file in the project for code quality and design system violations. It checks for hardcoded colors and spacing values that should use design tokens, wrong font declarations, deeply nested selectors, duplicate properties, `!important` usage, and missing focus states.

**Why use it:**
Hardcoded values (like `color: #28a745` instead of `var(--color-success)`) make the codebase harder to maintain — if the design system changes, those values won't update automatically. This command enforces consistency and catches issues that should be fixed before opening a pull request.

**How to run it:**

Scan everything:
```
/scss-audit
```

Scan a specific folder only:
```
/scss-audit frontend/src/app/projects/dashboard/
```

**What to expect:**
A report with three tiers:
- **CRITICAL** — must fix before opening a PR (hardcoded colors, wrong font, raw spacing values)
- **WARNINGS** — should fix (deep nesting, `!important`, missing focus states, duplicate properties)
- **INFO** — best practice suggestions (use `rem` for font-size, add `prefers-reduced-motion`)

Claude will offer to automatically fix the critical issues after showing the report.

---

## Quick reference

| Command | Purpose | Takes a path argument? |
|---|---|---|
| `/angular-component <name> "<desc>"` | Generate a new component | No — provide name and description |
| `/a11y-check` | Accessibility audit | Optional |
| `/design-tokens-check` | Design system compliance scores | No |
| `/responsive-check` | Responsive layout + RTL audit | Optional |
| `/scss-audit` | SCSS quality and token enforcement | Optional |

---

## Tips

- The audit commands (`/a11y-check`, `/scss-audit`, `/responsive-check`, `/design-tokens-check`) are safe to run at any time — they only read files, they never change anything unless you confirm.
- Run `/scss-audit` and `/a11y-check` before opening a pull request to catch issues early.
- When generating a component with `/angular-component`, Claude will ask you which project folder to use if the name does not clearly match one of the five projects.
