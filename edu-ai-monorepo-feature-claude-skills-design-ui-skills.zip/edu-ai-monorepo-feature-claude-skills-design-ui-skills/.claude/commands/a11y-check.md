# /a11y-check — Accessibility Audit

Audit Angular component templates and SCSS for accessibility (a11y) issues.
This project is a school platform — accessibility ensures teachers and students with disabilities can use it.
The app is Hebrew/RTL which adds specific requirements.

## Instructions

### Step 1 — Identify scope
If a path argument was provided (e.g. `/a11y-check frontend/src/app/projects/risk-report/`), scan only that path.
Otherwise scan ALL `.html` and `.scss` files under `frontend/src/app/`.

### Step 2 — HTML Template checks

**CRITICAL:**
- [ ] `<img>` without `alt` attribute — every image needs descriptive alt text (or `alt=""` if decorative)
- [ ] `<button>` with only an icon or SVG child and no `aria-label` or `aria-labelledby`
- [ ] `<a>` with text like "click here", "read more", "link" — not descriptive for screen readers
- [ ] `<input>`, `<select>`, `<textarea>` without an associated `<label>` (via `for`/`id` or `aria-label`)
- [ ] `<form>` missing `aria-label` or `aria-labelledby` when there are multiple forms on a page
- [ ] Interactive elements (clickable `<div>`, `<span>`) missing `role="button"` and `tabindex="0"`
- [ ] `<table>` missing `<caption>` or `aria-label`
- [ ] `<table>` missing `scope` attribute on `<th>` elements

**WARNING:**
- [ ] Heading hierarchy violations: `<h3>` appearing before any `<h2>`, or skipped levels (`<h1>` → `<h3>`)
- [ ] Multiple `<h1>` elements on a single component view
- [ ] `<section>` or `<article>` without an accessible heading or `aria-label`
- [ ] `tabindex` values greater than 0 (breaks natural tab order)
- [ ] `aria-hidden="true"` on elements that are focusable
- [ ] Missing `role="alert"` or `aria-live` on dynamic content areas (error messages, notifications)
- [ ] `<mat-icon>` (Angular Material icon) used alone without a visually-hidden label

**RTL/Hebrew specific:**
- [ ] Mixed Hebrew/English text in a single element without `dir="auto"` or explicit `dir` attribute
- [ ] Numbers and dates that need `dir="ltr"` when nested inside RTL context
- [ ] `lang` attribute missing on the root `<html>` element (should be `lang="he"`)

### Step 3 — SCSS checks

**CRITICAL:**
- [ ] `:focus` or `:focus-visible` style is absent for any selector that has `:hover` — keyboard users can't see focus
- [ ] `outline: none` or `outline: 0` without a custom `box-shadow` focus indicator replacement
- [ ] Touch targets smaller than 44×44px: look for interactive elements (buttons, links) with `height` or `min-height` < 44px

**WARNING:**
- [ ] `cursor: pointer` set on non-interactive elements (misleads users)
- [ ] Animation/transition with no `@media (prefers-reduced-motion: reduce)` override

### Step 4 — Output the report

```
## Accessibility Audit Report
**Scanned:** <N> HTML templates, <M> SCSS files

---
### 🔴 CRITICAL — Accessibility Blockers
| File | Line | Issue | Fix |
|------|------|-------|-----|

---
### 🟡 WARNINGS — Should Fix
| File | Line | Issue | Fix |
|------|------|-------|-----|

---
### 🔵 RTL/Hebrew Specific Issues
| File | Line | Issue | Fix |
|------|------|-------|-----|

---
### ✅ Summary
- Critical: X | Warnings: Y | RTL issues: Z
- Accessible components: [list]

### 💡 Quick wins
[List the 3 fastest fixes that would have the biggest impact]
```

After the report, offer to fix the critical `aria-label` and `:focus` issues automatically.
