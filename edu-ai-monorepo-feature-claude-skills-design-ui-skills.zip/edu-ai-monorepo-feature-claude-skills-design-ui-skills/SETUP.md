# 🚀 Developer Setup Guide

> קרא את המדריך הזה מהתחלה לסוף לפני שמתחילים. כל שלב חשוב.

---

## ✅ דרישות מקדימות (רק שניים!)

| כלי | למה |
|---|---|
| **Docker Desktop** | מריץ את סביבת הפיתוח |
| **VS Code** + תוסף **Dev Containers** | פותח את הפרויקט בתוך הסביבה |

- הורדת Docker Desktop: https://www.docker.com/products/docker-desktop
- הורדת תוסף Dev Containers: https://marketplace.visualstudio.com/items?itemName=ms-vscode-remote.remote-containers

> ✅ Node.js, Angular CLI וכל שאר הכלים **מותקנים אוטומטית** — אין צורך להתקין כלום ידנית.

---

## שלב 1 — קבלת גישה לפרויקט

פנה ל-Project Lead וקבל את הדברים הבאים לפני שממשיכים:

- [ ] הזמנה ל-Git Repository
- [ ] הזמנה ל-ClickUp
- [ ] ערכי `.env` לסביבת הפיתוח (OpenAI, Auth0, Pinecone וכו')

---

## שלב 2 — Clone של הפרויקט

פתח טרמינל והרץ:

```bash
git clone <repo-url>
cd school-ai-platform
git checkout develop
git pull origin develop
```

---

## שלב 3 — הגדרת קבצי סביבה

```bash
# Backend
cd backend
cp .env.example .env

# Frontend
cd ../frontend
cp .env.example .env
```

פתח כל קובץ `.env` והחלף את כל הערכים שכתוב בהם `ask_lead` בערכים שקיבלת מה-Project Lead.

> ⚠️ אל תשתף את קובץ `.env` עם אף אחד ואל תעלה אותו ל-Git.

---

## שלב 4 — פתיחה ב-Dev Container

```
1. ודא ש-Docker Desktop פתוח ורץ
2. פתח VS Code
3. File → Open Folder → בחר את תיקיית הפרויקט
4. VS Code ישאל: "Reopen in Container?" → לחץ Yes
5. המתן ~3 דקות (רק בפעם הראשונה)
```

מה שמותקן אוטומטית בזמן ההמתנה:
- Node.js 20
- Angular CLI
- כל ה-dependencies של Backend ו-Frontend
- PostgreSQL

---

## שלב 5 — הרצת הפרויקט

פתח **שני טרמינלים** בתוך VS Code (Terminal → New Terminal):

**טרמינל 1 — Backend:**
```bash
cd backend
npm run start:dev
```
רץ על `http://localhost:3000`

**טרמינל 2 — Frontend:**
```bash
cd frontend
ng serve --host 0.0.0.0
```
רץ על `http://localhost:4200`

---

## שלב 6 — בדיקה שהכל עובד

- [ ] `http://localhost:4200` — מופיע ממשק ההתחברות
- [ ] `http://localhost:3000/api` — מופיעה תשובה מה-Backend
- [ ] ב-Docker Desktop — כל ה-containers ירוקים ורצים

---

## שלב 7 — יצירת Branch לעבודה

**לפני שמתחילים לכתוב קוד**, צור branch לפי המשימה ב-ClickUp:

```bash
git checkout -b feature/<your-name>/CU-<task-id>-<short-description>
```

לדוגמה:
```bash
git checkout -b feature/john/CU-abc123-student-dashboard
```

---

## 🛑 בעיות נפוצות

**VS Code לא מציע "Reopen in Container":**
ודא שתוסף Dev Containers מותקן ו-Docker Desktop פתוח ורץ.

**הבנייה נכשלת או נתקעת:**
ב-VS Code: `Ctrl+Shift+P` ← הקלד: `Dev Containers: Rebuild Container`

**Backend לא מתחבר ל-DB:**
ודא שמילאת את ערכי ה-DB ב-`.env` ושה-container של PostgreSQL רץ ב-Docker Desktop.

**Port 4200 / 3000 תפוס:**
```bash
lsof -i :4200
lsof -i :3000
```

---

## 📋 סדר הפעולות בכל בוקר

**אופציה א — סקריפט אוטומטי (מומלץ):**

יש לך קובץ `start.sh` בתיקיית המסמכים שמריץ הכל אוטומטית:
```bash
~/Documents/start.sh
```
הסקריפט מריץ את Docker, Backend ו-Frontend בבת אחת — פותח שני חלונות טרמינל נפרדים.

---

**אופציה ב — ידנית:**
```bash
# 1. עדכן מ-develop
git checkout develop && git pull origin develop

# 2. עבור ל-branch שלך
git checkout feature/<your-name>/...

# 3. הרץ Backend (טרמינל 1)
cd backend && npm run start:dev

# 4. הרץ Frontend (טרמינל 2)
cd frontend && ng serve --host 0.0.0.0
```

> ה-Dev Container ו-Docker עולים אוטומטית עם פתיחת VS Code — אין צורך להריץ אותם ידנית.

---

*לשאלות — פנה ל-Project Lead.*