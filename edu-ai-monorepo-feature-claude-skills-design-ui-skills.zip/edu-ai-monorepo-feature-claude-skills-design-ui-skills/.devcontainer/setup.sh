#!/bin/bash
set -e
echo "📦 Installing Angular CLI..."
npm install -g @angular/cli@19
echo "📦 Installing backend dependencies..."
cd /workspace/backend && npm install
echo "📦 Installing frontend dependencies..."
cd /workspace/frontend && npm install
echo "✅ Setup complete!"
