# Team Development Guidelines

> This file defines the rules and workflow for all developers on this project.
> When using Claude or any AI assistant inside your development environment, these rules must be respected at all times.
> Claude should read and follow these instructions before suggesting any changes.

---

## 🧱 Tech Stack Overview

| Technology | Type | Role |
|---|---|---|
| **Angular** | Frontend | All user interfaces – chat, dashboards, forms, admin screens |
| **TypeScript** | Language | Code consistency across Frontend & Backend |
| **NestJS** | Backend Framework | Business logic, API, DB connections, AI, permissions, workflows |
| **PostgreSQL** | Relational Database | System data: users, permissions, class structures, statuses |
| **Google Sheets** | Data Source | Pedagogical data: students, grades, attendance |
| **Google Docs / PDF** | Documents | Pedagogical documents and reports |
| **Pinecone** | Vector Database | Storing embeddings for RAG |
| **LLM / OpenAI** | AI | Summaries, report generation, chat responses |
| **RAG** | AI Pattern | Integrating document knowledge into AI responses |
| **Auth0** | Authentication | User management, login, and permissions |
| **Docker** | Infrastructure | Local dev infrastructure only (PostgreSQL) |
| **Google Cloud (GCP)** | Cloud | Running Backend, Frontend, Jobs, and Secrets |

---

## 📁 Project Structure

```
school-ai-platform/                        ← Root repository (Git)
│
├── docker-compose.yml                     🔒 Local dev infrastructure only
├── docker-compose.staging.yml             🔒 Staging only — do not run locally
├── .env.example                           ← Copy to .env and fill in local values
├── CLAUDE.md                              ← This file
├── SETUP.md                               ← Onboarding guide
│
├── .devcontainer/                         🔒
│   ├── devcontainer.json
│   ├── docker-compose.yml
│   └── setup.sh
│
├── infra/                                 🔒 GCP & CI/CD — do not touch
│   ├── backend.dockerfile
│   ├── frontend.dockerfile
│   └── nginx.conf
│
├── frontend/                              ← Angular Application
│   ├── angular.json                       🔒
│   ├── tsconfig.json                      🔒
│   ├── package.json                       🔒
│   └── src/
│       ├── environments/                  🔒
│       └── app/
│           ├── core/                      🔒 (auth, interceptors, guards)
│                       ├── shared/                    ⚠️ Read before editing
│           └── projects/                  ✅ Your workspace
│               ├── chatbot/               → Project 1
│               ├── dashboard/             → Project 2
│               ├── risk-report/           → Project 3
│               ├── report-generator/      → Project 4
│               └── student-profile/       → Project 5
│
├── backend/                               ← NestJS Application
│   ├── nest-cli.json                      🔒
│   ├── tsconfig.json                      🔒
│   ├── package.json                       🔒
│   └── src/
│       ├── main.ts                        🔒
│       ├── app.module.ts                  🔒
│       ├── config/                        🔒 (OpenAI, Pinecone, Auth0, Google, Twilio)
│       ├── common/                        ⚠️ Read before editing
│       └── modules/                       ✅ Your workspace
│           ├── chatbot/                   → Project 1
│           │   ├── rag/
│           │   └── channels/              (whatsapp, email)
│           ├── dashboard/                 → Project 2
│           │   ├── sheets/
│           │   └── processors/
│           ├── risk-report/               → Project 3
│           │   ├── engine/
│           │   └── ai/
│           ├── report-generator/          → Project 4
│           │   ├── pdf/
│           │   └── templates/
│           └── student-profile/           → Project 5
│               └── ai/
│
├── database/
│   └── migrations/                        🔒 Managed by project lead only
│
└── infra/                                 🔒 GCP & CI/CD — do not touch
```

**Legend:**
- 🔒 Protected — managed by project lead only
- ⚠️ Shared — requires approval before editing
- ✅ Your workspace — work freely within your assigned feature/module

---

## 🖥️ Local Dev Setup

כל מפתח עובד לוקאלית. אין שרת משותף לפיתוח.

```bash
# 1. Clone the repo
git clone <repo-url>
cd school-ai-platform

# 2. Copy env files and fill in values from project lead
cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env

# 3. Open in VS Code → "Reopen in Container" → wait ~3 min

# 4. Run Backend (Terminal 1)
cd backend && npm run start:dev

# 5. Run Frontend (Terminal 2)
cd frontend && ng serve --host 0.0.0.0
```

- `docker-compose` מריץ את **PostgreSQL בלבד** — לא את הקוד
- הקוד רץ ישירות לוקאלית לצורך hot reload
- אל תריץ `docker-compose.staging.yml` לוקאלית — זה מיועד ל-GCP בלבד
- אם משהו לא עולה — פנה ל-lead לפני שמשנים קבצי תשתית

---

## 🔒 Protected Files — Do Not Touch

### General
- `package.json` / `package-lock.json` / `yarn.lock`
- `.env` / `.env.*`
- `README.md` (root level)
- `/.github/`

### Angular (Frontend)
- `angular.json`
- `tsconfig.json` / `tsconfig.app.json` / `tsconfig.spec.json`
- `src/environments/environment*.ts`
- `src/proxy.conf.json`

### NestJS (Backend)
- `tsconfig.json` / `tsconfig.build.json`
- `nest-cli.json`
- `src/app.module.ts`
- `src/main.ts`

### Infrastructure & Cloud
- `Dockerfile` / `docker-compose*.yml` / `.dockerignore`
- `cloudbuild.yaml` / `app.yaml` / any GCP config files
- `/infra/` directory
- `/.devcontainer/`

### External Services Config
- Any Auth0 configuration files
- Any Pinecone / OpenAI initialization/config files
- Any Google API credentials or service account files
- Any Twilio / Gmail config files

If a task requires changes to any of the above — **stop and consult the project lead.**

---

## 🏗️ Module Boundaries (NestJS)

The backend is divided into 5 independent modules. **Each developer works within their assigned module only.**

| Module | Responsibility |
|---|---|
| `chatbot` | RAG logic, document retrieval, WhatsApp & Email integrations |
| `dashboard` | Google Sheets ingestion, weekly processing, chart data APIs |
| `risk-report` | Rules-based scoring engine, weekly risk report generation |
| `report-generator` | PDF processing, questionnaire handling, report drafting |
| `student-profile` | Individual student data aggregation, AI trend analysis |

- Each module owns its own services, controllers, and DTOs
- Cross-module communication must go through clearly defined service interfaces — never import a module's internals directly
- If you think you need logic from another module, consult the project lead first

---

## 🔒 PII — Personal Data Rules (Critical)

- **Never log personal data** (student names, IDs, grades) to the console or any log file
- **Never store PII in variables or memory** longer than needed to complete a single request
- **Never save uploaded PDFs or documents to disk** — process in memory only and discard immediately
- **Never return raw student data in error messages** — sanitize all error responses
- **Never hardcode any student, teacher, or school data** — use mock data only for testing
- The RAG / Pinecone knowledge base must contain **procedures and policies only** — never personal records

If you are unsure whether a piece of data counts as PII — treat it as PII and ask.

---

## 🌍 Environments

Three environments: `development`, `staging`, `production`.

- You work in `development` only
- Never deploy or push config changes targeting `staging` or `production`
- Staging/production env vars are managed by the project lead via GCP Secrets Manager
- If your code behaves differently between environments — report it, do not fix it by editing env configs

---

## 📊 Google Sheets — Read-Only Data Source

- **Never modify column structure or column names** of the master sheet
- **Never write data to the master sheet** unless specifically assigned to the report-generation task
- **Never change sheet sharing permissions or API credentials**
- Always use the designated Google Sheets service class — do not create new direct API calls

---

## 📱 External Service Integrations — Protected

Do not create new instances, change credentials, or modify initialization logic for:

- **Twilio / WhatsApp Business** — chatbot messaging
- **Gmail API** — email bot
- **OpenAI API** — never initialize a new client outside the designated AI service
- **Pinecone** — never create new indexes or change the existing index name
- **Auth0** — never modify roles, rules, or permissions
- **Google APIs** (Sheets, Docs, Drive) — never create new service accounts

All are initialized once in `src/config/`. Use the injected service — do not instantiate directly.

---

## 🧩 Working with Shared Code

### Angular: `/shared` and `/core`
- `shared/` — treat as read-only. Create a local version inside your feature folder if needed.
- `core/` — never modify auth services, HTTP interceptors, or route guards.

### NestJS: `/common` and `/config`
- Do not edit shared guards, decorators, or pipes directly.
- Do not change any module registration in `app.module.ts`.

### Database (PostgreSQL)
- **Never write or run migrations directly** — submit schema change requests to the project lead.
- Do not modify existing entity files outside your assigned module.

---

## 📦 Adding New Dependencies

- **Never run `npm install <package>`** without approval
- Document the need and bring the request to the project lead
- Applies to both Angular and NestJS projects

---

## ✍️ Code Quality Standards

### Readability & Consistency
- All code, comments, variable names, and function names — **English only**
- No magic numbers — use named constants: `const MAX_RETRIES = 3`
- Every public function/method in NestJS must have a **JSDoc comment**
- Max function length: **30 lines**
- Max file length: **300 lines**
- **`any` is forbidden** in TypeScript — always define explicit types
- Use `const` by default — `let` only when value genuinely changes
- No commented-out code in commits

### Naming Conventions

| Element | Convention | Example |
|---|---|---|
| Component | PascalCase | `StudentDashboard` |
| Service / Class | PascalCase | `ReportGeneratorService` |
| Variable / Function | camelCase | `fetchStudentGrades()` |
| File name | kebab-case | `student-dashboard.component.ts` |
| Constant | UPPER_SNAKE_CASE | `MAX_FILE_SIZE` |
| DB column | snake_case | `created_at` |

### Preventing Recurring Bugs
- **Never** use `console.log` — use NestJS `Logger` service instead
- **Never** expose raw error messages to the frontend
- **Never** write raw SQL strings — use the ORM/query builder only
- **Never** store secrets or API keys in code — use environment variables only
- Always handle `null` / `undefined` explicitly
- Always wrap OpenAI and Pinecone calls in `try/catch` with a fallback response
- Every API endpoint must have input validation (DTOs + class-validator)

---

## 🗂️ ClickUp Workflow

No ticket = no branch = no PR.

### Before Starting
- Ticket is assigned to you and moved to **"In Progress"**
- Branch name: `feature/<your-name>/CU-<task-id>-<short-description>`
  - Example: `feature/john/CU-abc123-login-form-validation`

### While Working
- Hit a blocker? Update the ClickUp ticket before asking for help
- Log your time in ClickUp at end of each day

### Opening a PR
- PR title: `feat(CU-abc123): add login form validation`
- PR description template:

```
## What was done
[Short description]

## ClickUp Task
[Link to ticket]

## How to test
[Steps to verify]

## Notes for reviewer
[Anything to pay attention to]
```

---

## 🌿 Git Workflow

- **Never commit directly to `main` or `develop`**
- Branch naming: `feature/<your-name>/CU-<task-id>-<short-description>`
- Keep commits small — one logical change per commit
- Commit message format: `feat(CU-abc123): add attendance summary component`
- **Never merge your own PR**

---

## 🤖 Guidelines for Using Claude (AI Assistant)

1. **Never suggest changes to protected files** — if Claude does, disregard the suggestion
2. Provide Claude with context **scoped to your feature/module only**
3. Claude helps with: feature logic, tests, debugging, explaining concepts, documentation
4. If Claude suggests installing a package — **do not act on it**, bring it to the project lead
5. If Claude suggests editing shared modules or config files — discussion point only, not an action
6. If Claude suggests schema/migration changes — bring to project lead
7. Always review Claude's output before applying it — **you are responsible for the code you commit**

---

## ✅ Day-to-Day Checklist

Before starting work:
- [ ] Pull latest changes from `develop`
- [ ] Confirm you are on your own branch
- [ ] ClickUp ticket moved to "In Progress"

Before committing:
- [ ] Changes scoped to your assigned feature/module
- [ ] No protected files modified
- [ ] Code runs locally without errors
- [ ] Tests written/updated
- [ ] No hardcoded secrets or API keys
- [ ] No `console.log` in code
- [ ] No commented-out code blocks

Before opening a PR:
- [ ] Branch is up to date with `develop`
- [ ] PR title includes ClickUp task ID
- [ ] PR description follows the template

---

## 🙋 When to Ask for Help

Don't stay stuck for more than **30 minutes**. Reach out via the team channel with:
1. What you were trying to do
2. What you tried
3. The error or result you got

---

*Last updated by project lead. Do not modify this file.*