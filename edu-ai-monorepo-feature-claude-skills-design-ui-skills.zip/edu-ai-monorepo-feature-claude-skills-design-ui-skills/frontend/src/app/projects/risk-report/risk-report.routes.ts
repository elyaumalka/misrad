import { Routes } from '@angular/router';
import { RiskReportComponent } from './risk-report.component';

export const routes: Routes = [
  { path: '', component: RiskReportComponent }
];
