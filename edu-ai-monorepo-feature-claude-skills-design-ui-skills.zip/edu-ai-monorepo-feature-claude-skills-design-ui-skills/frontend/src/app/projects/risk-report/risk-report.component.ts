import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-risk-report',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './risk-report.component.html',
})
export class RiskReportComponent {}
