import { Routes } from '@angular/router';
import { ReportGeneratorComponent } from './report-generator.component';

export const routes: Routes = [
  { path: '', component: ReportGeneratorComponent }
];
