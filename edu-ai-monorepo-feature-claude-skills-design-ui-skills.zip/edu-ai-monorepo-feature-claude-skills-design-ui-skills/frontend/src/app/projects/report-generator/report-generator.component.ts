import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-report-generator',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './report-generator.component.html',
})
export class ReportGeneratorComponent {}
