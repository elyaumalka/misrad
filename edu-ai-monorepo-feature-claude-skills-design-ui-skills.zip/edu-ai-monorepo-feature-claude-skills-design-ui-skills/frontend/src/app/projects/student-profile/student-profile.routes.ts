import { Routes } from '@angular/router';
import { StudentProfileComponent } from './student-profile.component';

export const routes: Routes = [
  { path: '', component: StudentProfileComponent }
];
