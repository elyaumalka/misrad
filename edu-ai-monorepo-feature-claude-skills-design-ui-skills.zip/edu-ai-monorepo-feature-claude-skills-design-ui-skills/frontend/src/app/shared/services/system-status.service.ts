import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';

export interface SystemStatus {
  lastSyncTime: string;
  status: 'ok' | 'error';
  message?: string;
}

@Injectable({
  providedIn: 'root'
})
export class SystemStatusService {
  constructor(private http: HttpClient) {}

  getStatus(): Observable<SystemStatus> {
    // TODO: כאשר הבקנד יוכן, להשתמש בנתיב אמיתי
    // return this.http.get<SystemStatus>('/api/system/status').pipe(
    //   catchError(() => this.getDefaultStatus())
    // );

    // בינתיים - mock data
    return of({
      lastSyncTime: new Date().toISOString(),
      status: 'ok',
      message: 'סנכרון אחרון הצליח'
    });
  }

  private getDefaultStatus(): Observable<SystemStatus> {
    return of({
      lastSyncTime: new Date().toISOString(),
      status: 'error',
      message: 'לא ניתן להשיג סטטוס המערכת'
    });
  }
}
