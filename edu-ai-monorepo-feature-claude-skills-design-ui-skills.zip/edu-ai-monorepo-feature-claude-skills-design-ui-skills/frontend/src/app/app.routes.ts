import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    loadChildren: () => import('./home/home.routes').then(m => m.routes)
  },
  {
    path: 'dashboard',
    loadChildren: () => import('./projects/dashboard/dashboard.routes').then(m => m.routes)
  },
  {
    path: 'chatbot',
    loadChildren: () => import('./projects/chatbot/chatbot.routes').then(m => m.routes)
  },
  {
    path: 'report-generator',
    loadChildren: () => import('./projects/report-generator/report-generator.routes').then(m => m.routes)
  },
  {
    path: 'risk-report',
    loadChildren: () => import('./projects/risk-report/risk-report.routes').then(m => m.routes)
  },
  {
    path: 'student-profile',
    loadChildren: () => import('./projects/student-profile/student-profile.routes').then(m => m.routes)
  }
];
