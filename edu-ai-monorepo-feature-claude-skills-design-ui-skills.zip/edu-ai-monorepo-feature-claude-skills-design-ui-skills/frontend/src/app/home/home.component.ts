import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { NavCardComponent } from '../shared/components/nav-card';
import { SystemStatusService } from '../shared/services';
import { HttpClientModule } from '@angular/common/http';

interface NavCard {
  title: string;
  description: string;
  icon: string;
  route: string;
  projectNumber: number;
}

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterLink, NavCardComponent, HttpClientModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss'
})
export class HomeComponent implements OnInit {
  lastSyncTime: string | null = null;
  syncStatus: 'ok' | 'error' | 'loading' = 'loading';
  syncMessage: string = '';

  navCards: NavCard[] = [
    {
      title: '🤖 צ\'אטבוט ידע',
      description: 'שאל שאלה על נהלי בית הספר',
      icon: '🤖',
      route: '/chatbot',
      projectNumber: 1
    },
    {
      title: '📊 דשבורד ביצועים',
      description: 'סקירת נתוני כיתה שבועיתית',
      icon: '📊',
      route: '/dashboard',
      projectNumber: 2
    },
    {
      title: '⚠️ דוח סיכון',
      description: 'תלמידים הדורשים תשומת לב',
      icon: '⚠️',
      route: '/risk-report',
      projectNumber: 3
    },
    {
      title: '📝 יצירת דוחות',
      description: 'כתיבת דוחות פדגוגיים בסיוע AI',
      icon: '📝',
      route: '/report-generator',
      projectNumber: 4
    },
    {
      title: '👤 פרופיל תלמיד',
      description: 'תמונת מצב אישית לתלמיד',
      icon: '👤',
      route: '/student-profile',
      projectNumber: 5
    }
  ];

  constructor(private systemStatusService: SystemStatusService) {}

  ngOnInit(): void {
    this.loadSystemStatus();
  }

  private loadSystemStatus(): void {
    this.systemStatusService.getStatus().subscribe({
      next: (status) => {
        this.lastSyncTime = status.lastSyncTime;
        this.syncStatus = status.status;
        this.syncMessage = status.message || '';
      },
      error: (error) => {
        this.syncStatus = 'error';
        this.syncMessage = 'שגיאה בטעינת סטטוס המערכת';
        console.error('Failed to load system status:', error);
      }
    });
  }
}
