# Design System — `styles.scss`

This file is the **single source of truth** for all visual styling across all 6 projects.
Every developer must use these classes and CSS variables — do not override or duplicate them locally.

---

## How It Works

`styles.scss` is loaded automatically by Angular as a global stylesheet.
That means every class and variable defined here is available in every component, with no import needed.

---

## Colors

Use CSS variables — never hardcode hex values in your component.

### Base Colors
| Variable | Value | Usage |
|---|---|---|
| `--color-primary-dark` | `#0D1B2A` | Header, sidebar, primary buttons |
| `--color-primary` | `#1B2A3B` | Card/panel backgrounds |
| `--color-primary-light` | `#2E4057` | Hover states, borders |
| `--color-bg` | `#F4F6F8` | General page background |
| `--color-surface` | `#FFFFFF` | Card and content box backgrounds |

### Status Colors
| Variable | Value | Usage |
|---|---|---|
| `--color-success` | `#2E7D32` | Low risk, positive KPI |
| `--color-warning` | `#E65100` | Medium risk, warning KPI |
| `--color-danger` | `#C62828` | High risk, negative KPI |
| `--color-info` | `#1565C0` | Info messages, tooltips |

### Text Colors
| Variable | Value | Usage |
|---|---|---|
| `--color-text-primary` | `#0D1B2A` | Headings, main text |
| `--color-text-secondary` | `#4A5568` | Descriptions, secondary text |
| `--color-text-disabled` | `#A0AEC0` | Placeholders, inactive elements |
| `--color-text-on-dark` | `#FFFFFF` | Text on dark backgrounds |

---

## Spacing

| Variable | Value | Usage |
|---|---|---|
| `--space-xs` | `4px` | Small inner padding |
| `--space-sm` | `8px` | Gap between elements |
| `--space-md` | `16px` | Card padding |
| `--space-lg` | `24px` | Gap between sections |
| `--space-xl` | `40px` | Gap between large areas |

---

## Typography

Font: **Heebo** (loaded from Google Fonts automatically).

| Class | Size | Weight | Usage |
|---|---|---|---|
| `.ds-display` | 32px | 900 | Main page title |
| `.ds-h1` | 24px | 700 | Screen headings |
| `.ds-h2` | 20px | 700 | Section headings |
| `.ds-h3` | 16px | 500 | Card headings |
| `.ds-body` | 14px | 400 | Regular text |
| `.ds-small` | 12px | 400 | Notes, tags |

---

## Layout

| Class | Description |
|---|---|
| `.ds-container` | Centers content, max-width 1280px, 24px side padding |
| `.ds-grid` | 3-column grid (2 on tablet, 1 on mobile) |

---

## Components

### Header — `.ds-header`
Dark background (`#0D1B2A`), height 64px, white text.
- `.ds-header__brand` — right side: logo + system name
- `.ds-header__user` — left side: username + role

```html
<header class="ds-header">
  <div class="ds-header__brand">Logo + System Name</div>
  <div class="ds-header__user">Name + Role</div>
</header>
```

---

### Card — `.ds-card`
White surface, rounded corners, subtle shadow. Shadow increases on hover.

```html
<div class="ds-card">Content here</div>
```

---

### KPI Card — `.ds-kpi-card`
White card with a colored top border indicating status.

| Modifier | Border Color |
|---|---|
| `.ds-kpi-card--success` | Green |
| `.ds-kpi-card--warning` | Orange |
| `.ds-kpi-card--danger` | Red |
| `.ds-kpi-card--info` | Blue |

- `.ds-kpi-card__value` — the metric number (32px, bold)
- `.ds-kpi-card__label` — the metric description (13px, secondary color)

```html
<div class="ds-kpi-card ds-kpi-card--success">
  <span class="ds-kpi-card__value">94%</span>
  <span class="ds-kpi-card__label">Attendance Rate</span>
</div>
```

---

### Buttons

```html
<!-- Primary -->
<button class="ds-btn-primary">Submit</button>

<!-- Secondary -->
<button class="ds-btn-secondary">Cancel</button>
```

---

### Status Badge — `.ds-badge`

| Modifier | Background | Text |
|---|---|---|
| `.ds-badge--success` | `#E8F5E9` | `#2E7D32` |
| `.ds-badge--warning` | `#FFF3E0` | `#E65100` |
| `.ds-badge--danger` | `#FFEBEE` | `#C62828` |

```html
<span class="ds-badge ds-badge--success">OK</span>
<span class="ds-badge ds-badge--warning">Review</span>
<span class="ds-badge ds-badge--danger">High Risk</span>
```

---

### AI Insights Box — `.ds-ai-insights`
Light background with a dark right border (RTL accent).

- `.ds-ai-insights__title` — bold title
- `.ds-ai-insights__content` — body text

```html
<div class="ds-ai-insights">
  <p class="ds-ai-insights__title">AI Summary</p>
  <p class="ds-ai-insights__content">Student shows improvement over the last 3 weeks.</p>
</div>
```

---

### Charts

Use the following CSS variables when configuring your chart library (Chart.js or Recharts):

| Variable | Value |
|---|---|
| `--chart-color-1` | `#0D1B2A` |
| `--chart-color-2` | `#2E4057` |
| `--chart-color-3` | `#4A7B9D` |
| `--chart-color-4` | `#1565C0` |
| `--chart-grid` | `#E2E8F0` |
| `--chart-bg` | `#F0F4F8` |

---

## RTL Rules

The file sets `direction: rtl` and `text-align: right` globally on `html` and `body`.

- Use `flex-direction: row` in flexbox — the browser flips it automatically in RTL.
- For accent borders (like AI Insights), always use `border-right`, never `border-left`.
- For directional icons (arrows), add the class `.ds-icon-directional` to flip them.

---

## Using Variables in Your Component SCSS

Since `styles.scss` is global, all CSS variables are available directly in any component SCSS file — no import needed.

```scss
// my-component.component.scss

.my-component {
  background-color: var(--color-surface);
  padding: var(--space-md);
  border-radius: 12px;
}

.my-component__title {
  font-size: 16px;
  font-weight: 500;
  color: var(--color-text-primary);
}

.my-component__subtitle {
  font-size: 14px;
  color: var(--color-text-secondary);
}

.my-component:hover {
  background-color: var(--color-primary-light);
  color: var(--color-text-on-dark);
}
```

---

## Rules

- Do not override these classes in your component SCSS.
- Do not hardcode colors — always use the CSS variables.
- Do not modify this file without approval from the team lead.
