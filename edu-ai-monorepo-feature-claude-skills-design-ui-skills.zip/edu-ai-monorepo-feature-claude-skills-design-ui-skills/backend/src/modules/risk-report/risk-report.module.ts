import { Module } from '@nestjs/common';
import { RiskReportController } from './risk-report.controller';
import { RiskReportService } from './risk-report.service';

@Module({
  controllers: [RiskReportController],
  providers: [RiskReportService],
  exports: [RiskReportService],
})
export class RiskReportModule {}
