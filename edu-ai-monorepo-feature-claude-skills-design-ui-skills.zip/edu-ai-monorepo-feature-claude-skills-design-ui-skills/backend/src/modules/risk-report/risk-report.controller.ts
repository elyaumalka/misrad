import { Controller, Get } from '@nestjs/common';
import { RiskReportService } from './risk-report.service';
import { ApiTags } from '@nestjs/swagger';

@ApiTags('risk-report')
@Controller('risk-report')
export class RiskReportController {
  constructor(private readonly service: RiskReportService) {}

  @Get()
  findAll() {
    return this.service.findAll();
  }
}
