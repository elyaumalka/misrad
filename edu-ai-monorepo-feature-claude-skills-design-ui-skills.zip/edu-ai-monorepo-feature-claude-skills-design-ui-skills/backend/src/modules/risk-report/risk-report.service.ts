import { Injectable, Logger } from '@nestjs/common';

@Injectable()
export class RiskReportService {
  private readonly logger = new Logger(RiskReportService.name);

  findAll() {
    this.logger.log('findAll called');
    return [];
  }
}
