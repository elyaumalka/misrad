import { Controller, Get } from '@nestjs/common';
import { StudentProfileService } from './student-profile.service';
import { ApiTags } from '@nestjs/swagger';

@ApiTags('student-profile')
@Controller('student-profile')
export class StudentProfileController {
  constructor(private readonly service: StudentProfileService) {}

  @Get()
  findAll() {
    return this.service.findAll();
  }
}
