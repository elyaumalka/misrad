import { Injectable, Logger } from '@nestjs/common';

@Injectable()
export class StudentProfileService {
  private readonly logger = new Logger(StudentProfileService.name);

  findAll() {
    this.logger.log('findAll called');
    return [];
  }
}
