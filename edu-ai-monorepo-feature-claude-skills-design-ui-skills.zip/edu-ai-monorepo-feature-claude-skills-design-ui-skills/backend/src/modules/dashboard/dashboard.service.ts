import { Injectable, Logger } from '@nestjs/common';

@Injectable()
export class DashboardService {
  private readonly logger = new Logger(DashboardService.name);

  findAll() {
    this.logger.log('findAll called');
    return [];
  }
}
