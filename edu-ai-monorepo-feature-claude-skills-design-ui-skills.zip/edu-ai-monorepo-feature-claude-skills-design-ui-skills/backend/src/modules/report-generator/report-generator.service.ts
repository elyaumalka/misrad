import { Injectable, Logger } from '@nestjs/common';

@Injectable()
export class ReportGeneratorService {
  private readonly logger = new Logger(ReportGeneratorService.name);

  findAll() {
    this.logger.log('findAll called');
    return [];
  }
}
