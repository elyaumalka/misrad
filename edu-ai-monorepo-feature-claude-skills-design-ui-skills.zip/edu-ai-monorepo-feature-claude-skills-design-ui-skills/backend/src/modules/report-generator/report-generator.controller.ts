import { Controller, Get } from '@nestjs/common';
import { ReportGeneratorService } from './report-generator.service';
import { ApiTags } from '@nestjs/swagger';

@ApiTags('report-generator')
@Controller('report-generator')
export class ReportGeneratorController {
  constructor(private readonly service: ReportGeneratorService) {}

  @Get()
  findAll() {
    return this.service.findAll();
  }
}
