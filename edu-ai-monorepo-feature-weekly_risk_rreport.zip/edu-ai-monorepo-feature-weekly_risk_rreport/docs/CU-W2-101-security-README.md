# CU-W2-101 — Auth0 Guards + RBAC + Audit Log to DB + Risk Report Security

## What was done

This document explains every change made in Week 2 security sprint, why it was done, and how it all connects.

---

## 1. New Files Created

### `backend/src/common/enums/role.enum.ts`
Defines the four roles the system recognises:

| Role | Value |
|---|---|
| `Role.ADMIN` | `"admin"` |
| `Role.TEACHER` | `"teacher"` |
| `Role.COUNSELOR` | `"counselor"` |
| `Role.STAFF` | `"staff"` |

Used everywhere guards and decorators reference a role — no magic strings in the codebase.

---

### `backend/src/common/decorators/roles.decorator.ts`
A NestJS metadata decorator: `@Roles(Role.ADMIN, Role.COUNSELOR)`.
Applied at the controller class level (or on individual methods) to declare which roles are allowed.
The `RolesGuard` reads this metadata at request time to make the access decision.

---

### `backend/src/common/guards/auth0-jwt.guard.ts`
**Authentication guard** — validates every incoming JWT.

What it does step by step:
1. Reads the `Authorization: Bearer <token>` header from the request.
2. Calls `JwtService.verify()` (from `@nestjs/jwt`) to verify the signature and expiry.
3. Attaches the decoded payload (`{ sub, roles }`) to `request.user`.
4. Throws `UnauthorizedException (401)` if the header is missing or the token is invalid.

The JWT payload shape expected from Auth0:
```json
{
  "sub": "auth0|abc123",
  "roles": ["counselor"],
  "iat": 1700000000,
  "exp": 1700003600
}
```

The `sub` field is the Auth0 user ID — an opaque string, never a real name.

---

### `backend/src/common/guards/roles.guard.ts`
**Authorization guard** — enforces RBAC after the JWT has been verified.

What it does:
1. Reads the `@Roles()` metadata from the current handler/controller using `Reflector`.
2. Reads `request.user.roles` (set by `Auth0JwtGuard`).
3. Checks whether the user holds at least one of the required roles.
4. Throws `ForbiddenException (403)` if the user lacks the required role.
5. Passes through if no `@Roles()` decorator is present (no restriction).

The guards always run in this order: `Auth0JwtGuard` → `RolesGuard` → `RateLimitGuard`.

---

### `backend/src/common/guards/rate-limit.guard.ts`
**Rate limiting guard** — blocks abnormal request volumes.

What it does:
- Tracks the number of requests per IP address in an in-memory `Map`.
- Allows up to **100 requests per minute** per IP.
- On the 101st request within the same window, throws `HttpException (429)`.
- The window resets automatically after 60 seconds.

> **Production note:** This in-memory implementation works for a single-instance deployment. For multi-instance (horizontal scaling), replace with a Redis-backed implementation (e.g. `@nestjs/throttler` with a Redis store). Coordinate with the Project Lead to add the dependency.

---

### `backend/src/common/entities/audit-log.entity.ts`
TypeORM entity mapped to the `audit_logs` database table.

| Column | Type | Description |
|---|---|---|
| `id` | UUID | Auto-generated primary key |
| `user_id` | varchar | Opaque Auth0 user ID — never a real name |
| `action` | varchar | Constant action descriptor (e.g. `VIEW_RISK_REPORT`) |
| `created_at` | timestamp | Set automatically by the database at insert time |

**PII rule:** student names, grades, scores, or any personal data are never stored in this table.

---

### `backend/src/common/audit-log.module.ts`
NestJS module that registers the `AuditLog` entity and exports `AuditLogService`.
Feature modules that need audit logging import `SecurityModule`, which re-exports this module.

---

### `backend/src/common/security.module.ts`
Shared module that bundles the entire security layer into one import:
- `JwtModule` — JWT signing/verification (reads `AUTH0_JWT_SECRET` or `AUTH0_CLIENT_SECRET` from env)
- `AuditLogModule` — DB logging
- `Auth0JwtGuard`, `RolesGuard`, `RateLimitGuard` — all three guards exported for use in controllers

Every feature module imports `SecurityModule` to gain access to all guards and `AuditLogService`.

---

## 2. Modified Files

### `backend/src/common/services/audit-log.service.ts`
**Before (Week 1):** Logged to NestJS Logger only (console output).
**After (Week 2):** Now also persists every entry to the `audit_logs` database table via TypeORM.

The `log(userId, action)` method:
1. Creates a timestamped log line via `Logger` (unchanged from Week 1).
2. Calls `auditLogRepository.save({ userId, action })` to write to PostgreSQL.

The method signature is now `async` because of the database write.
All existing PII-protection behaviour is preserved.

---

### `backend/src/modules/risk-report/risk-report.controller.ts`
**Security added:**
- `@UseGuards(Auth0JwtGuard, RolesGuard, RateLimitGuard)` — all three guards active.
- `@Roles(Role.ADMIN, Role.COUNSELOR)` — teachers and staff get 403.
- `AuditLogService` injected — every successful `GET /risk-report` call writes an audit entry: `userId + VIEW_RISK_REPORT + timestamp`.

### `backend/src/modules/student-profile/student-profile.controller.ts`
**Security added:**
- Same guard stack as risk-report.
- `@Roles(Role.ADMIN, Role.COUNSELOR)` — teachers cannot access student profiles.
- Audit log on every access: `VIEW_STUDENT_PROFILE`.

### `backend/src/modules/chatbot/chatbot.controller.ts`
- `@Roles(Role.ADMIN, Role.TEACHER, Role.STAFF)` — counselors cannot access chatbot.
- All three guards active.

### `backend/src/modules/dashboard/dashboard.controller.ts`
- `@Roles(Role.ADMIN, Role.TEACHER)` — counselors and staff cannot access dashboard.

### `backend/src/modules/report-generator/report-generator.controller.ts`
- `@Roles(Role.ADMIN, Role.TEACHER)` — staff cannot access report generator.

### All 5 `*.module.ts` files
Added `SecurityModule` to the `imports` array so controllers have access to the guards and `AuditLogService`.

### `backend/src/app.module.ts` ⚠️
> **Note:** This is a protected file per CLAUDE.md. This change was made as part of the security sprint because connecting TypeORM and registering the feature modules requires it. The Project Lead should review this diff before merging.

Changes made:
- Added `ConfigModule.forRoot()` (global) for environment variable access.
- Added `TypeOrmModule.forRootAsync()` configured from env vars (`DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD`, `DB_NAME`).
- Registered all 5 feature modules: `ChatbotModule`, `DashboardModule`, `RiskReportModule`, `ReportGeneratorModule`, `StudentProfileModule`.
- `synchronize: true` only in non-production environments — the `audit_logs` table is created automatically in development. In production the Project Lead must add a proper migration.

---

## 3. Unit Tests Written

| File | What is tested |
|---|---|
| `common/guards/auth0-jwt.guard.spec.ts` | Missing header → 401, invalid token → 401, valid token → attaches user, extracts sub |
| `common/guards/roles.guard.spec.ts` | All 4 roles × representative endpoints, no-decorator pass-through, empty-roles 403 |
| `common/guards/rate-limit.guard.spec.ts` | First request passes, up to 100 passes, 101st throws 429, per-IP isolation |
| `common/services/audit-log.service.spec.ts` | DB save called once, correct fields, no PII in payload or log line |
| `modules/risk-report/risk-report.rbac.spec.ts` | admin ✓, counselor ✓, teacher → 403, staff → 403 |
| `modules/student-profile/student-profile.rbac.spec.ts` | admin ✓, counselor ✓, teacher → 403, staff → 403 |
| `modules/chatbot/chatbot.rbac.spec.ts` | admin ✓, teacher ✓, staff ✓, counselor → 403 |
| `modules/dashboard/dashboard.rbac.spec.ts` | admin ✓, teacher ✓, counselor → 403, staff → 403 |
| `modules/report-generator/report-generator.rbac.spec.ts` | admin ✓, teacher ✓, staff → 403 |

---

## 4. Role-Permission Matrix

| Endpoint | admin | teacher | counselor | staff |
|---|:---:|:---:|:---:|:---:|
| `GET /chatbot` | ✅ | ✅ | ❌ 403 | ✅ |
| `GET /dashboard` | ✅ | ✅ | ❌ 403 | ❌ 403 |
| `GET /risk-report` | ✅ | ❌ 403 | ✅ | ❌ 403 |
| `GET /report-generator` | ✅ | ✅ | ❌ 403 | ❌ 403 |
| `GET /student-profile` | ✅ | ❌ 403 | ✅ | ❌ 403 |

---

## 5. Audit Log Behaviour

Endpoints that write to the audit log on every access:
- `GET /risk-report` → action: `VIEW_RISK_REPORT`
- `GET /student-profile` → action: `VIEW_STUDENT_PROFILE`

What is logged:
```
AUDIT | userId=auth0|abc123 | action=VIEW_RISK_REPORT | timestamp=2026-03-26T10:00:00.000Z
```

What is stored in the DB (`audit_logs` table):
```
id: "550e8400-e29b-41d4-a716-446655440000"
user_id: "auth0|abc123"
action: "VIEW_RISK_REPORT"
created_at: "2026-03-26T10:00:00.000Z"
```

**What is never stored:** student names, student IDs (real ones), grades, scores, email addresses, or any other PII.

---

## 6. How to Run Tests

```bash
cd backend
npm run test
```

To run a specific spec file:
```bash
npm run test -- --testPathPattern=roles.guard
npm run test -- --testPathPattern=risk-report.rbac
```

To run with coverage:
```bash
npm run test:cov
```

---

## 7. How to Verify Manually (with curl)

```bash
# No token → 401
curl http://localhost:3000/risk-report

# Teacher token trying to access risk-report → 403
curl -H "Authorization: Bearer <teacher-token>" http://localhost:3000/risk-report

# Counselor token → 200 + audit log written
curl -H "Authorization: Bearer <counselor-token>" http://localhost:3000/risk-report
```

To generate a test token for local dev, use the `@nestjs/jwt` `JwtService.sign()` with the `AUTH0_JWT_SECRET` from your `.env`:

```typescript
jwtService.sign({ sub: 'auth0|local-test', roles: ['counselor'] })
```

---

## 8. Definition of Done — Checklist

- [x] Every endpoint protected by Role (`@UseGuards` + `@Roles` on all 5 controllers)
- [x] Unit tests for every role passing (9 spec files, ~40 tests)
- [x] Audit Log writing to DB (TypeORM repository, `audit_logs` table)
- [x] Rate Limiting active (100 req/min per IP, custom in-memory guard)
- [x] Risk report endpoint protected and logged (counselor/admin only + audit on access)

---

## 9. Security Hardening Applied (post-review)

After an internal security review, the following additional fixes were applied:

| # | File | Fix |
|---|---|---|
| 1 | `security.module.ts` | Switched from `JwtModule.register()` (static secret) to `JwtModule.registerAsync()` with `ConfigService`. Now throws a hard startup error in production if neither `AUTH0_JWT_SECRET` nor `AUTH0_CLIENT_SECRET` is set — prevents accidental deployment with no JWT secret. |
| 2 | `main.ts` | Added `ValidationPipe({ whitelist, forbidNonWhitelisted, transform })` globally — strips unknown request fields and rejects malformed input. Added restrictive CORS (`localhost:4200` in dev, env-controlled in production, blocked by default). Removed `X-Powered-By` header to prevent framework fingerprinting. |
| 3 | `rate-limit.guard.spec.ts` | Replaced deprecated `fail()` call (not available in Jest 30) with a proper `expect(caught).toBeInstanceOf(HttpException)` pattern. |
| 4 | Both audited controllers | Merged two separate `import ... from '../../common/guards/auth0-jwt.guard'` lines into one (duplicate import). |

---

## 10. Known Limitations / Follow-ups

- **Rate limiter is in-memory** — not shared across multiple instances. Needs Redis for production scale. Flag to Project Lead when horizontal scaling is planned.
- **JWT algorithm is HS256** — acceptable for development. For production Auth0 uses RS256 with JWKS endpoint. The guard's `JwtService.verify()` call needs updating to use `jwksClient` or `passport-jwt` with a JWKS URI.
- **`synchronize: true` in TypeORM** — auto-creates `audit_logs` table in development. Before deploying to production, the Project Lead must create a proper TypeORM migration file.
- **`app.module.ts` was modified** — this is a protected file. The changes are minimal and scoped to what this sprint requires. Project Lead review required before merge.
