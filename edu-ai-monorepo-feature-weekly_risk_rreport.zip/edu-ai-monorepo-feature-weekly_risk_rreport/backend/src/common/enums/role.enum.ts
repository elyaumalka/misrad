/**
 * Defines the possible roles a user can have in the system.
 * Used by the RBAC guard to control access to endpoints.
 */
export enum Role {
  ADMIN = 'admin',
  TEACHER = 'teacher',
  COUNSELOR = 'counselor',
  STAFF = 'staff',
}
