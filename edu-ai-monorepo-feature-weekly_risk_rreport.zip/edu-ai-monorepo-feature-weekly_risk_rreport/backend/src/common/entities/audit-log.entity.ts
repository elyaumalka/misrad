import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from 'typeorm';

/**
 * TypeORM entity representing a row in the `audit_logs` table.
 *
 * PII policy: only userId (opaque ID) and action name are stored.
 * Student names, grades, or any personal identifiable information are never written here.
 */
@Entity('audit_logs')
export class AuditLog {
  /** Auto-generated UUID primary key. */
  @PrimaryGeneratedColumn('uuid')
  id: string;

  /**
   * The opaque user identifier from Auth0 (e.g. "auth0|abc123").
   * Never a real name or email address.
   */
  @Column({ name: 'user_id' })
  userId: string;

  /**
   * A constant action descriptor (e.g. "VIEW_RISK_REPORT", "VIEW_STUDENT_PROFILE").
   * Must not contain any PII.
   */
  @Column()
  action: string;

  /** Timestamp automatically set at insert time by the database. */
  @CreateDateColumn({ name: 'created_at' })
  timestamp: Date;
}
