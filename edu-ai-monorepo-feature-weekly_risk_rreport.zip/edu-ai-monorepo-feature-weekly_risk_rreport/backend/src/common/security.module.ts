import { Module } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtModule } from '@nestjs/jwt';
import { Auth0JwtGuard } from './guards/auth0-jwt.guard';
import { RolesGuard } from './guards/roles.guard';
import { RateLimitGuard } from './guards/rate-limit.guard';
import { AuditLogModule } from './audit-log.module';

/**
 * Shared security module that bundles JWT authentication, RBAC, rate limiting,
 * and audit logging into a single importable unit.
 *
 * Import SecurityModule in any feature module that needs protected endpoints.
 *
 * JWT secret resolution order:
 *   1. AUTH0_JWT_SECRET env var
 *   2. AUTH0_CLIENT_SECRET env var
 *   3. In development only: falls back to a local dev secret
 *   4. In production: throws at startup if neither variable is set
 *
 * ConfigModule is registered globally in AppModule, so ConfigService is available here.
 */
@Module({
  imports: [
    JwtModule.registerAsync({
      useFactory: (config: ConfigService) => {
        const secret =
          config.get<string>('AUTH0_JWT_SECRET') ??
          config.get<string>('AUTH0_CLIENT_SECRET');

        if (!secret && config.get<string>('NODE_ENV') === 'production') {
          throw new Error(
            'Missing JWT secret: AUTH0_JWT_SECRET or AUTH0_CLIENT_SECRET must be set in production.',
          );
        }

        return {
          secret: secret ?? 'dev-secret-do-not-use-in-production',
          signOptions: { expiresIn: '1h' },
        };
      },
      inject: [ConfigService],
    }),
    AuditLogModule,
  ],
  providers: [Auth0JwtGuard, RolesGuard, RateLimitGuard],
  exports: [Auth0JwtGuard, RolesGuard, RateLimitGuard, AuditLogModule, JwtModule],
})
export class SecurityModule {}
