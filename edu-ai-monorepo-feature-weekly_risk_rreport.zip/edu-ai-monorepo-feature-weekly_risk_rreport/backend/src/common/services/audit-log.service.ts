import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { AuditLog } from '../entities/audit-log.entity';

/**
 * Represents a single audit log entry for a sensitive action.
 * Contains only non-PII fields: user identifier, action name, and timestamp.
 */
export interface AuditLogEntry {
  userId: string;
  action: string;
  timestamp: Date;
}

/**
 * Service responsible for recording sensitive operations that involve student data.
 * Persists each entry to the `audit_logs` database table AND writes a structured
 * log line via NestJS Logger.
 *
 * PII policy: logs only userId and action — never names, grades, or any personal information.
 */
@Injectable()
export class AuditLogService {
  private readonly logger = new Logger(AuditLogService.name);

  constructor(
    @InjectRepository(AuditLog)
    private readonly auditLogRepository: Repository<AuditLog>,
  ) {}

  /**
   * Records a sensitive action performed by a user.
   * Writes to the database and to the application log.
   * Only userId and action are stored — no PII is written anywhere.
   *
   * @param userId - The opaque Auth0 user ID performing the action
   * @param action - A constant action descriptor (e.g. 'VIEW_STUDENT_PROFILE')
   */
  async log(userId: string, action: string): Promise<void> {
    const entry: AuditLogEntry = {
      userId,
      action,
      timestamp: new Date(),
    };

    this.logger.log(
      `AUDIT | userId=${entry.userId} | action=${entry.action} | timestamp=${entry.timestamp.toISOString()}`,
    );

    await this.auditLogRepository.save({
      userId: entry.userId,
      action: entry.action,
    });
  }
}
