import { Test, TestingModule } from '@nestjs/testing';
import { Logger } from '@nestjs/common';
import { getRepositoryToken } from '@nestjs/typeorm';
import { AuditLogService } from './audit-log.service';
import { AuditLog } from '../entities/audit-log.entity';

const mockRepository = {
  save: jest.fn().mockResolvedValue({}),
};

describe('AuditLogService', () => {
  let service: AuditLogService;
  let logSpy: jest.SpyInstance;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AuditLogService,
        {
          provide: getRepositoryToken(AuditLog),
          useValue: mockRepository,
        },
      ],
    }).compile();

    service = module.get<AuditLogService>(AuditLogService);
    logSpy = jest.spyOn(Logger.prototype, 'log').mockImplementation(() => undefined);
    jest.clearAllMocks();
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should not throw when logging a valid action', async () => {
    await expect(
      service.log('user-123', 'VIEW_STUDENT_PROFILE'),
    ).resolves.not.toThrow();
  });

  it('should include userId in the log message', async () => {
    await service.log('user-abc', 'GENERATE_REPORT');
    const logMessage = logSpy.mock.calls[0][0] as string;
    expect(logMessage).toContain('user-abc');
  });

  it('should include action in the log message', async () => {
    await service.log('user-abc', 'GENERATE_REPORT');
    const logMessage = logSpy.mock.calls[0][0] as string;
    expect(logMessage).toContain('GENERATE_REPORT');
  });

  it('should include an ISO timestamp in the log message', async () => {
    await service.log('user-xyz', 'DELETE_RECORD');
    const logMessage = logSpy.mock.calls[0][0] as string;
    expect(logMessage).toMatch(/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/);
  });

  it('should call repository.save with userId and action (no PII)', async () => {
    await service.log('user-123', 'VIEW_STUDENT_PROFILE');
    expect(mockRepository.save).toHaveBeenCalledWith({
      userId: 'user-123',
      action: 'VIEW_STUDENT_PROFILE',
    });
  });

  it('should not pass student name fields to repository.save (PII protection)', async () => {
    await service.log('user-123', 'VIEW_STUDENT_PROFILE');
    const savedPayload = mockRepository.save.mock.calls[0][0] as Record<string, unknown>;
    expect(savedPayload).not.toHaveProperty('name');
    expect(savedPayload).not.toHaveProperty('studentName');
    expect(savedPayload).not.toHaveProperty('grade');
    expect(savedPayload).not.toHaveProperty('score');
  });

  it('should not log student name fields to console (PII protection)', async () => {
    await service.log('user-123', 'VIEW_STUDENT_PROFILE');
    const logMessage = logSpy.mock.calls[0][0] as string;
    expect(logMessage).not.toMatch(/name=/i);
    expect(logMessage).not.toMatch(/studentName=/i);
  });

  it('should not log grade fields to console (PII protection)', async () => {
    await service.log('user-123', 'VIEW_GRADES');
    const logMessage = logSpy.mock.calls[0][0] as string;
    expect(logMessage).not.toMatch(/grade=/i);
    expect(logMessage).not.toMatch(/score=/i);
  });

  it('should call logger exactly once per log() call', async () => {
    await service.log('user-123', 'VIEW_STUDENT_PROFILE');
    expect(logSpy).toHaveBeenCalledTimes(1);
  });

  it('should call repository.save exactly once per log() call', async () => {
    await service.log('user-123', 'VIEW_STUDENT_PROFILE');
    expect(mockRepository.save).toHaveBeenCalledTimes(1);
  });
});
