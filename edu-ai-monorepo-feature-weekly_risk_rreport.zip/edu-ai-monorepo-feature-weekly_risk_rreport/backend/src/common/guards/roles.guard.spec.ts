import { ExecutionContext, ForbiddenException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Test, TestingModule } from '@nestjs/testing';
import { RolesGuard } from './roles.guard';
import { Role } from '../enums/role.enum';
import { ROLES_KEY } from '../decorators/roles.decorator';

function buildContext(
  userRoles: string[],
  requiredRoles: Role[] | undefined,
): ExecutionContext {
  return {
    getHandler: () => ({}),
    getClass: () => ({}),
    switchToHttp: () => ({
      getRequest: () => ({ user: { sub: 'auth0|user-1', roles: userRoles } }),
    }),
  } as unknown as ExecutionContext;
}

describe('RolesGuard', () => {
  let guard: RolesGuard;
  let reflector: Reflector;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [RolesGuard, Reflector],
    }).compile();

    guard = module.get<RolesGuard>(RolesGuard);
    reflector = module.get<Reflector>(Reflector);
  });

  it('should be defined', () => {
    expect(guard).toBeDefined();
  });

  it('should allow access when no @Roles() decorator is set', () => {
    jest.spyOn(reflector, 'getAllAndOverride').mockReturnValue(undefined);
    const ctx = buildContext([], undefined);
    expect(guard.canActivate(ctx)).toBe(true);
  });

  it('should allow admin to access any endpoint', () => {
    jest
      .spyOn(reflector, 'getAllAndOverride')
      .mockReturnValue([Role.ADMIN, Role.COUNSELOR]);
    const ctx = buildContext([Role.ADMIN], [Role.ADMIN, Role.COUNSELOR]);
    expect(guard.canActivate(ctx)).toBe(true);
  });

  it('should allow counselor to access risk-report endpoint', () => {
    jest
      .spyOn(reflector, 'getAllAndOverride')
      .mockReturnValue([Role.ADMIN, Role.COUNSELOR]);
    const ctx = buildContext([Role.COUNSELOR], [Role.ADMIN, Role.COUNSELOR]);
    expect(guard.canActivate(ctx)).toBe(true);
  });

  it('should deny teacher access to risk-report endpoint', () => {
    jest
      .spyOn(reflector, 'getAllAndOverride')
      .mockReturnValue([Role.ADMIN, Role.COUNSELOR]);
    const ctx = buildContext([Role.TEACHER], [Role.ADMIN, Role.COUNSELOR]);
    expect(() => guard.canActivate(ctx)).toThrow(ForbiddenException);
  });

  it('should deny staff access to risk-report endpoint', () => {
    jest
      .spyOn(reflector, 'getAllAndOverride')
      .mockReturnValue([Role.ADMIN, Role.COUNSELOR]);
    const ctx = buildContext([Role.STAFF], [Role.ADMIN, Role.COUNSELOR]);
    expect(() => guard.canActivate(ctx)).toThrow(ForbiddenException);
  });

  it('should deny teacher access to student-profile endpoint', () => {
    jest
      .spyOn(reflector, 'getAllAndOverride')
      .mockReturnValue([Role.ADMIN, Role.COUNSELOR]);
    const ctx = buildContext([Role.TEACHER], [Role.ADMIN, Role.COUNSELOR]);
    expect(() => guard.canActivate(ctx)).toThrow(ForbiddenException);
  });

  it('should allow teacher to access chatbot endpoint', () => {
    jest
      .spyOn(reflector, 'getAllAndOverride')
      .mockReturnValue([Role.ADMIN, Role.TEACHER, Role.STAFF]);
    const ctx = buildContext(
      [Role.TEACHER],
      [Role.ADMIN, Role.TEACHER, Role.STAFF],
    );
    expect(guard.canActivate(ctx)).toBe(true);
  });

  it('should allow staff to access chatbot endpoint', () => {
    jest
      .spyOn(reflector, 'getAllAndOverride')
      .mockReturnValue([Role.ADMIN, Role.TEACHER, Role.STAFF]);
    const ctx = buildContext(
      [Role.STAFF],
      [Role.ADMIN, Role.TEACHER, Role.STAFF],
    );
    expect(guard.canActivate(ctx)).toBe(true);
  });

  it('should deny staff access to dashboard endpoint', () => {
    jest
      .spyOn(reflector, 'getAllAndOverride')
      .mockReturnValue([Role.ADMIN, Role.TEACHER]);
    const ctx = buildContext([Role.STAFF], [Role.ADMIN, Role.TEACHER]);
    expect(() => guard.canActivate(ctx)).toThrow(ForbiddenException);
  });

  it('should deny counselor access to chatbot endpoint', () => {
    jest
      .spyOn(reflector, 'getAllAndOverride')
      .mockReturnValue([Role.ADMIN, Role.TEACHER, Role.STAFF]);
    const ctx = buildContext(
      [Role.COUNSELOR],
      [Role.ADMIN, Role.TEACHER, Role.STAFF],
    );
    expect(() => guard.canActivate(ctx)).toThrow(ForbiddenException);
  });

  it('should throw ForbiddenException when user has no roles at all', () => {
    jest
      .spyOn(reflector, 'getAllAndOverride')
      .mockReturnValue([Role.ADMIN]);
    const ctx = {
      getHandler: () => ({}),
      getClass: () => ({}),
      switchToHttp: () => ({
        getRequest: () => ({ user: { sub: 'auth0|no-role', roles: [] } }),
      }),
    } as unknown as ExecutionContext;
    expect(() => guard.canActivate(ctx)).toThrow(ForbiddenException);
  });

  it('should return 403 message indicating required roles', () => {
    jest
      .spyOn(reflector, 'getAllAndOverride')
      .mockReturnValue([Role.ADMIN, Role.COUNSELOR]);
    const ctx = buildContext([Role.TEACHER], [Role.ADMIN, Role.COUNSELOR]);
    expect(() => guard.canActivate(ctx)).toThrow(
      expect.objectContaining({ message: expect.stringContaining('admin') }),
    );
  });
});
