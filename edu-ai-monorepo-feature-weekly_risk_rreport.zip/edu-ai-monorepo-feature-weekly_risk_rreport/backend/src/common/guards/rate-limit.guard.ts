import {
  Injectable,
  CanActivate,
  ExecutionContext,
  HttpException,
  HttpStatus,
} from '@nestjs/common';
import { Request } from 'express';

/** Maximum requests allowed per window per IP. */
const MAX_REQUESTS = 100;

/** Rolling window duration in milliseconds (1 minute). */
const WINDOW_MS = 60_000;

interface RateLimitEntry {
  count: number;
  windowStart: number;
}

/**
 * Guard that enforces IP-based rate limiting using an in-memory sliding window.
 *
 * Each unique IP is allowed up to MAX_REQUESTS requests within WINDOW_MS.
 * Exceeding the limit returns HTTP 429 Too Many Requests.
 *
 * Note: For multi-instance deployments, replace with a Redis-backed solution.
 */
@Injectable()
export class RateLimitGuard implements CanActivate {
  private readonly ipMap = new Map<string, RateLimitEntry>();

  /**
   * Checks and updates the request count for the calling IP.
   * @param context - NestJS execution context
   * @returns true when under the rate limit; throws 429 otherwise
   */
  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest<Request>();
    const ip = request.ip ?? 'unknown';
    const now = Date.now();

    const entry = this.ipMap.get(ip);

    if (!entry || now - entry.windowStart > WINDOW_MS) {
      this.ipMap.set(ip, { count: 1, windowStart: now });
      return true;
    }

    if (entry.count >= MAX_REQUESTS) {
      throw new HttpException(
        'Too many requests – please wait before retrying',
        HttpStatus.TOO_MANY_REQUESTS,
      );
    }

    entry.count += 1;
    return true;
  }
}
