import {
  Injectable,
  CanActivate,
  ExecutionContext,
  UnauthorizedException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { Request } from 'express';

/**
 * Shape of the JWT payload issued by Auth0.
 * Roles are stored as a custom claim.
 */
export interface JwtPayload {
  /** Auth0 user ID (e.g. "auth0|abc123") */
  sub: string;
  /** Array of role strings assigned to the user (e.g. ["admin", "teacher"]) */
  roles: string[];
  iat?: number;
  exp?: number;
}

/**
 * Guard that validates the Auth0 JWT present in the Authorization header.
 * Attaches the decoded payload to `request.user` for downstream use.
 *
 * Throws UnauthorizedException when:
 * - No Authorization header is present
 * - Token is malformed, expired, or has an invalid signature
 */
@Injectable()
export class Auth0JwtGuard implements CanActivate {
  constructor(private readonly jwtService: JwtService) {}

  /**
   * Extracts and verifies the Bearer token from the request.
   * @param context - NestJS execution context
   * @returns true when the token is valid; throws otherwise
   */
  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest<Request>();
    const token = this.extractToken(request);

    if (!token) {
      throw new UnauthorizedException('Missing authentication token');
    }

    try {
      const payload = this.jwtService.verify<JwtPayload>(token);
      request['user'] = payload;
      return true;
    } catch {
      throw new UnauthorizedException('Invalid or expired authentication token');
    }
  }

  /**
   * Parses the "Bearer <token>" Authorization header.
   * @param request - The incoming HTTP request
   * @returns The raw JWT string, or undefined if not present
   */
  private extractToken(request: Request): string | undefined {
    const authHeader = request.headers.authorization;
    const [type, token] = authHeader?.split(' ') ?? [];
    return type === 'Bearer' ? token : undefined;
  }
}
