import { ExecutionContext, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { Test, TestingModule } from '@nestjs/testing';
import { Auth0JwtGuard, JwtPayload } from './auth0-jwt.guard';

const VALID_PAYLOAD: JwtPayload = {
  sub: 'auth0|test-user-123',
  roles: ['teacher'],
};

function buildContext(authHeader?: string): ExecutionContext {
  return {
    switchToHttp: () => ({
      getRequest: () => ({
        headers: { authorization: authHeader },
      }),
    }),
  } as unknown as ExecutionContext;
}

describe('Auth0JwtGuard', () => {
  let guard: Auth0JwtGuard;
  let jwtService: JwtService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        Auth0JwtGuard,
        {
          provide: JwtService,
          useValue: { verify: jest.fn() },
        },
      ],
    }).compile();

    guard = module.get<Auth0JwtGuard>(Auth0JwtGuard);
    jwtService = module.get<JwtService>(JwtService);
  });

  it('should be defined', () => {
    expect(guard).toBeDefined();
  });

  it('should throw UnauthorizedException when Authorization header is missing', () => {
    const ctx = buildContext(undefined);
    expect(() => guard.canActivate(ctx)).toThrow(UnauthorizedException);
  });

  it('should throw UnauthorizedException when Authorization is not Bearer type', () => {
    const ctx = buildContext('Basic dXNlcjpwYXNz');
    expect(() => guard.canActivate(ctx)).toThrow(UnauthorizedException);
  });

  it('should throw UnauthorizedException when JWT verification fails', () => {
    jest.spyOn(jwtService, 'verify').mockImplementation(() => {
      throw new Error('invalid signature');
    });
    const ctx = buildContext('Bearer invalid.token.here');
    expect(() => guard.canActivate(ctx)).toThrow(UnauthorizedException);
  });

  it('should return true and attach user when token is valid', () => {
    jest.spyOn(jwtService, 'verify').mockReturnValue(VALID_PAYLOAD);
    const request = { headers: { authorization: 'Bearer valid.token' } };
    const ctx = {
      switchToHttp: () => ({ getRequest: () => request }),
    } as unknown as ExecutionContext;

    const result = guard.canActivate(ctx);

    expect(result).toBe(true);
    expect(request['user']).toEqual(VALID_PAYLOAD);
  });

  it('should extract userId (sub) from valid token payload', () => {
    jest.spyOn(jwtService, 'verify').mockReturnValue(VALID_PAYLOAD);
    const request = { headers: { authorization: 'Bearer valid.token' } };
    const ctx = {
      switchToHttp: () => ({ getRequest: () => request }),
    } as unknown as ExecutionContext;

    guard.canActivate(ctx);

    expect((request['user'] as JwtPayload).sub).toBe('auth0|test-user-123');
  });
});
