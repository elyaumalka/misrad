import { ExecutionContext, HttpException, HttpStatus } from '@nestjs/common';
import { RateLimitGuard } from './rate-limit.guard';

function buildContext(ip: string): ExecutionContext {
  return {
    switchToHttp: () => ({
      getRequest: () => ({ ip }),
    }),
  } as unknown as ExecutionContext;
}

describe('RateLimitGuard', () => {
  let guard: RateLimitGuard;

  beforeEach(() => {
    guard = new RateLimitGuard();
  });

  it('should be defined', () => {
    expect(guard).toBeDefined();
  });

  it('should allow the first request from an IP', () => {
    const ctx = buildContext('10.0.0.1');
    expect(guard.canActivate(ctx)).toBe(true);
  });

  it('should allow requests up to the limit', () => {
    const ctx = buildContext('10.0.0.2');
    for (let i = 0; i < 100; i++) {
      expect(guard.canActivate(ctx)).toBe(true);
    }
  });

  it('should throw HttpException 429 when limit is exceeded', () => {
    const ctx = buildContext('10.0.0.3');
    for (let i = 0; i < 100; i++) {
      guard.canActivate(ctx);
    }
    expect(() => guard.canActivate(ctx)).toThrow(HttpException);
  });

  it('should return status 429 on the exceeded request', () => {
    const ctx = buildContext('10.0.0.4');
    for (let i = 0; i < 100; i++) {
      guard.canActivate(ctx);
    }

    let caught: HttpException | undefined;
    try {
      guard.canActivate(ctx);
    } catch (e) {
      caught = e as HttpException;
    }

    expect(caught).toBeInstanceOf(HttpException);
    expect(caught?.getStatus()).toBe(HttpStatus.TOO_MANY_REQUESTS);
  });

  it('should track limits per IP independently', () => {
    const ctx1 = buildContext('10.0.0.5');
    const ctx2 = buildContext('10.0.0.6');

    for (let i = 0; i < 100; i++) {
      guard.canActivate(ctx1);
    }

    expect(() => guard.canActivate(ctx2)).not.toThrow();
  });
});
