import { SetMetadata } from '@nestjs/common';
import { Role } from '../enums/role.enum';

/** Metadata key used by RolesGuard to read required roles. */
export const ROLES_KEY = 'roles';

/**
 * Decorator that specifies which roles are allowed to access an endpoint.
 * Applied at the controller class or individual handler method level.
 *
 * @param roles - One or more Role values that are permitted
 *
 * @example
 * \@Roles(Role.ADMIN, Role.COUNSELOR)
 * \@Get()
 * findAll() { ... }
 */
export const Roles = (...roles: Role[]) => SetMetadata(ROLES_KEY, roles);
