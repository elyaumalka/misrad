import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { AuditLog } from './common/entities/audit-log.entity';
import { ChatbotModule } from './modules/chatbot/chatbot.module';
import { DashboardModule } from './modules/dashboard/dashboard.module';
import { RiskReportModule } from './modules/risk-report/risk-report.module';
import { ReportGeneratorModule } from './modules/report-generator/report-generator.module';
import { StudentProfileModule } from './modules/student-profile/student-profile.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        type: 'postgres',
        host: config.get<string>('DB_HOST', 'localhost'),
        port: config.get<number>('DB_PORT', 5432),
        username: config.get<string>('DB_USER', 'postgres'),
        password: config.get<string>('DB_PASSWORD', ''),
        database: config.get<string>('DB_NAME', 'school_platform'),
        entities: [AuditLog],
        synchronize: config.get<string>('NODE_ENV') !== 'production',
      }),
    }),
    ChatbotModule,
    DashboardModule,
    RiskReportModule,
    ReportGeneratorModule,
    StudentProfileModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
