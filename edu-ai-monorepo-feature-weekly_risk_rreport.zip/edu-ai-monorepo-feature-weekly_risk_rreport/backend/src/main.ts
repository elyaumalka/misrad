import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // Remove server fingerprinting header that reveals the framework
  app.getHttpAdapter().getInstance().disable('x-powered-by');

  // Global input validation:
  // - whitelist: strips properties not defined in DTOs (prevents mass-assignment)
  // - forbidNonWhitelisted: rejects requests with unknown properties instead of silently stripping
  // - transform: auto-converts primitives to declared TS types
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
    }),
  );

  // CORS: allow only known origins.
  // CORS_ORIGIN env var accepts a comma-separated list (e.g. "https://app.example.com").
  // In production with no CORS_ORIGIN set: same-origin only (false).
  // In development: Angular dev server on localhost:4200 is allowed.
  const corsOrigin = process.env.CORS_ORIGIN
    ? process.env.CORS_ORIGIN.split(',').map((o) => o.trim())
    : process.env.NODE_ENV === 'production'
      ? false
      : ['http://localhost:4200'];

  app.enableCors({ origin: corsOrigin });

  await app.listen(process.env.PORT ?? 3000);
}
bootstrap();
