import { Controller, Get, UseGuards } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { DashboardService } from './dashboard.service';
import { Auth0JwtGuard } from '../../common/guards/auth0-jwt.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { RateLimitGuard } from '../../common/guards/rate-limit.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { Role } from '../../common/enums/role.enum';

/**
 * Handles dashboard-related API requests (class data, charts, weekly summaries).
 * Access: admin, teacher.
 * Counselors and staff do not have access to this module.
 */
@ApiTags('dashboard')
@Controller('dashboard')
@UseGuards(Auth0JwtGuard, RolesGuard, RateLimitGuard)
@Roles(Role.ADMIN, Role.TEACHER)
export class DashboardController {
  constructor(private readonly service: DashboardService) {}

  /** Returns dashboard data visible to the authenticated user. */
  @Get()
  findAll() {
    return this.service.findAll();
  }
}
