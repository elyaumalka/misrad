import { Controller, Get, UseGuards, Request } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { StudentProfileService } from './student-profile.service';
import { Auth0JwtGuard, JwtPayload } from '../../common/guards/auth0-jwt.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { RateLimitGuard } from '../../common/guards/rate-limit.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { Role } from '../../common/enums/role.enum';
import { AuditLogService } from '../../common/services/audit-log.service';

/** Constant action label used in audit log entries for this endpoint. */
const ACTION_VIEW_STUDENT_PROFILE = 'VIEW_STUDENT_PROFILE';

/**
 * Handles student-profile API requests.
 * Access: admin, counselor ONLY. Teachers and staff are explicitly denied (403).
 *
 * Every access is written to the audit log (userId only — no student names or PII).
 */
@ApiTags('student-profile')
@Controller('student-profile')
@UseGuards(Auth0JwtGuard, RolesGuard, RateLimitGuard)
@Roles(Role.ADMIN, Role.COUNSELOR)
export class StudentProfileController {
  constructor(
    private readonly service: StudentProfileService,
    private readonly auditLogService: AuditLogService,
  ) {}

  /**
   * Returns student profile data.
   * Writes an audit log entry on every successful access.
   */
  @Get()
  async findAll(@Request() req: { user: JwtPayload }) {
    await this.auditLogService.log(req.user.sub, ACTION_VIEW_STUDENT_PROFILE);
    return this.service.findAll();
  }
}
