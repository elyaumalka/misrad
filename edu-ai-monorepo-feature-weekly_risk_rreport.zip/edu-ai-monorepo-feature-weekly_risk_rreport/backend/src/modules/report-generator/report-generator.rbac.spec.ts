import { Test, TestingModule } from '@nestjs/testing';
import { ExecutionContext, ForbiddenException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Role } from '../../common/enums/role.enum';

/**
 * RBAC unit tests for the /report-generator endpoint.
 *
 * Rule: admin and teacher may access the report generator.
 * Staff must receive HTTP 403 Forbidden.
 */
describe('ReportGenerator RBAC', () => {
  let guard: RolesGuard;
  let reflector: Reflector;

  const REQUIRED_ROLES = [Role.ADMIN, Role.TEACHER];

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [RolesGuard, Reflector],
    }).compile();

    guard = module.get<RolesGuard>(RolesGuard);
    reflector = module.get<Reflector>(Reflector);

    jest
      .spyOn(reflector, 'getAllAndOverride')
      .mockReturnValue(REQUIRED_ROLES);
  });

  function buildContext(roles: Role[]): ExecutionContext {
    return {
      getHandler: () => ({}),
      getClass: () => ({}),
      switchToHttp: () => ({
        getRequest: () => ({ user: { sub: 'auth0|test', roles } }),
      }),
    } as unknown as ExecutionContext;
  }

  it('admin should access report-generator (200)', () => {
    expect(guard.canActivate(buildContext([Role.ADMIN]))).toBe(true);
  });

  it('teacher should access report-generator (200)', () => {
    expect(guard.canActivate(buildContext([Role.TEACHER]))).toBe(true);
  });

  it('staff should NOT access report-generator (403)', () => {
    expect(() => guard.canActivate(buildContext([Role.STAFF]))).toThrow(
      ForbiddenException,
    );
  });
});
