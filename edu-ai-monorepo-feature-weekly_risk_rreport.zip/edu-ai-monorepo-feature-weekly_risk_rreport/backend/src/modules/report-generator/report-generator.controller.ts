import { Controller, Get, UseGuards } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { ReportGeneratorService } from './report-generator.service';
import { Auth0JwtGuard } from '../../common/guards/auth0-jwt.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { RateLimitGuard } from '../../common/guards/rate-limit.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { Role } from '../../common/enums/role.enum';

/**
 * Handles report-generator API requests (PDF processing, questionnaires).
 * Access: admin, teacher.
 * Staff do not have access to this module.
 */
@ApiTags('report-generator')
@Controller('report-generator')
@UseGuards(Auth0JwtGuard, RolesGuard, RateLimitGuard)
@Roles(Role.ADMIN, Role.TEACHER)
export class ReportGeneratorController {
  constructor(private readonly service: ReportGeneratorService) {}

  /** Returns generated reports visible to the authenticated user. */
  @Get()
  findAll() {
    return this.service.findAll();
  }
}
