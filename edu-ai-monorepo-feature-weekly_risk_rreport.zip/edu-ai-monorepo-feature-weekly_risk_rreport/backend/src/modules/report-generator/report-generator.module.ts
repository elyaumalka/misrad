import { Module } from '@nestjs/common';
import { ReportGeneratorController } from './report-generator.controller';
import { ReportGeneratorService } from './report-generator.service';
import { SecurityModule } from '../../common/security.module';

@Module({
  imports: [SecurityModule],
  controllers: [ReportGeneratorController],
  providers: [ReportGeneratorService],
  exports: [ReportGeneratorService],
})
export class ReportGeneratorModule {}
