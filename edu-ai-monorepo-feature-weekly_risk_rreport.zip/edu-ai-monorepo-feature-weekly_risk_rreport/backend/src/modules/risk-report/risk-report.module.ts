import { Module } from '@nestjs/common';
import { RiskReportController } from './risk-report.controller';
import { RiskReportService } from './risk-report.service';
import { SecurityModule } from '../../common/security.module';

@Module({
  imports: [SecurityModule],
  controllers: [RiskReportController],
  providers: [RiskReportService],
  exports: [RiskReportService],
})
export class RiskReportModule {}
