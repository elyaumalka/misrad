import { Test, TestingModule } from '@nestjs/testing';
import { ExecutionContext, ForbiddenException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Role } from '../../common/enums/role.enum';

/**
 * RBAC unit tests for the /risk-report endpoint.
 *
 * Rule: only admin and counselor may access this endpoint.
 * Teachers and staff must receive HTTP 403 Forbidden.
 */
describe('RiskReport RBAC', () => {
  let guard: RolesGuard;
  let reflector: Reflector;

  const REQUIRED_ROLES = [Role.ADMIN, Role.COUNSELOR];

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [RolesGuard, Reflector],
    }).compile();

    guard = module.get<RolesGuard>(RolesGuard);
    reflector = module.get<Reflector>(Reflector);

    jest
      .spyOn(reflector, 'getAllAndOverride')
      .mockReturnValue(REQUIRED_ROLES);
  });

  function buildContext(roles: Role[]): ExecutionContext {
    return {
      getHandler: () => ({}),
      getClass: () => ({}),
      switchToHttp: () => ({
        getRequest: () => ({ user: { sub: 'auth0|test', roles } }),
      }),
    } as unknown as ExecutionContext;
  }

  it('admin should access risk-report (200)', () => {
    expect(guard.canActivate(buildContext([Role.ADMIN]))).toBe(true);
  });

  it('counselor should access risk-report (200)', () => {
    expect(guard.canActivate(buildContext([Role.COUNSELOR]))).toBe(true);
  });

  it('teacher should NOT access risk-report (403)', () => {
    expect(() => guard.canActivate(buildContext([Role.TEACHER]))).toThrow(
      ForbiddenException,
    );
  });

  it('staff should NOT access risk-report (403)', () => {
    expect(() => guard.canActivate(buildContext([Role.STAFF]))).toThrow(
      ForbiddenException,
    );
  });
});
