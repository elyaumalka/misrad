import { Controller, Get, UseGuards, Request } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { RiskReportService } from './risk-report.service';
import { Auth0JwtGuard, JwtPayload } from '../../common/guards/auth0-jwt.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { RateLimitGuard } from '../../common/guards/rate-limit.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { Role } from '../../common/enums/role.enum';
import { AuditLogService } from '../../common/services/audit-log.service';

/** Constant action label used in audit log entries for this endpoint. */
const ACTION_VIEW_RISK_REPORT = 'VIEW_RISK_REPORT';

/**
 * Handles risk-report API requests.
 * Access: admin, counselor ONLY. Teachers and staff are explicitly denied (403).
 *
 * Every access to this endpoint is written to the audit log (userId + timestamp).
 * No PII is stored in the log.
 */
@ApiTags('risk-report')
@Controller('risk-report')
@UseGuards(Auth0JwtGuard, RolesGuard, RateLimitGuard)
@Roles(Role.ADMIN, Role.COUNSELOR)
export class RiskReportController {
  constructor(
    private readonly service: RiskReportService,
    private readonly auditLogService: AuditLogService,
  ) {}

  /**
   * Returns the weekly risk report.
   * Writes an audit log entry on every successful access.
   */
  @Get()
  async findAll(@Request() req: { user: JwtPayload }) {
    await this.auditLogService.log(req.user.sub, ACTION_VIEW_RISK_REPORT);
    return this.service.findAll();
  }
}
