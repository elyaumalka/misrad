import { Controller, Get, UseGuards } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { ChatbotService } from './chatbot.service';
import { Auth0JwtGuard } from '../../common/guards/auth0-jwt.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { RateLimitGuard } from '../../common/guards/rate-limit.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { Role } from '../../common/enums/role.enum';

/**
 * Handles chatbot-related API requests.
 * Access: admin, teacher, staff.
 * Counselors do not have access to this module.
 */
@ApiTags('chatbot')
@Controller('chatbot')
@UseGuards(Auth0JwtGuard, RolesGuard, RateLimitGuard)
@Roles(Role.ADMIN, Role.TEACHER, Role.STAFF)
export class ChatbotController {
  constructor(private readonly service: ChatbotService) {}

  /** Returns all chatbot sessions visible to the authenticated user. */
  @Get()
  findAll() {
    return this.service.findAll();
  }
}
