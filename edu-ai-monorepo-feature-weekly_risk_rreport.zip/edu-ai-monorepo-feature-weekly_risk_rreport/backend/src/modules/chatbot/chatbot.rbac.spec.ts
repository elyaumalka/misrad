import { Test, TestingModule } from '@nestjs/testing';
import { ExecutionContext, ForbiddenException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Role } from '../../common/enums/role.enum';

/**
 * RBAC unit tests for the /chatbot endpoint.
 *
 * Rule: admin, teacher, and staff may access chatbot.
 * Counselors must receive HTTP 403 Forbidden.
 */
describe('Chatbot RBAC', () => {
  let guard: RolesGuard;
  let reflector: Reflector;

  const REQUIRED_ROLES = [Role.ADMIN, Role.TEACHER, Role.STAFF];

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [RolesGuard, Reflector],
    }).compile();

    guard = module.get<RolesGuard>(RolesGuard);
    reflector = module.get<Reflector>(Reflector);

    jest
      .spyOn(reflector, 'getAllAndOverride')
      .mockReturnValue(REQUIRED_ROLES);
  });

  function buildContext(roles: Role[]): ExecutionContext {
    return {
      getHandler: () => ({}),
      getClass: () => ({}),
      switchToHttp: () => ({
        getRequest: () => ({ user: { sub: 'auth0|test', roles } }),
      }),
    } as unknown as ExecutionContext;
  }

  it('admin should access chatbot (200)', () => {
    expect(guard.canActivate(buildContext([Role.ADMIN]))).toBe(true);
  });

  it('teacher should access chatbot (200)', () => {
    expect(guard.canActivate(buildContext([Role.TEACHER]))).toBe(true);
  });

  it('staff should access chatbot (200)', () => {
    expect(guard.canActivate(buildContext([Role.STAFF]))).toBe(true);
  });

  it('counselor should NOT access chatbot (403)', () => {
    expect(() => guard.canActivate(buildContext([Role.COUNSELOR]))).toThrow(
      ForbiddenException,
    );
  });
});
