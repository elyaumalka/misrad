import { Controller, Get } from '@nestjs/common';

/**
 * Root controller exposing a public health-check endpoint.
 *
 * GET / is intentionally unauthenticated — it is used by the GCP load balancer
 * to verify the service is alive. It returns no user data and no PII.
 * All other endpoints require Auth0 JWT authentication.
 */
@Controller()
export class AppController {
  /** Public health-check — returns HTTP 200 when the service is running. */
  @Get()
  healthCheck(): { status: string } {
    return { status: 'ok' };
  }
}
