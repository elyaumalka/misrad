import { HttpExceptionFilter, ApiErrorResponse } from './http-exception.filter';
import {
  HttpException,
  HttpStatus,
  UnauthorizedException,
  ForbiddenException,
  BadRequestException,
} from '@nestjs/common';
import { ArgumentsHost } from '@nestjs/common';

/** Builds a mock ArgumentsHost that captures the JSON response. */
function buildMockHost(url = '/test'): {
  host: ArgumentsHost;
  getJson: () => ApiErrorResponse;
} {
  let capturedJson: ApiErrorResponse;

  const mockResponse = {
    status: jest.fn().mockReturnThis(),
    json: jest.fn().mockImplementation((body: ApiErrorResponse) => {
      capturedJson = body;
    }),
  };

  const mockRequest = { url, method: 'GET' };

  const host = {
    switchToHttp: () => ({
      getResponse: () => mockResponse,
      getRequest: () => mockRequest,
    }),
  } as unknown as ArgumentsHost;

  return { host, getJson: () => capturedJson };
}

describe('HttpExceptionFilter', () => {
  let filter: HttpExceptionFilter;

  beforeEach(() => {
    filter = new HttpExceptionFilter();
  });

  describe('HttpException handling', () => {
    it('returns 401 with clean message for UnauthorizedException', () => {
      const { host, getJson } = buildMockHost('/protected');
      filter.catch(new UnauthorizedException('Missing authentication token'), host);

      const body = getJson();
      expect(body.statusCode).toBe(HttpStatus.UNAUTHORIZED);
      expect(body.message).toBe('Missing authentication token');
      expect(body.path).toBe('/protected');
      expect(body.timestamp).toBeDefined();
    });

    it('returns 403 with clean message for ForbiddenException', () => {
      const { host, getJson } = buildMockHost('/risk-report');
      filter.catch(new ForbiddenException('Access denied: no roles assigned to user'), host);

      const body = getJson();
      expect(body.statusCode).toBe(HttpStatus.FORBIDDEN);
      expect(body.message).toBe('Access denied: no roles assigned to user');
    });

    it('joins ValidationPipe array messages into a single string', () => {
      const { host, getJson } = buildMockHost('/upload');
      const exception = new BadRequestException({
        message: ['file must be a pdf', 'file size must not exceed 5MB'],
        error: 'Bad Request',
        statusCode: 400,
      });
      filter.catch(exception, host);

      const body = getJson();
      expect(body.statusCode).toBe(HttpStatus.BAD_REQUEST);
      expect(body.message).toBe('file must be a pdf; file size must not exceed 5MB');
    });
  });

  describe('Unknown error handling', () => {
    it('returns 500 with generic message for unexpected Error — no internals leaked', () => {
      const { host, getJson } = buildMockHost('/students');
      const rawError = new Error('SELECT * FROM students WHERE id = 42 — column "ssn" does not exist');
      filter.catch(rawError, host);

      const body = getJson();
      expect(body.statusCode).toBe(HttpStatus.INTERNAL_SERVER_ERROR);
      expect(body.message).toBe('An unexpected error occurred. Please try again later.');
      // The raw DB error must NOT appear in the response
      expect(body.message).not.toContain('SELECT');
      expect(body.message).not.toContain('ssn');
    });

    it('returns 500 for non-Error throws', () => {
      const { host, getJson } = buildMockHost('/');
      filter.catch('something broke', host);

      const body = getJson();
      expect(body.statusCode).toBe(HttpStatus.INTERNAL_SERVER_ERROR);
    });

    it('response body never contains a stack trace', () => {
      const { host, getJson } = buildMockHost('/');
      filter.catch(new Error('boom'), host);

      const body = getJson();
      expect(JSON.stringify(body)).not.toContain('at ');
    });
  });

  describe('Response shape', () => {
    it('always includes statusCode, message, timestamp, and path', () => {
      const { host, getJson } = buildMockHost('/chatbot');
      filter.catch(new HttpException('test', HttpStatus.NOT_FOUND), host);

      const body = getJson();
      expect(body).toHaveProperty('statusCode');
      expect(body).toHaveProperty('message');
      expect(body).toHaveProperty('timestamp');
      expect(body).toHaveProperty('path');
    });
  });
});
