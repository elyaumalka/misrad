import {
  ExceptionFilter,
  Catch,
  ArgumentsHost,
  HttpException,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import { Request, Response } from 'express';

/**
 * Standard error response shape returned by every endpoint in the system.
 * No stack traces, no raw ORM errors, no PII.
 */
export interface ApiErrorResponse {
  statusCode: number;
  message: string;
  timestamp: string;
  path: string;
}

/**
 * Global exception filter that intercepts all unhandled exceptions and formats
 * them into a consistent ApiErrorResponse.
 *
 * Security guarantees:
 * - Stack traces are never included in the response body.
 * - Raw TypeORM / database errors are replaced with a generic 500 message.
 * - The original error is logged server-side (without PII) for diagnostics.
 * - Non-HttpException errors (unexpected crashes) return HTTP 500 with a safe message.
 */
@Catch()
export class HttpExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger(HttpExceptionFilter.name);

  catch(exception: unknown, host: ArgumentsHost): void {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest<Request>();

    const { statusCode, message } = this.resolveError(exception);

    const body: ApiErrorResponse = {
      statusCode,
      message,
      timestamp: new Date().toISOString(),
      path: request.url,
    };

    // Log the real error server-side for diagnostics — never in the response.
    this.logger.error(
      `HTTP ${statusCode} | ${request.method} ${request.url} | ${this.safeErrorMessage(exception)}`,
    );

    response.status(statusCode).json(body);
  }

  /**
   * Maps the thrown exception to a safe status code and user-facing message.
   * HttpExceptions (401, 403, 429 …) preserve their message.
   * Everything else becomes a generic 500.
   */
  private resolveError(exception: unknown): {
    statusCode: number;
    message: string;
  } {
    if (exception instanceof HttpException) {
      const status = exception.getStatus();
      const exceptionResponse = exception.getResponse();

      // NestJS ValidationPipe wraps messages in an object { message: string[] }
      if (
        typeof exceptionResponse === 'object' &&
        exceptionResponse !== null &&
        'message' in exceptionResponse
      ) {
        const msg = (exceptionResponse as { message: unknown }).message;
        const safeMessage = Array.isArray(msg) ? msg.join('; ') : String(msg);
        return { statusCode: status, message: safeMessage };
      }

      return {
        statusCode: status,
        message:
          typeof exceptionResponse === 'string'
            ? exceptionResponse
            : exception.message,
      };
    }

    // Unknown / unexpected error (e.g. raw TypeORM crash) — never leak internals.
    return {
      statusCode: HttpStatus.INTERNAL_SERVER_ERROR,
      message: 'An unexpected error occurred. Please try again later.',
    };
  }

  /**
   * Extracts a safe log message from the exception.
   * For unknown errors logs the constructor name — not the full message which
   * might contain SQL, file paths, or other sensitive internals.
   */
  private safeErrorMessage(exception: unknown): string {
    if (exception instanceof HttpException) {
      return exception.message;
    }
    if (exception instanceof Error) {
      // Log only the class name for unexpected errors — not the message body.
      return `[${exception.constructor.name}] (details hidden — check server logs)`;
    }
    return 'Unknown error';
  }
}
