import { Module } from '@nestjs/common';
import { ChatbotController } from './chatbot.controller';
import { ChatbotService } from './chatbot.service';
import { SecurityModule } from '../../common/security.module';
import { EmailBotService } from './channels/email/email-bot.service';

@Module({
  imports: [SecurityModule],
  controllers: [ChatbotController],
  providers: [ChatbotService, EmailBotService],
  exports: [ChatbotService],
})
export class ChatbotModule {}
