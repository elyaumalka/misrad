import { Test, TestingModule } from '@nestjs/testing';
import { ConfigService } from '@nestjs/config';
import { EmailBotService } from './email-bot.service';
import { ChatbotService } from '../../chatbot.service';

/** Minimal ConfigService mock — returns safe test values for all Gmail keys. */
const mockConfig = {
  get: jest.fn((key: string, defaultVal = '') => {
    const values: Record<string, string> = {
      GMAIL_CLIENT_ID: 'test-client-id',
      GMAIL_CLIENT_SECRET: 'test-client-secret',
      GMAIL_REFRESH_TOKEN: 'test-refresh-token',
      ALLOWED_EMAIL_DOMAINS: 'school.edu,district.org',
    };
    return values[key] ?? defaultVal;
  }),
};

/** Minimal ChatbotService mock. */
const mockChatbot = { query: jest.fn() };

describe('EmailBotService', () => {
  let service: EmailBotService;

  beforeEach(async () => {
    jest.clearAllMocks();
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        EmailBotService,
        { provide: ConfigService, useValue: mockConfig },
        { provide: ChatbotService, useValue: mockChatbot },
      ],
    }).compile();

    service = module.get<EmailBotService>(EmailBotService);
  });

  // ─── validateSenderDomain ────────────────────────────────────────────────

  describe('validateSenderDomain', () => {
    it('accepts a plain address from an allowed domain', () => {
      expect(service.validateSenderDomain('teacher@school.edu')).toBe(true);
    });

    it('accepts a "Display Name <addr>" format from an allowed domain', () => {
      expect(service.validateSenderDomain('Jane Doe <jane@district.org>')).toBe(true);
    });

    it('rejects an address from an unknown domain', () => {
      expect(service.validateSenderDomain('attacker@gmail.com')).toBe(false);
    });

    it('rejects an address with no @ symbol', () => {
      expect(service.validateSenderDomain('notanemail')).toBe(false);
    });

    it('is case-insensitive on the domain part', () => {
      expect(service.validateSenderDomain('user@SCHOOL.EDU')).toBe(true);
    });
  });

  // ─── isRateLimited ───────────────────────────────────────────────────────

  describe('isRateLimited', () => {
    const email = 'sender@school.edu';

    it('allows the first email from a new sender', () => {
      expect(service.isRateLimited(email)).toBe(false);
    });

    it('allows up to 5 emails within the hour', () => {
      // Seed 4 recent timestamps directly via the private map
      const rateLimitMap: Map<string, number[]> = (service as unknown as { rateLimitMap: Map<string, number[]> }).rateLimitMap;
      rateLimitMap.set(email, [Date.now(), Date.now(), Date.now(), Date.now()]);

      expect(service.isRateLimited(email)).toBe(false);
    });

    it('blocks the 6th email within the same hour', () => {
      const rateLimitMap: Map<string, number[]> = (service as unknown as { rateLimitMap: Map<string, number[]> }).rateLimitMap;
      rateLimitMap.set(email, [
        Date.now(), Date.now(), Date.now(), Date.now(), Date.now(),
      ]);

      expect(service.isRateLimited(email)).toBe(true);
    });

    it('does not count timestamps older than one hour', () => {
      const rateLimitMap: Map<string, number[]> = (service as unknown as { rateLimitMap: Map<string, number[]> }).rateLimitMap;
      const twoHoursAgo = Date.now() - 2 * 60 * 60_000;
      // 5 expired timestamps — should all be evicted
      rateLimitMap.set(email, [
        twoHoursAgo, twoHoursAgo, twoHoursAgo, twoHoursAgo, twoHoursAgo,
      ]);

      expect(service.isRateLimited(email)).toBe(false);
    });
  });

  // ─── maskEmail ───────────────────────────────────────────────────────────

  describe('maskEmail', () => {
    it('masks all characters before the first letter of the local part', () => {
      expect(service.maskEmail('john.doe@school.edu')).toBe('j***@school.edu');
    });

    it('extracts the address from a "Display Name <addr>" string before masking', () => {
      expect(service.maskEmail('Jane Doe <jane@district.org>')).toBe('j***@district.org');
    });

    it('returns *** for a string with no @ symbol', () => {
      expect(service.maskEmail('notanemail')).toBe('***');
    });

    it('never exposes the full local part', () => {
      const masked = service.maskEmail('verylongname@school.edu');
      expect(masked).not.toContain('verylongname');
      expect(masked).toContain('@school.edu');
    });
  });
});
