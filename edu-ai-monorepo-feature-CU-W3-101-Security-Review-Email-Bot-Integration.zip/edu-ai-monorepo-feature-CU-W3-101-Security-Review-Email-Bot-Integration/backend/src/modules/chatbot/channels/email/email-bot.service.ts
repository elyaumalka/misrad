import {
  Injectable,
  Logger,
  OnModuleInit,
  OnModuleDestroy,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { google, gmail_v1 } from 'googleapis';
import { ChatbotService, RagResult } from '../../chatbot.service';

/** How often to poll the inbox for new messages (ms). */
const POLL_INTERVAL_MS = 60_000;

/** Maximum emails processed per sender per rolling hour. */
const MAX_EMAILS_PER_HOUR = 5;

/** Rolling window for rate-limit tracking (ms). */
const HOUR_MS = 60 * 60_000;

/** Maximum characters extracted from the email body for RAG. */
const MAX_BODY_CHARS = 4_000;

/** Reply sent when the RAG engine finds no matching document. */
const FALLBACK_MESSAGE =
  'The information was not found in the documents';

@Injectable()
export class EmailBotService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(EmailBotService.name);

  /** Stores timestamps of processed emails per sender for rate limiting. */
  private readonly rateLimitMap = new Map<string, number[]>();

  private readonly allowedDomains: string[];
  private readonly gmail: gmail_v1.Gmail;
  private pollTimer: NodeJS.Timeout | null = null;

  constructor(
    private readonly config: ConfigService,
    private readonly chatbotService: ChatbotService,
  ) {
    this.allowedDomains = this.resolveAllowedDomains();
    this.gmail = this.initGmailClient();
  }

  /** Starts the inbox polling loop on application startup. */
  onModuleInit(): void {
    this.logger.log(`Email bot started — polling every ${POLL_INTERVAL_MS / 1000}s`);
    this.pollTimer = setInterval(() => void this.checkInbox(), POLL_INTERVAL_MS);
  }

  /** Clears the polling interval on application shutdown. */
  onModuleDestroy(): void {
    if (this.pollTimer) clearInterval(this.pollTimer);
  }

  /**
   * Checks whether the sender's email domain is in the allowed school list.
   * @param email - Full sender address (may include display name)
   */
  validateSenderDomain(email: string): boolean {
    const address = this.extractAddress(email);
    const domain = address.split('@').at(1)?.toLowerCase() ?? '';
    return this.allowedDomains.includes(domain);
  }

  /**
   * Returns true when the sender has exceeded the per-hour email limit.
   * Also evicts expired timestamps from the in-memory map.
   * @param email - Raw sender address used as the rate-limit key
   */
  isRateLimited(email: string): boolean {
    const now = Date.now();
    const recent = (this.rateLimitMap.get(email) ?? []).filter(
      (t) => now - t < HOUR_MS,
    );
    this.rateLimitMap.set(email, recent);
    return recent.length >= MAX_EMAILS_PER_HOUR;
  }

  /**
   * Returns a masked version of the email address safe for logging.
   * e.g. "john.doe@school.edu" → "j***@school.edu"
   * @param email - Full or partial email address
   */
  maskEmail(email: string): string {
    const address = this.extractAddress(email);
    const atIndex = address.indexOf('@');
    if (atIndex <= 0) return '***';
    return `${address[0]}***${address.slice(atIndex)}`;
  }

  // ─── Private helpers ────────────────────────────────────────────────────────

  /** Reads ALLOWED_EMAIL_DOMAINS from env and returns a lowercase array. */
  private resolveAllowedDomains(): string[] {
    const raw = this.config.get<string>('ALLOWED_EMAIL_DOMAINS', '');
    if (!raw) {
      this.logger.warn('ALLOWED_EMAIL_DOMAINS is not set — all senders will be rejected');
    }
    return raw
      .split(',')
      .map((d) => d.trim().toLowerCase())
      .filter(Boolean);
  }

  /** Creates an authenticated Gmail API client from env credentials. */
  private initGmailClient(): gmail_v1.Gmail {
    const auth = new google.auth.OAuth2(
      this.config.get<string>('GMAIL_CLIENT_ID'),
      this.config.get<string>('GMAIL_CLIENT_SECRET'),
    );
    auth.setCredentials({
      refresh_token: this.config.get<string>('GMAIL_REFRESH_TOKEN'),
    });
    return google.gmail({ version: 'v1', auth });
  }

  /** Lists unread inbox messages and processes each one independently. */
  private async checkInbox(): Promise<void> {
    let messages: gmail_v1.Schema$Message[] = [];

    try {
      const res = await this.gmail.users.messages.list({
        userId: 'me',
        q: 'is:unread in:inbox',
        maxResults: 10,
      });
      messages = res.data.messages ?? [];
    } catch (err) {
      this.logger.error(
        `checkInbox list error: ${err instanceof Error ? err.constructor.name : 'unknown'}`,
      );
      return;
    }

    for (const msg of messages) {
      if (!msg.id) continue;
      try {
        await this.processEmail(msg.id);
      } catch (err) {
        // Log and continue — one failing message must not block the rest.
        this.logger.error(
          `processEmail failed: ${err instanceof Error ? err.constructor.name : 'unknown'}`,
        );
      }
    }
  }

  /**
   * Full processing pipeline for a single email message:
   * fetch → mark read → validate → rate limit → RAG → reply.
   */
  private async processEmail(messageId: string): Promise<void> {
    const msg = await this.gmail.users.messages.get({
      userId: 'me',
      id: messageId,
      format: 'full',
    });

    const headers = msg.data.payload?.headers ?? [];
    const sender = this.getHeader(headers, 'From') ?? '';
    const subject = this.getHeader(headers, 'Subject') ?? '';
    const threadId = msg.data.threadId ?? messageId;

    await this.markAsRead(messageId);

    if (!sender || !this.validateSenderDomain(sender)) {
      this.logger.log(`Rejected — unauthorized domain: ${this.maskEmail(sender)}`);
      return;
    }

    if (this.isRateLimited(this.extractAddress(sender))) {
      this.logger.log(`Rate limit exceeded for ${this.maskEmail(sender)}`);
      return;
    }

    this.recordRequest(this.extractAddress(sender));

    const question = this.extractEmailBody(msg.data.payload).slice(0, MAX_BODY_CHARS);
    const ragResult = await this.queryRag(question);
    const replyBody = this.buildReplyBody(ragResult);

    await this.sendReply(messageId, threadId, sender, subject, replyBody);
    this.logger.log(`Replied to ${this.maskEmail(sender)}`);
  }

  /** Calls the RAG engine; swallows errors and returns null on failure. */
  private async queryRag(question: string): Promise<RagResult | null> {
    try {
      return await this.chatbotService.query(question);
    } catch {
      return null;
    }
  }

  /** Formats the final reply text from a RAG result (or fallback). */
  private buildReplyBody(result: RagResult | null): string {
    if (!result) return FALLBACK_MESSAGE;
    return `${result.answer}\n\nSource: ${result.source}`;
  }

  /** Records the current timestamp for the sender's rate-limit window. */
  private recordRequest(email: string): void {
    const timestamps = this.rateLimitMap.get(email) ?? [];
    timestamps.push(Date.now());
    this.rateLimitMap.set(email, timestamps);
  }

  /** Extracts the bare email address from a "Display Name <addr>" string. */
  private extractAddress(from: string): string {
    const match = from.match(/<([^>]+)>/);
    return match ? match[1] : from.trim();
  }

  /** Finds a named header value from a list of Gmail message headers. */
  private getHeader(
    headers: gmail_v1.Schema$MessagePartHeader[],
    name: string,
  ): string | undefined {
    return (
      headers.find((h) => h.name?.toLowerCase() === name.toLowerCase())
        ?.value ?? undefined
    );
  }

  /**
   * Extracts plain text from a Gmail message payload.
   * Prefers text/plain parts; falls back to the root body.
   */
  private extractEmailBody(
    payload: gmail_v1.Schema$MessagePart | undefined,
  ): string {
    if (!payload) return '';
    if (payload.parts) {
      const plain = payload.parts.find((p) => p.mimeType === 'text/plain');
      if (plain?.body?.data) return this.decodeBase64url(plain.body.data);
    }
    if (payload.body?.data) return this.decodeBase64url(payload.body.data);
    return '';
  }

  /** Decodes a base64url-encoded Gmail body string to UTF-8 text. */
  private decodeBase64url(encoded: string): string {
    return Buffer.from(encoded, 'base64url').toString('utf-8');
  }

  /** Removes the UNREAD label so the message is not processed again. */
  private async markAsRead(messageId: string): Promise<void> {
    await this.gmail.users.messages.modify({
      userId: 'me',
      id: messageId,
      requestBody: { removeLabelIds: ['UNREAD'] },
    });
  }

  /**
   * Sends an RFC 2822 reply email back to the original thread.
   * Email content is never stored — the buffer is used only for sending.
   */
  private async sendReply(
    messageId: string,
    threadId: string,
    to: string,
    subject: string,
    body: string,
  ): Promise<void> {
    const raw = [
      `To: ${to}`,
      `Subject: Re: ${subject}`,
      `In-Reply-To: <${messageId}>`,
      `References: <${messageId}>`,
      'Content-Type: text/plain; charset="UTF-8"',
      '',
      body,
    ].join('\r\n');

    await this.gmail.users.messages.send({
      userId: 'me',
      requestBody: {
        raw: Buffer.from(raw).toString('base64url'),
        threadId,
      },
    });
  }
}
