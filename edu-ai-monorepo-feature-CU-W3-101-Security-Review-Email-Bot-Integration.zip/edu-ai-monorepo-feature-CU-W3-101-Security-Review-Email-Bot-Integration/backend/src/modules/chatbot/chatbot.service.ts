import { Injectable, Logger } from '@nestjs/common';

/** Shape returned by a successful RAG query. */
export interface RagResult {
  answer: string;
  source: string;
}

@Injectable()
export class ChatbotService {
  private readonly logger = new Logger(ChatbotService.name);

  findAll() {
    this.logger.log('findAll called');
    return [];
  }

  /**
   * Queries the RAG engine with a natural-language question.
   * Returns the answer and source citation, or null when no result is found.
   *
   * TODO(chatbot/rag): wire to Pinecone query pipeline when rag/ module is built.
   *
   * @param question - The question to look up in the knowledge base
   */
  async query(_question: string): Promise<RagResult | null> {
    this.logger.log('RAG query received');
    return null;
  }
}
