# CU-W3-101 — Security Review Report (Week 3)

**Reviewer:** Developer 1
**Date:** 2026-04-12
**Branch:** `feature/CU-W3-101-Security-Review-Email-Bot-Integration`
**Scope:** All endpoints built in Week 2 (Developers 2–5)

---

## Executive Summary

| Area | Status |
|---|---|
| Auth0 Guard on all endpoints | ❌ Gap found — report-generator unguarded (Finding 4.A) |
| PII in error messages | ❌ Gap found — no global exception filter (Finding 2.A, fixed) |
| PII in logs | ✅ Pass |
| ApiErrorResponse format | ❌ Gap found — not enforced globally (Finding 2.A, fixed) |
| PDF upload validation | ✅ Pass — file type and size validated correctly |
| CORS | ❌ Gap found — custom middleware bypasses global policy (Finding 4.B) |

**2 gaps fixed in this branch. 3 findings reported to Developer 4 and Project Lead.**

---

## 1. Auth0 Guard Check

Checked every controller for `@UseGuards(Auth0JwtGuard, RolesGuard, RateLimitGuard)` at the class level.

| Module | File | Auth0JwtGuard | RolesGuard | RateLimitGuard | Roles Defined |
|---|---|:---:|:---:|:---:|---|
| chatbot | `modules/chatbot/chatbot.controller.ts` | ✅ | ✅ | ✅ | ADMIN, TEACHER, STAFF |
| dashboard | `modules/dashboard/dashboard.controller.ts` | ✅ | ✅ | ✅ | ADMIN, TEACHER |
| student-profile | `modules/student-profile/student-profile.controller.ts` | ✅ | ✅ | ✅ | ADMIN, COUNSELOR |
| report-generator | `modules/report-generator/report-generator.controller.ts` | ✅ | ✅ | ✅ | ADMIN, TEACHER |
| risk-report | `modules/risk-report/risk-report.controller.ts` | ✅ | ✅ | ✅ | ADMIN, COUNSELOR |
| root | `app.controller.ts` | — | — | — | intentionally public |

### Finding 1.A — Root endpoint `GET /` (resolved)

**Severity:** Low
**File:** `backend/src/app.controller.ts`

The root endpoint was returning `"Hello World!"` with no guard and no documentation.
Although it exposes no PII or sensitive data, it was not documented as intentionally public.

**Fix applied in this branch:**
- Renamed `getHello()` → `healthCheck()`, returns `{ status: 'ok' }`
- Added JSDoc comment explicitly documenting it as a GCP load-balancer health check
- Removed the now-unused `AppService` dependency from the controller
- Updated `app.controller.spec.ts` to match

**Verdict:** ✅ Resolved — endpoint is intentionally public and now documented as such.

---

## 2. PII in Error Messages + ApiErrorResponse Format

### Finding 2.A — No global exception filter (critical gap)

**Severity:** High
**Status:** Filter created, registration pending Project Lead action

There is no global `ExceptionFilter` registered in `main.ts`. This means:

1. **Unhandled TypeORM errors** bubble up as raw NestJS responses that may include:
   - SQL query fragments
   - Column/table names
   - Internal entity structure
2. **No consistent `ApiErrorResponse` format** — different errors return different shapes
3. **Stack traces** could appear in production error responses from unexpected throws

**Example risk scenario:**
```
// TypeORM throws internally:
QueryFailedError: column "student_name" of relation "students" violates not-null constraint

// Without a filter, this could reach the client as-is
```

**Fix created in this branch:**

New file: `backend/src/common/filters/http-exception.filter.ts`

The `HttpExceptionFilter`:
- Catches **all** exceptions globally (`@Catch()` with no arguments)
- Returns a consistent `ApiErrorResponse` shape for every error:
  ```json
  {
    "statusCode": 500,
    "message": "An unexpected error occurred. Please try again later.",
    "timestamp": "2026-04-12T09:00:00.000Z",
    "path": "/students"
  }
  ```
- For `HttpException` (401, 403, 429, 400) — preserves the safe NestJS message
- For `ValidationPipe` array messages — joins them into a single readable string
- For unknown errors (TypeORM, unexpected crashes) — returns generic 500, logs only the error class name server-side (not the message body)
- **Never** includes stack traces in the response
- **Never** forwards raw database error messages to the client

**Tests:** `backend/src/common/filters/http-exception.filter.spec.ts` (7 tests)

### Action required from Project Lead

`main.ts` is a protected file. The filter must be registered there:

```typescript
// Add import:
import { HttpExceptionFilter } from './common/filters/http-exception.filter';

// Add inside bootstrap(), after useGlobalPipes():
app.useGlobalFilters(new HttpExceptionFilter());
```

> **Note:** This is a one-line addition after the existing `useGlobalPipes()` call at line 15 of `main.ts`. No other changes needed.

---

## 3. PII in Logs

Reviewed all `Logger` calls across every service and the `AuditLogService`.

| File | Log calls | PII present? |
|---|---|---|
| `modules/chatbot/chatbot.service.ts` | `'findAll called'` | ✅ No PII |
| `modules/dashboard/dashboard.service.ts` | `'findAll called'` | ✅ No PII |
| `modules/student-profile/student-profile.service.ts` | `'findAll called'` | ✅ No PII |
| `modules/report-generator/report-generator.service.ts` | `'findAll called'` | ✅ No PII |
| `modules/risk-report/risk-report.service.ts` | `'findAll called'` | ✅ No PII |
| `common/services/audit-log.service.ts` | `AUDIT \| userId=... \| action=...` | ✅ userId only, no names/grades |
| `common/filters/http-exception.filter.ts` | Error class name only for 500s | ✅ No PII |

**Verdict:** ✅ Pass — all log lines contain only opaque IDs and action constants.

---

## 4. PDF Upload Validation

**Status:** ✅ / ❌ Reviewed — endpoint found in `feature/CU-W2-501-report-generator-student-profile`
**Branch reviewed:** `origin/feature/CU-W2-501-report-generator-student-profile`
**File:** `backend/src/modules/report-generator/report-generator.controller.ts`

The endpoint is `POST /report-generator/summarize-pdf`.

### File validation — Pass

| Check | Expected | Actual | Result |
|---|---|---|---|
| File type | `application/pdf` only | `mimetype !== 'application/pdf'` → `BadRequestException` | ✅ |
| File size | max 5MB | `limits: { fileSize: 5 * 1024 * 1024 }` | ✅ |
| Buffer cleanup | purged after processing | `buffer.fill(0)` in `finally` block | ✅ |

### Finding 4.A — No Auth0 Guard on any endpoint (critical)

**Severity:** High
**Affects:** `GET /report-generator`, `POST /report-generator/summarize-pdf`, `POST /report-generator/generate`

The controller has no `@UseGuards()` decorator and the module does not import `SecurityModule`.
All three endpoints are publicly accessible without authentication — any caller can invoke the OpenAI API and process PDFs without a valid token.

Required fix (to be applied by Developer 4 or via PR review):
```typescript
// report-generator.module.ts
imports: [SecurityModule]  // add this

// report-generator.controller.ts
@UseGuards(Auth0JwtGuard, RolesGuard, RateLimitGuard)
@Roles(Role.ADMIN, Role.TEACHER)
```

### Finding 4.B — Custom CORS middleware bypasses global CORS config (medium)

**Severity:** Medium
**File:** `backend/src/modules/report-generator/cors.middleware.ts`

A module-level `CorsMiddleware` hardcodes `Access-Control-Allow-Origin: http://localhost:4200`.
This overrides the global CORS policy set in `main.ts` (which reads from `CORS_ORIGIN` env var).
In production the middleware would still allow `localhost:4200`, effectively breaking CORS security.

Required fix: remove `CorsMiddleware` and `implements NestModule` from the module — global CORS in `main.ts` is sufficient.

---

## 5. Summary of Changes in This Branch

| File | Type | Description |
|---|---|---|
| `backend/src/app.controller.ts` | Modified | Health check endpoint — documented as intentionally public |
| `backend/src/app.controller.spec.ts` | Modified | Updated test to match healthCheck() |
| `backend/src/common/filters/http-exception.filter.ts` | **New** | Global exception filter — enforces ApiErrorResponse format, blocks PII leak via errors |
| `backend/src/common/filters/http-exception.filter.spec.ts` | **New** | 7 unit tests |
| `backend/src/common/guards/auth0-jwt.guard.ts` | Modified | Fixed TS7053 type error (`Request & { user?: JwtPayload }`) |
| `backend/src/common/guards/auth0-jwt.guard.spec.ts` | Modified | Typed mock request to match guard fix |
| `backend/src/modules/chatbot/chatbot.service.ts` | Modified | Added `RagResult` interface and `query()` stub |
| `backend/src/modules/chatbot/chatbot.module.ts` | Modified | Registered `EmailBotService` |
| `backend/src/modules/chatbot/channels/email/email-bot.service.ts` | **New** | Email Bot — Gmail polling, domain validation, rate limiting, RAG, reply, email masking |
| `backend/src/modules/chatbot/channels/email/email-bot.service.spec.ts` | **New** | 13 unit tests |
| `backend/.env.example` | Modified | Added `ALLOWED_EMAIL_DOMAINS` |
| `docs/security-review-W3.md` | **New** | This document |

**Test suite:** 76 tests across 12 suites — all passing. TypeScript compilation: clean (0 errors).

**Day 4 fix:** `checkInbox` refactored to isolate per-message errors — one failing message no longer blocks processing of remaining messages in the batch.

---

## 6. Action Items for Project Lead

| # | Action | Priority |
|---|---|---|
| 1 | Register `HttpExceptionFilter` in `main.ts` (see section 2.A above) | 🔴 High |
| 2 | Developer 4: add `SecurityModule` + `@UseGuards` to `report-generator` (Finding 4.A) | 🔴 High |
| 3 | Developer 4: remove `CorsMiddleware` from `report-generator.module.ts` (Finding 4.B) | 🟡 Medium |

---

## 7. Definition of Done

### Security Review
- [x] All 5 module controllers verified for Auth0 Guard
- [x] Root endpoint documented as intentionally public (health check)
- [x] Global exception filter created — ApiErrorResponse enforced, no stack traces, no raw ORM errors
- [x] All log lines verified — no PII (student names / grades)
- [x] PDF upload endpoint validated — file type ✅, file size ✅
- [x] TypeScript compilation: clean (fixed pre-existing TS7053 in auth0-jwt.guard)
- [x] Findings documented and reported to Project Lead
- [ ] **[Lead]** Register `HttpExceptionFilter` in `main.ts`
- [ ] **[Dev 4]** Add `SecurityModule` + `@UseGuards` to report-generator (Finding 4.A)
- [ ] **[Dev 4]** Remove `CorsMiddleware` from report-generator module (Finding 4.B)

### Email Bot
- [x] Email Bot receives emails and polls Gmail every 60s
- [x] Sender domain validated against `ALLOWED_EMAIL_DOMAINS`
- [x] Rate limit active — max 5 emails/hour per sender
- [x] Question passed to RAG engine via `ChatbotService.query()`
- [x] Reply sent with answer + source citation
- [x] Fallback reply: "The information was not found in the documents"
- [x] Sender email masked in all logs (`j***@school.edu`)
- [x] Email content never stored — no DB write, no disk write
- [x] Gmail credentials in Backend only — not present in frontend (`grep` verified)
- [x] 76 unit tests passing across 12 test suites
