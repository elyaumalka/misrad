import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ScheduleModule } from '@nestjs/schedule';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { RiskReportModule } from './modules/risk-report/risk-report.module';

@Module({
  imports: [ConfigModule.forRoot(), ScheduleModule.forRoot(), RiskReportModule],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
