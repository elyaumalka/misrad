import { Injectable, Logger } from '@nestjs/common';
import { google } from 'googleapis';
import { RiskReportRow, RiskLevel } from './dto/risk-report-row.dto';

const SHEET_HEADERS = [
  'מזהה תלמיד',
  'שם תלמיד',
  'כיתה',
  'ניקוד',
  'רמת סיכון',
  'סיבה',
];

const RISK_LEVEL_COLUMN_INDEX = 4; // Column E (0-based)

const RISK_COLORS: Record<RiskLevel, { red: number; green: number; blue: number }> = {
  [RiskLevel.HIGH]: { red: 0.96, green: 0.4, blue: 0.4 },
  [RiskLevel.MEDIUM]: { red: 1.0, green: 0.75, blue: 0.3 },
  [RiskLevel.LOW]: { red: 0.42, green: 0.78, blue: 0.42 },
};

@Injectable()
export class GoogleSheetsExportService {
  private readonly logger = new Logger(GoogleSheetsExportService.name);

  /**
   * Exports the weekly risk report to a new tab in Google Sheets.
   * Tab name format: "דוח סיכון שבועי- DD/MM/YYYY"
   * Applies color formatting on risk level column and enables column filters.
   * Reads credentials from GOOGLE_SERVICE_ACCOUNT_PATH and GOOGLE_SPREADSHEET_ID env vars.
   */
  async exportReport(rows: RiskReportRow[], date: Date): Promise<void> {
    const spreadsheetId = process.env.GOOGLE_SPREADSHEET_ID;
    const keyFilePath = process.env.GOOGLE_SERVICE_ACCOUNT_PATH;

    if (!spreadsheetId || !keyFilePath) {
      this.logger.error('Missing Google Sheets env vars — export skipped');
      return;
    }

    try {
      const auth = new google.auth.GoogleAuth({
        keyFile: keyFilePath,
        scopes: ['https://www.googleapis.com/auth/spreadsheets'],
      });

      const sheets = google.sheets({ version: 'v4', auth });
      const tabName = this.buildTabName(date);

      const sheetId = await this.createTab(sheets, spreadsheetId, tabName);
      await this.writeData(sheets, spreadsheetId, tabName, rows);
      await this.applyFormatting(sheets, spreadsheetId, sheetId, rows.length);

      this.logger.log(`Risk report exported to Google Sheets tab: ${tabName}`);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      this.logger.error(`Failed to export risk report to Google Sheets: ${message}`);
    }
  }

  /**
   * Builds the tab name in the format "דוח סיכון שבועי- DD/MM/YYYY".
   */
  private buildTabName(date: Date): string {
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return ` דוח סיכון שבועי- ${day}/${month}/${year}`;
  }

  /**
   * Creates a new sheet tab with the given title.
   * Returns the new sheet's numeric ID for use in formatting requests.
   */
  private async createTab(
    sheets: ReturnType<typeof google.sheets>,
    spreadsheetId: string,
    tabName: string,
  ): Promise<number> {
    const response = await sheets.spreadsheets.batchUpdate({
      spreadsheetId,
      requestBody: {
        requests: [{ addSheet: { properties: { title: tabName } } }],
      },
    });
    const sheetId = response.data.replies?.[0]?.addSheet?.properties?.sheetId;
    if (sheetId === undefined || sheetId === null) {
      throw new Error('Failed to retrieve sheetId after tab creation');
    }
    return sheetId;
  }

  /**
   * Writes headers and data rows to the specified tab.
   */
  private async writeData(
    sheets: ReturnType<typeof google.sheets>,
    spreadsheetId: string,
    tabName: string,
    rows: RiskReportRow[],
  ): Promise<void> {
    const dataRows = rows.map(row => [
      row.studentId,
      `=HYPERLINK("${row.profileLink}","${row.studentName}")`,
      row.classId,
      row.riskScore.totalScore,
      row.riskLevel,
      row.reasonForFlag,
    ]);

    await sheets.spreadsheets.values.update({
      spreadsheetId,
      range: `${tabName}!A1`,
      valueInputOption: 'USER_ENTERED',
      requestBody: { values: [SHEET_HEADERS, ...dataRows] },
    });
  }

  /**
   * Applies conditional color formatting to the risk level column,
   * enables a basic filter on the header row, and sets RTL direction.
   */
  private async applyFormatting(
    sheets: ReturnType<typeof google.sheets>,
    spreadsheetId: string,
    sheetId: number,
    rowCount: number,
  ): Promise<void> {
    const requests = [
      ...this.buildColorRules(sheetId, rowCount),
      this.buildFilterRule(sheetId, rowCount),
      this.buildRtlRule(sheetId),
    ];
    await sheets.spreadsheets.batchUpdate({
      spreadsheetId,
      requestBody: { requests },
    });
  }

  /**
   * Builds conditional formatting rules that color each row by risk level.
   */
  private buildColorRules(sheetId: number, rowCount: number): object[] {
    return Object.entries(RISK_COLORS).map(([level, color]) => ({
      addConditionalFormatRule: {
        rule: {
          ranges: [{
            sheetId,
            startRowIndex: 1,
            endRowIndex: rowCount + 1,
            startColumnIndex: RISK_LEVEL_COLUMN_INDEX,
            endColumnIndex: RISK_LEVEL_COLUMN_INDEX + 1,
          }],
          booleanRule: {
            condition: { type: 'TEXT_EQ', values: [{ userEnteredValue: level }] },
            format: { backgroundColor: color },
          },
        },
        index: 0,
      },
    }));
  }

  /**
   * Builds a basic filter rule covering all header columns.
   */
  private buildFilterRule(sheetId: number, rowCount: number): object {
    return {
      setBasicFilter: {
        filter: {
          range: {
            sheetId,
            startRowIndex: 0,
            endRowIndex: rowCount + 1,
            startColumnIndex: 0,
            endColumnIndex: SHEET_HEADERS.length,
          },
        },
      },
    };
  }

  /**
   * Builds a sheet properties update rule to enable RTL direction.
   */
  private buildRtlRule(sheetId: number): object {
    return {
      updateSheetProperties: {
        properties: { sheetId, rightToLeft: true },
        fields: 'rightToLeft',
      },
    };
  }
}
