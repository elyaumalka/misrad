import { ScoringEngine } from './scoring.engine';
import { StudentInput } from '../dto/student-input.dto';
import { RiskLevel } from '../dto/risk-report-row.dto';
import { evaluateA1, evaluateA2 } from './rules/academic.rules';
import { evaluateB1, evaluateB2 } from './rules/behavioral.rules';
import { evaluateC1 } from './rules/attendance.rules';

// ─── Helper builders ────────────────────────────────────────────────────────

function baseStudent(overrides: Partial<StudentInput> = {}): StudentInput {
  return {
    studentId: 'TEST',
    name: 'תלמיד בדיקה',
    class: 'י-א',
    grades: [],
    absences: 0,
    incidents: [],
    ...overrides,
  };
}

// ─── A1: Grade Drop ──────────────────────────────────────────────────────────

describe('A1 – Grade Drop', () => {
  it('returns 5 points for a drop of exactly 15%', () => {
    // 80 → 68: drop = 15%
    const grades = [{ subject: 'מתמטיקה', current: 68, previous: 80 }];
    const result = evaluateA1(grades);
    expect(result.points).toBe(5);
    expect(result.reason).not.toBeNull();
  });

  it('returns 5 points for a drop greater than 15%', () => {
    // 80 → 60: drop = 25%
    const grades = [{ subject: 'מתמטיקה', current: 60, previous: 80 }];
    const result = evaluateA1(grades);
    expect(result.points).toBe(5);
  });

  it('returns 0 points for a drop below 15%', () => {
    // 80 → 70: drop = 12.5%
    const grades = [{ subject: 'מתמטיקה', current: 70, previous: 80 }];
    const result = evaluateA1(grades);
    expect(result.points).toBe(0);
    expect(result.reason).toBeNull();
  });

  it('returns 0 points when there is no drop', () => {
    const grades = [{ subject: 'מתמטיקה', current: 85, previous: 80 }];
    const result = evaluateA1(grades);
    expect(result.points).toBe(0);
  });

  it('returns 0 points for empty grades array', () => {
    expect(evaluateA1([]).points).toBe(0);
  });
});

// ─── A2: Failing Grades ───────────────────────────────────────────────────────

describe('A2 – Failing Grades', () => {
  it('returns 3 points for 1 failing grade (below 60)', () => {
    const grades = [{ subject: 'מתמטיקה', current: 59, previous: 70 }];
    expect(evaluateA2(grades).points).toBe(3);
  });

  it('returns 6 points for 2 failing grades', () => {
    const grades = [
      { subject: 'מתמטיקה', current: 50, previous: 70 },
      { subject: 'אנגלית', current: 55, previous: 65 },
    ];
    expect(evaluateA2(grades).points).toBe(6);
  });

  it('returns 9 points for 3 failing grades', () => {
    const grades = [
      { subject: 'מתמטיקה', current: 50, previous: 70 },
      { subject: 'אנגלית', current: 55, previous: 65 },
      { subject: 'היסטוריה', current: 58, previous: 75 },
    ];
    expect(evaluateA2(grades).points).toBe(9);
  });

  it('returns 0 points for a grade of exactly 60 (not failing)', () => {
    const grades = [{ subject: 'מתמטיקה', current: 60, previous: 70 }];
    expect(evaluateA2(grades).points).toBe(0);
  });

  it('returns 0 points when no grades are failing', () => {
    const grades = [{ subject: 'מתמטיקה', current: 75, previous: 70 }];
    expect(evaluateA2(grades).points).toBe(0);
  });
});

// ─── B1: Incident Frequency ──────────────────────────────────────────────────

describe('B1 – Incident Frequency', () => {
  it('returns 2 points for 1 incident', () => {
    const incidents = [{ type: 'הפרעה', severity: 'low' as const }];
    expect(evaluateB1(incidents).points).toBe(2);
  });

  it('returns 6 points for 3 incidents', () => {
    const incidents = Array(3).fill({ type: 'הפרעה', severity: 'low' as const });
    expect(evaluateB1(incidents).points).toBe(6);
  });

  it('returns 10 points for 5 incidents', () => {
    const incidents = Array(5).fill({ type: 'הפרעה', severity: 'low' as const });
    expect(evaluateB1(incidents).points).toBe(10);
  });

  it('returns 0 points for no incidents', () => {
    expect(evaluateB1([]).points).toBe(0);
  });
});

// ─── B2: Incident Severity ────────────────────────────────────────────────────

describe('B2 – Incident Severity', () => {
  it('returns 3 points when 1 incident has high severity', () => {
    const incidents = [{ type: 'קטטה', severity: 'high' as const }];
    expect(evaluateB2(incidents).points).toBe(3);
  });

  it('returns 6 points when 2 incidents have high severity', () => {
    const incidents = [
      { type: 'קטטה', severity: 'high' as const },
      { type: 'אלימות', severity: 'high' as const },
    ];
    expect(evaluateB2(incidents).points).toBe(6);
  });

  it('returns 0 points when no high-severity incidents exist', () => {
    const incidents = [
      { type: 'הפרעה', severity: 'low' as const },
      { type: 'איחור', severity: 'medium' as const },
    ];
    expect(evaluateB2(incidents).points).toBe(0);
  });
});

// ─── C1: Absence Count ────────────────────────────────────────────────────────

describe('C1 – Absence Count', () => {
  it('returns 1 point for 1 absence', () => {
    expect(evaluateC1(1).points).toBe(1);
  });

  it('returns 7 points for 7 absences', () => {
    expect(evaluateC1(7).points).toBe(7);
  });

  it('returns 11 points for 11 absences', () => {
    expect(evaluateC1(11).points).toBe(11);
  });

  it('returns 0 points for 0 absences', () => {
    expect(evaluateC1(0).points).toBe(0);
  });
});

// ─── Integration: ScoringEngine ──────────────────────────────────────────────

describe('ScoringEngine – calculateRisk', () => {
  let engine: ScoringEngine;

  beforeEach(() => {
    engine = new ScoringEngine();
  });

  it('calculates correct total score and breakdown for a high-risk student', () => {
    // A1: avg drop (80+60)/2=70 prev, (60+50)/2=55 curr → 21.4% ≥ 15% → +5
    // A2: English 50 < 60 → +3; Math 60 is NOT < 60 → academic = 5+3 = 8
    // B1: 1 incident × 2 = +2; B2: severity high → +3 → behavioral = 5
    // C1: 11 absences × 1 = +11
    // Total = 8 + 5 + 11 = 24
    const student = baseStudent({
      grades: [
        { subject: 'מתמטיקה', current: 60, previous: 80 },
        { subject: 'אנגלית', current: 50, previous: 60 },
      ],
      absences: 11,
      incidents: [{ type: 'קטטה', severity: 'high' }],
    });

    const row = engine.calculateRisk(student);
    expect(row.riskScore.totalScore).toBe(24);
    expect(row.riskScore.academic).toBe(8);
    expect(row.riskScore.behavioral).toBe(5);
    expect(row.riskScore.attendance).toBe(11);
    expect(row.riskLevel).toBe(RiskLevel.HIGH);
  });

  it('classifies a student with score between 5-9 as medium risk', () => {
    // B1: 1 incident × 2 = +2; C1: 3 absences = +3 → total = 5
    const student = baseStudent({
      absences: 3,
      incidents: [{ type: 'הפרעה', severity: 'low' }],
    });

    const row = engine.calculateRisk(student);
    expect(row.riskScore.totalScore).toBe(5);
    expect(row.riskLevel).toBe(RiskLevel.MEDIUM);
  });

  it('classifies a student with score below 5 as low risk', () => {
    // B1: 1 incident × 2 = +2; C1: 2 absences = +2 → total = 4
    const student = baseStudent({
      absences: 2,
      incidents: [{ type: 'איחור', severity: 'low' }],
    });

    const row = engine.calculateRisk(student);
    expect(row.riskScore.totalScore).toBe(4);
    expect(row.riskLevel).toBe(RiskLevel.LOW);
  });

  it('returns "ללא דגלים" reason for a student with zero score', () => {
    const student = baseStudent({ absences: 0, incidents: [], grades: [] });
    const row = engine.calculateRisk(student);
    expect(row.riskScore.totalScore).toBe(0);
    expect(row.reasonForFlag).toBe('לא בסיכון');
  });

  it('includes aiStatusSummary and profileLink in the output', () => {
    const student = baseStudent({ studentId: 'S999' });
    const row = engine.calculateRisk(student);
    expect(row.aiStatusSummary).toBe('');
    expect(row.profileLink).toBe('/student-profile/S999');
  });

  it('preserves student identity fields in the output row', () => {
    const student = baseStudent({ studentId: 'S999', name: 'אורה בן דוד', class: 'י-ג' });
    const row = engine.calculateRisk(student);
    expect(row.studentId).toBe('S999');
    expect(row.studentName).toBe('אורה בן דוד');
    expect(row.classId).toBe('י-ג');
  });
});
