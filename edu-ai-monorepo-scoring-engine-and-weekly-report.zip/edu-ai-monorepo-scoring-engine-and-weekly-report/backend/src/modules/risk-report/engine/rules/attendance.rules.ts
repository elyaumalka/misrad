import { RuleResult } from './academic.rules';

const POINTS_PER_ABSENCE = 1;

/**
 * C1 – Absence Count: Awards +1 point per unexcused absence in the current period.
 */
export function evaluateC1(absences: number): RuleResult {
  if (absences === 0) return { points: 0, reason: null };

  return {
    points: absences * POINTS_PER_ABSENCE,
    reason: `${absences} היעדרויות`,
  };
}
