import { StudentIncident } from '../../dto/student-input.dto';
import { RuleResult } from './academic.rules';

const POINTS_PER_EVENT = 2;
const HIGH_SEVERITY_DELTA = 3;

/**
 * B1 – Incident Frequency: Awards +2 points per behavioral incident.
 */
export function evaluateB1(incidents: StudentIncident[]): RuleResult {
  const count = incidents.length;

  if (count === 0) return { points: 0, reason: null };

  return {
    points: count * POINTS_PER_EVENT,
    reason: `${count} אירועים התנהגותיים`,
  };
}

/**
 * B2 – Incident Severity: Awards +3 extra points per high-severity incident,
 * bringing the total for that event to +5 instead of +2.
 */
export function evaluateB2(incidents: StudentIncident[]): RuleResult {
  const highCount = incidents.filter(i => i.severity === 'high').length;

  if (highCount === 0) return { points: 0, reason: null };

  return {
    points: highCount * HIGH_SEVERITY_DELTA,
    reason: `${highCount} אירועי חומרה גבוהה`,
  };
}
