import { StudentGrade } from '../../dto/student-input.dto';

export interface RuleResult {
  points: number;
  reason: string | null;
}

const FAILING_THRESHOLD = 60;
const GRADE_DROP_THRESHOLD = 15;
const GRADE_DROP_POINTS = 5;
const FAILING_GRADE_POINTS = 3;

/**
 * A1 – Grade Drop: Detects a drop of 15% or more in a student's average grade
 * compared to the previous period. Awards +5 points.
 */
export function evaluateA1(grades: StudentGrade[]): RuleResult {
  if (grades.length === 0) return { points: 0, reason: null };

  const currentAvg = grades.reduce((sum, g) => sum + g.current, 0) / grades.length;
  const previousAvg = grades.reduce((sum, g) => sum + g.previous, 0) / grades.length;

  if (previousAvg === 0) return { points: 0, reason: null };

  const dropPercent = ((previousAvg - currentAvg) / previousAvg) * 100;

  if (dropPercent >= GRADE_DROP_THRESHOLD) {
    return { points: GRADE_DROP_POINTS, reason: `ירידה של ${Math.round(dropPercent)}% בממוצע הציונים` };
  }

  return { points: 0, reason: null };
}

/**
 * A2 – Failing Grades: Awards +3 points per subject where the student's current
 * grade is below the passing threshold (60).
 */
export function evaluateA2(grades: StudentGrade[]): RuleResult {
  const failCount = grades.filter(g => g.current < FAILING_THRESHOLD).length;

  if (failCount === 0) return { points: 0, reason: null };

  return {
    points: failCount * FAILING_GRADE_POINTS,
    reason: `${failCount} מקצועות עם ציון נכשל`,
  };
}
