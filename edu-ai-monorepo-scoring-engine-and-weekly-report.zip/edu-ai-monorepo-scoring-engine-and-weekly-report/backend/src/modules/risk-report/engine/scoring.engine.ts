import { Injectable } from '@nestjs/common';
import { StudentInput } from '../dto/student-input.dto';
import { RiskLevel, RiskReportRow, RiskScore } from '../dto/risk-report-row.dto';
import { evaluateA1, evaluateA2 } from './rules/academic.rules';
import { evaluateB1, evaluateB2 } from './rules/behavioral.rules';
import { evaluateC1 } from './rules/attendance.rules';

const MEDIUM_THRESHOLD = 5;
const HIGH_THRESHOLD = 10;

/**
 * Core scoring engine that evaluates all risk rules for a student
 * and produces a RiskReportRow with a categorised score, level, and reason.
 */
@Injectable()
export class ScoringEngine {
  /**
   * Calculates the risk score for a single student based on all approved rules.
   * Rules: A1 (grade drop), A2 (failing grades), B1 (incident frequency),
   * B2 (incident severity), C1 (absence count).
   */
  calculateRisk(input: StudentInput): RiskReportRow {
    const a1 = evaluateA1(input.grades);
    const a2 = evaluateA2(input.grades);
    const b1 = evaluateB1(input.incidents);
    const b2 = evaluateB2(input.incidents);
    const c1 = evaluateC1(input.absences);

    const academic = a1.points + a2.points;
    const behavioral = b1.points + b2.points;
    const attendance = c1.points;
    const totalScore = academic + behavioral + attendance;

    const riskScore: RiskScore = { academic, behavioral, attendance, totalScore };
    const level = this.mapScoreToLevel(totalScore);

    const reasons = [a1, a2, b1, b2, c1]
      .map(r => r.reason)
      .filter((r): r is string => r !== null);
    const reasonForFlag = reasons.length > 0 ? reasons.join(' + ') : 'לא בסיכון';

    return {
      studentId: input.studentId,
      studentName: input.name,
      classId: input.class,
      riskScore,
      riskLevel: level,
      reasonForFlag,
      aiStatusSummary: '',
      profileLink: `/student-profile/${input.studentId}`,
    };
  }

  private mapScoreToLevel(score: number): RiskLevel {
    if (score >= HIGH_THRESHOLD) return RiskLevel.HIGH;
    if (score >= MEDIUM_THRESHOLD) return RiskLevel.MEDIUM;
    return RiskLevel.LOW;
  }
}
