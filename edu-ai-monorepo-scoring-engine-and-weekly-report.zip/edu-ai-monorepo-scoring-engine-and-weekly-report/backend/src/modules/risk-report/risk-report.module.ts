import { Module } from '@nestjs/common';
import { RiskReportController } from './risk-report.controller';
import { RiskReportService } from './risk-report.service';
import { RiskReportScheduler } from './risk-report.scheduler';
import { GoogleSheetsExportService } from './google-sheets-export.service';
import { ScoringEngine } from './engine/scoring.engine';

@Module({
  controllers: [RiskReportController],
  providers: [RiskReportService, ScoringEngine, RiskReportScheduler, GoogleSheetsExportService],
  exports: [RiskReportService],
})
export class RiskReportModule {}
