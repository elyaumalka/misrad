import { Injectable, Logger } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import { RiskReportService } from './risk-report.service';
import { GoogleSheetsExportService } from './google-sheets-export.service';

@Injectable()
export class RiskReportScheduler {
  private readonly logger = new Logger(RiskReportScheduler.name);

  constructor(
    private readonly riskReportService: RiskReportService,
    private readonly googleSheetsExportService: GoogleSheetsExportService,
  ) {}

  /**
   * Runs every Sunday at 02:00 AM.
   * Generates the weekly risk report and exports it to Google Sheets.
   */
  @Cron('0 0 2 * * 0')
  async handleWeeklyReport(): Promise<void> {
    this.logger.log('Weekly risk report job started');
    try {
      const report = await this.riskReportService.generateWeeklyReport();
      this.logger.log(`Weekly risk report completed — ${report.length} students processed`);
      await this.googleSheetsExportService.exportReport(report, new Date());
    } catch {
      this.logger.error('Weekly risk report job failed — see application logs for details');
    }
  }
}
