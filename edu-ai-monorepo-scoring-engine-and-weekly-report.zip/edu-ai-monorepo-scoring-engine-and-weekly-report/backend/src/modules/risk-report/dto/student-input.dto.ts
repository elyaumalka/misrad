export interface StudentGrade {
  subject: string;
  current: number;
  previous: number;
}

export interface StudentIncident {
  type: string;
  severity: 'low' | 'medium' | 'high';
}

export interface StudentInput {
  studentId: string;
  name: string;
  class: string;
  grades: StudentGrade[];
  absences: number;
  incidents: StudentIncident[];
}
