export enum RiskLevel {
  LOW = 'Low',
  MEDIUM = 'Medium',
  HIGH = 'High',
}

export interface RiskScore {
  academic: number;
  behavioral: number;
  attendance: number;
  totalScore: number;
}

export interface RiskReportRow {
  studentId: string;
  studentName: string;
  classId: string;
  riskScore: RiskScore;
  riskLevel: RiskLevel;
  reasonForFlag: string;
  aiStatusSummary: string;
  profileLink: string;
}
