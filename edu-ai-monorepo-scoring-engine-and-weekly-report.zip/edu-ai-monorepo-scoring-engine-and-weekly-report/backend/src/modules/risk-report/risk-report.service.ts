import { Injectable, Logger } from '@nestjs/common';
import { ScoringEngine } from './engine/scoring.engine';
import { StudentInput } from './dto/student-input.dto';
import { RiskReportRow } from './dto/risk-report-row.dto';

/** Mock student data – used only for weekly report calculation; data is stored in database */
const MOCK_STUDENTS: StudentInput[] = [
  {
    studentId: 'S001',
    name: 'ישראל ישראלי',
    class: 'י-א',
    grades: [
      { subject: 'מתמטיקה', current: 60, previous: 80 },
      { subject: 'אנגלית', current: 50, previous: 75 },
    ],
    absences: 1,
    incidents: [
      { type: 'הפרעה בשיעור', severity: 'low' },
      { type: 'קטטה', severity: 'high' },
      { type: 'הפרעה בשיעור', severity: 'low' },
    ],
  },
  {
    studentId: 'S002',
    name: 'שרה כהן',
    class: 'י-ב',
    grades: [
      { subject: 'מתמטיקה', current: 85, previous: 82 },
      { subject: 'אנגלית', current: 90, previous: 88 },
    ],
    absences: 2,
    incidents: [],
  },
  {
    studentId: 'S003',
    name: 'דוד לוי',
    class: 'י-א',
    grades: [
      { subject: 'מתמטיקה', current: 52, previous: 58 },
      { subject: 'אנגלית', current: 60, previous: 55 },
    ],
    absences: 0,
    incidents: [
      { type: 'איחור', severity: 'low' },
      { type: 'איחור', severity: 'low' },
      { type: 'איחור', severity: 'medium' },
    ],
  },
];

@Injectable()
export class RiskReportService {
  private readonly logger = new Logger(RiskReportService.name);

  constructor(private readonly scoringEngine: ScoringEngine) {}

  /**
   * Calculates weekly risk scores for all students.
   * Returns scores to frontend – no database storage.
   * Frontend handles filtering and sorting by risk level.
   */
  async generateWeeklyReport(): Promise<RiskReportRow[]> {
    this.logger.log('Calculating weekly risk scores for all students');
    const scoredStudents = MOCK_STUDENTS.map(student =>
      this.scoringEngine.calculateRisk(student),
    );
    this.logger.log(`Calculated risk scores for ${scoredStudents.length} students`);
    return scoredStudents;
  }
}
