import { Controller, Get, Post } from '@nestjs/common';
import { ApiTags, ApiOperation } from '@nestjs/swagger';
import { RiskReportService } from './risk-report.service';
import { GoogleSheetsExportService } from './google-sheets-export.service';
import { RiskReportRow } from './dto/risk-report-row.dto';

@ApiTags('at-risk')
@Controller('at-risk')
export class RiskReportController {
  constructor(
    private readonly service: RiskReportService,
    private readonly googleSheetsExportService: GoogleSheetsExportService,
  ) {}

  /**
   * Returns the full weekly at-risk report for all students.
   * Each row includes score breakdown, risk level, reason, and profile link.
   * Frontend handles filtering and sorting by risk level.
   */
  @ApiOperation({ summary: 'Fetch full weekly report data, filtered by grade/class' })
  @Get('weekly-report')
  async getWeeklyReport(): Promise<RiskReportRow[]> {
    return await this.service.generateWeeklyReport();
  }

  /**
   * Triggers generation of risk scores and exports the report to Google Sheets.
   */
  @ApiOperation({ summary: 'Trigger generation of risk scores and export to Google Sheets' })
  @Post('generate')
  async generateReport(): Promise<{ message: string }> {
    const report = await this.service.generateWeeklyReport();
    await this.googleSheetsExportService.exportReport(report, new Date());
    return { message: 'Report generation triggered' };
  }
}
