# At-Risk Student Detection System

A backend module that analyzes student data from the last 30 days, computes a risk score based on configurable rules, and generates a weekly report for school counselors and administrators.

---

## Table of Contents

- [Rules Engine](#rules-engine)
- [Risk Score Table](#risk-score-table)
- [Interfaces](#interfaces)
- [API Contracts](#api-contracts)
- [Security & Permissions](#security--permissions)

---

## Rules Engine

The engine evaluates each student across three categories and accumulates points based on the following triggers:

### Academic

| Rule | Input | Trigger | Points |
|------|-------|---------|--------|
| Grade Drop | Average grades (last 30 days vs. prior period) | Drop of 15% or more in average | +5 |
| Failing Grades | Final grades (last 30 days) | Any final grade below 60 | +3 per failing grade |

### Behavioral

| Rule | Input | Trigger | Points |
|------|-------|---------|--------|
| Event Frequency | Events where `EventType = 'התנהגות'` (last 30 days) | Any recorded behavioral event | +2 per event |
| Event Severity *(optional)* | Severity column (1–3) | Behavioral event with severity 3 | +5 instead of +2 |

### Attendance

| Rule | Input | Trigger | Points |
|------|-------|---------|--------|
| Absence Count | Events where `EventType = 'נוכחות'` (last 30 days) | Any unexcused absence recorded | +1 per absence |

---

## Risk Score Table

| Risk Level | Score Range | System Color |
|------------|-------------|--------------|
| Low | 1–4 | Green |
| Medium (For Review) | 5–9 | Yellow |
| High (Immediate Attention) | 10+ | Red |

---

## Interfaces

Located in `backend/src/common/interfaces/`

```ts
// RiskLevel.ts
export enum RiskLevel {
  LOW = 'Low',
  MEDIUM = 'Medium',
  HIGH = 'High'
}

// RiskScore.ts
export interface RiskScore {
  academic: number;
  behavioral: number;
  attendance: number;
  totalScore: number;
}

// RiskReportRow.ts
export interface RiskReportRow {
  studentId: string;
  studentName: string;    // Rendered as a clickable link to student profile
  classId: string;
  riskScore: RiskScore;
  riskLevel: RiskLevel;
  reasonForFlag: string;
  aiStatusSummary: string;
  profileLink: string;
}
```

> `RiskReportRow` uses base data models provided by Developer 3's module.

---

## API Contracts

### Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/at-risk/weekly-report` | Fetch full weekly report data, filtered by grade/class |
| `POST` | `/api/at-risk/generate` | Trigger generation/update of risk scores and AI summaries |

### Weekly Report Response Fields

| Field | Description | Example |
|-------|-------------|---------|
| `studentID` | Unique student identifier | `204587123` |
| `studentName` | Full name — rendered as a clickable link to the student's dynamic profile page | `Moshe Cohen` |
| `classID` | Student's class identifier | `Grade 7-2` |
| `totalRiskScore` | Total risk score computed by the system | `12` |
| `riskLevel` | Student risk level (`High`, `Medium`, `Low`) | `High Risk` |
| `reasonForFlag` | Data-driven summary of which rules were triggered | `20% grade drop; behavioral events; absences` |
| `aiStatusSummary` | Short AI-generated narrative based on student data for the relevant period | `Moshe is showing several indicators that require attention...` |

---

## Security & Permissions

| Topic | Rule | Detail |
|-------|------|--------|
| Link data security | Profile link structure | The profile link must contain **only the StudentID** — no additional personal data |
| Access control | Authorized roles | `admin` (management) and `counselor` |
| Access control | Blocked roles | `teacher` — regular teachers are **not** authorized to view the full At-Risk weekly report |
