import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from '../../shared/layout/header/header.component';
import { SidebarComponent } from '../../shared/layout/sidebar/sidebar.component';
import { KpiCardComponent } from '../../shared/components/kpi-card/kpi-card.component';
import { LoadingSpinnerComponent } from '../../shared/components/loading-spinner/loading-spinner.component';
import { ErrorMessageComponent } from '../../shared/components/error-message/error-message.component';

// TODO: Temporary showcase — remove once AppShellComponent is integrated
@Component({
  selector: 'app-report-generator',
  standalone: true,
  imports: [
    CommonModule,
    HeaderComponent,
    SidebarComponent,
    KpiCardComponent,
    LoadingSpinnerComponent,
    ErrorMessageComponent,
  ],
  templateUrl: './report-generator.component.html',
})
export class ReportGeneratorComponent {}
