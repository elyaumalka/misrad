# CU-W1-301 — Data Models + Google Sheets Service

**Branch:** `feature/cu-w1-301-data-models-gs-service`
**ClickUp:** CU-W1-301
**Status:** Pending approval from all modules before closing

---

## What Was Done

This task established the shared data foundation for the entire backend:

1. **Shared Data Models** — TypeScript interfaces and an enum in `backend/src/common/` that all five modules will consume when reading from the Google Sheet.
2. **Google Sheets Service** — A read-only `GoogleSheetsService` in `backend/src/common/services/` that currently returns mock data. The real Google Sheets API call will be wired in next week; all parsing logic is already in place.
3. **Mock Data** — Covers all three event types (Grade, Attendance, Behavior) using completely fictional student names.
4. **Dashboard API Contracts** — Two endpoints (`GET /dashboard/kpis` and `GET /dashboard/charts`) with fully typed DTOs and Swagger documentation.
5. **Unit Tests** — Full test suite for `GoogleSheetsService` including PII-leak assertions on every method.

---

## ⚠️ Section 1: Shared Data Models — Approval Required

> **Approval needed from:** chatbot, risk-report, report-generator, student-profile

These files live in `backend/src/common/` and are consumed by every module.

---

### `enums/event-type.enum.ts`

```typescript
/**
 * Represents the three types of student events tracked in the Google Sheet.
 * The sheet stores these as Hebrew strings — the service maps them to this enum.
 *
 * Sheet value → Enum:
 *   'ציון'       → EventType.GRADE
 *   'נוכחות'     → EventType.ATTENDANCE
 *   'התנהגות'    → EventType.BEHAVIOR
 */
export enum EventType {
  GRADE = 'GRADE',
  ATTENDANCE = 'ATTENDANCE',
  BEHAVIOR = 'BEHAVIOR',
}
```

---

### `interfaces/student.interface.ts`

```typescript
/**
 * Represents a unique student, derived from event rows in the Google Sheet.
 * All fields in this interface are PII — never log any of them.
 */
export interface Student {
  /** @PII Student ID number (e.g., "204587123") */
  studentId: string;

  /** @PII Student full name (e.g., "Alex Morgan") */
  studentName: string;

  /** Class the student belongs to (e.g., "ח-1") */
  classId: string;
}
```

---

### `interfaces/grade-event.interface.ts`

```typescript
import { EventType } from '../enums/event-type.enum';

/**
 * A grade entry for a student in a specific subject.
 * Maps to a Google Sheet row where EventType = 'ציון'.
 */
export interface GradeEvent {
  /** Unique event identifier (maps to sheet column: EventID) */
  eventId: string;

  /** @PII Student ID — reference only, do not log (maps to sheet column: StudentID) */
  studentId: string;

  /** @PII Student full name — do not log (maps to sheet column: StudentName) */
  studentName: string;

  /** Class the student belongs to (maps to sheet column: ClassID) */
  classId: string;

  /** Date of the event (maps to sheet column: EventDate) */
  eventDate: Date;

  /** Always EventType.GRADE for this interface (maps to sheet column: EventType) */
  eventType: EventType.GRADE;

  /** Subject name, e.g. "מתמטיקה" (maps to sheet column: EventSubject) */
  eventSubject: string;

  /** Numeric score between 0 and 100 (maps to sheet column: EventValue) */
  eventValue: number;

  /** Optional short description, e.g. "מבחן רבעוני" (maps to sheet column: EventDescription) */
  eventDescription?: string;
}
```

---

### `interfaces/attendance-event.interface.ts`

```typescript
import { EventType } from '../enums/event-type.enum';

/**
 * An attendance record for a student on a specific date.
 * Maps to a Google Sheet row where EventType = 'נוכחות'.
 */
export interface AttendanceEvent {
  /** Unique event identifier (maps to sheet column: EventID) */
  eventId: string;

  /** @PII Student ID — reference only, do not log (maps to sheet column: StudentID) */
  studentId: string;

  /** @PII Student full name — do not log (maps to sheet column: StudentName) */
  studentName: string;

  /** Class the student belongs to (maps to sheet column: ClassID) */
  classId: string;

  /** Date of the event (maps to sheet column: EventDate) */
  eventDate: Date;

  /** Always EventType.ATTENDANCE for this interface (maps to sheet column: EventType) */
  eventType: EventType.ATTENDANCE;

  /** Subject context, if applicable (maps to sheet column: EventSubject — only required for Grade events per spec) */
  eventSubject?: string;

  /**
   * Attendance status (maps to sheet column: EventValue).
   * 1 = absent (חיסור), 0 = present (נוכחות)
   */
  eventValue: number;

  /** Optional short description, e.g. "חיסור מוצדק - מחלה" (maps to sheet column: EventDescription) */
  eventDescription?: string;
}
```

---

### `interfaces/behavior-event.interface.ts`

```typescript
import { EventType } from '../enums/event-type.enum';

/**
 * A behavior incident recorded for a student.
 * Maps to a Google Sheet row where EventType = 'התנהגות'.
 */
export interface BehaviorEvent {
  /** Unique event identifier (maps to sheet column: EventID) */
  eventId: string;

  /** @PII Student ID — reference only, do not log (maps to sheet column: StudentID) */
  studentId: string;

  /** @PII Student full name — do not log (maps to sheet column: StudentName) */
  studentName: string;

  /** Class the student belongs to (maps to sheet column: ClassID) */
  classId: string;

  /** Date of the event (maps to sheet column: EventDate) */
  eventDate: Date;

  /** Always EventType.BEHAVIOR for this interface (maps to sheet column: EventType) */
  eventType: EventType.BEHAVIOR;

  /** Subject context, if applicable (maps to sheet column: EventSubject — only required for Grade events per spec) */
  eventSubject?: string;

  /**
   * Behavior indicator (maps to sheet column: EventValue).
   * 1 = negative event (אירוע שלילי)
   */
  eventValue: number;

  /** Optional short description, e.g. "הפרעה בשיעור" (maps to sheet column: EventDescription) */
  eventDescription?: string;
}
```

---

## Google Sheet Column Mapping

All interfaces map 1-to-1 to the sheet columns. The raw sheet row structure is:

| Sheet Column | TypeScript Field | Type | PII |
|---|---|---|---|
| `EventID` | `eventId` | `string` | No |
| `StudentID` | `studentId` | `string` | **Yes** |
| `StudentName` | `studentName` | `string` | **Yes** |
| `ClassID` | `classId` | `string` | No |
| `EventDate` | `eventDate` | `Date` | No |
| `EventType` | `eventType` | Hebrew string → `EventType` enum | No |
| `EventSubject` | `eventSubject` | `string` | No |
| `EventValue` | `eventValue` | `number` | No |
| `EventDescription` | `eventDescription` | `string` (optional) | No |

> `eventValue` encoding:
> - **Grade** — numeric score 0–100
> - **Attendance** — `0` = present, `1` = absent
> - **Behavior** — `1` = negative incident

---

## ⚠️ Section 2: Google Sheets Service — Public API

> **Approval needed from:** chatbot, risk-report, report-generator, student-profile

`GoogleSheetsService` is the **only** entry point for reading sheet data. All modules must inject it — never create a direct Google Sheets API call inside your own module.

It is registered in `CommonModule` and exported. To use it, import `CommonModule` into your module.

### Public Methods

| Method | Signature | Returns |
|---|---|---|
| `getStudents` | `getStudents(): Promise<Student[]>` | All unique students (deduplicated by `studentId`) |
| `getGrades` | `getGrades(studentId: string): Promise<GradeEvent[]>` | Grade events for one student |
| `getAllGrades` | `getAllGrades(): Promise<GradeEvent[]>` | All grade events across all students |
| `getAttendance` | `getAttendance(studentId: string): Promise<AttendanceEvent[]>` | Attendance records for one student |
| `getAllAttendance` | `getAllAttendance(): Promise<AttendanceEvent[]>` | All attendance records across all students |
| `getBehaviorEvents` | `getBehaviorEvents(studentId: string): Promise<BehaviorEvent[]>` | Behavior events for one student |
| `getAllBehaviorEvents` | `getAllBehaviorEvents(): Promise<BehaviorEvent[]>` | All behavior events across all students |

**PII rules enforced by the service:**
- All log messages emit only record counts — never student names, IDs, or score values.
- The internal `SheetRow` type is private to the service and is never exposed to callers.

**Swap point for real API:** The private `getRows()` method is the single location to replace mock data with a live Google Sheets API call. All parsing and mapping logic downstream stays identical.

---

## ⚠️ Section 3: Dashboard API Contracts — Approval Required

> **Approval needed from:** chatbot, risk-report, report-generator, student-profile

### Endpoint 1 — `GET /dashboard/kpis`

**Purpose:** Aggregated school-level KPI metrics for dashboard header cards.

**Request:**

| Field | Value |
|---|---|
| Method | `GET` |
| Path | `/dashboard/kpis` |
| Auth | Bearer token (Auth0) |
| Query params | None |
| Request body | None |

**Response — `200 OK`:**

```json
{
  "totalStudents": 5,
  "averageGrade": 72.6,
  "attendanceRate": 16.7,
  "behaviorIncidentCount": 5
}
```

**Response field definitions:**

| Field | Type | Description |
|---|---|---|
| `totalStudents` | `number` | Count of unique students in the system |
| `averageGrade` | `number` | Mean score across all grade events (0–100, 1 decimal place) |
| `attendanceRate` | `number` | % of attendance events where student was present (0–100, 1 decimal place) |
| `behaviorIncidentCount` | `number` | Total count of negative behavior events (`eventValue === 1`) |

**PII guarantee:** All values are aggregated numbers. No student names or raw IDs are present.

---

### Endpoint 2 — `GET /dashboard/charts`

**Purpose:** Chart-ready data series for the three main dashboard charts.

**Request:**

| Field | Value |
|---|---|
| Method | `GET` |
| Path | `/dashboard/charts` |
| Auth | Bearer token (Auth0) |
| Query params | None |
| Request body | None |

**Response — `200 OK`:**

```json
{
  "gradesBySubject": [
    { "label": "מתמטיקה", "value": 73.6 },
    { "label": "אנגלית",  "value": 70.0 }
  ],
  "weeklyAbsences": [
    { "label": "2025-W36", "value": 3 },
    { "label": "2025-W37", "value": 2 }
  ],
  "behaviorByStudent": [
    { "label": "S102", "value": 2 },
    { "label": "S104", "value": 1 },
    { "label": "S105", "value": 2 }
  ]
}
```

**Response field definitions:**

| Field | Type | Description |
|---|---|---|
| `gradesBySubject` | `ChartDataPointDto[]` | Average score per subject. `label` = subject name, `value` = average (1 dp) |
| `weeklyAbsences` | `ChartDataPointDto[]` | Absence count per ISO week. `label` = `"YYYY-W##"`, `value` = count. Sorted ascending |
| `behaviorByStudent` | `ChartDataPointDto[]` | Incident count per student. `label` = `studentId` (**not** `studentName`), `value` = count |

**`ChartDataPointDto` shape:**

```typescript
{
  label: string;  // Subject name | ISO week (e.g. "2025-W36") | studentId
  value: number;  // Average score | count
}
```

**PII guarantee:**
- `gradesBySubject` — labels are subject names.
- `weeklyAbsences` — labels are ISO week strings.
- `behaviorByStudent` — labels are `studentId` values, never `studentName`.

---

## Mock Data Overview

Mock data is in `backend/src/common/services/mock-data/mock-sheet-rows.ts`. All student names are completely fictional.

| Event Type | Sheet Value | Row Count | Student IDs |
|---|---|---|---|
| Grade | `ציון` | 7 | S101, S102, S103, S104, S105 |
| Attendance | `נוכחות` | 6 | S101, S102, S103, S104, S105 |
| Behavior | `התנהגות` | 5 | S102, S104, S105 |

---

## Unit Tests

**File:** `backend/src/common/services/google-sheets.service.spec.ts`

| Test group | Cases covered |
|---|---|
| `getStudents` | Returns array; correct unique count; required fields; no PII in logs |
| `getGrades` | Returns array; correct count per student; required fields; DD/MM/YYYY format; empty for nonexistent student; no PII in logs |
| `getAllGrades` | Correct total count; all records typed `GRADE`; no PII in logs |
| `getAttendance` | Returns array; correct count per student; required fields; numeric `eventValue`; at least one absence; DD/MM/YYYY format; empty for nonexistent student; no PII in logs |
| `getAllAttendance` | Correct total count; all records typed `ATTENDANCE`; no PII in logs |
| `getBehaviorEvents` | Returns array; correct count per student; required fields; numeric `eventValue`; at least one incident; DD/MM/YYYY format; empty for nonexistent student; no PII in logs |
| `getAllBehaviorEvents` | Correct total count; all records typed `BEHAVIOR`; no PII in logs |

The PII assertions spy on `Logger.prototype.log` and verify that no logged string contains any `studentId` or `studentName` value from the mock data.

**Run tests:**

```bash
cd backend
npm run test -- --testPathPattern=google-sheets.service.spec
```

---

## Files Changed

```
backend/src/common/
├── enums/
│   └── event-type.enum.ts              ← New
├── interfaces/
│   ├── index.ts                        ← New
│   ├── student.interface.ts            ← New
│   ├── grade-event.interface.ts        ← New
│   ├── attendance-event.interface.ts   ← New
│   └── behavior-event.interface.ts     ← New
├── services/
│   ├── google-sheets.service.ts        ← New
│   ├── google-sheets.service.spec.ts   ← New
│   └── mock-data/
│       └── mock-sheet-rows.ts          ← New
├── common.module.ts                    ← New
└── index.ts                            ← New

backend/src/modules/dashboard/
├── dashboard.controller.ts             ← Updated
├── dashboard.service.ts                ← Updated
├── dashboard.module.ts                 ← Updated
├── dashboard.service.spec.ts           ← New
└── dto/
    ├── kpi-response.dto.ts             ← New
    └── chart-data-response.dto.ts      ← New
```

---

## Approval Checklist

Please reply with your approval (or comments) before this task is closed.

**Shared Data Models & Google Sheets Service** (Sections 1 & 2):
- [ ] chatbot module developer — approved
- [ ] risk-report module developer — approved
- [ ] report-generator module developer — approved
- [ ] student-profile module developer — approved

**Dashboard API Contracts** (Section 3):
- [ ] chatbot module developer — approved
- [ ] risk-report module developer — approved
- [ ] report-generator module developer — approved
- [ ] student-profile module developer — approved
