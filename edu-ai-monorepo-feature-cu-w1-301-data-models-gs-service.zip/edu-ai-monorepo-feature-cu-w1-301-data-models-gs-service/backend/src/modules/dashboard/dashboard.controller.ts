import {
  Controller,
  Get,
  Headers,
  Post,
  Query,
  UnauthorizedException,
} from '@nestjs/common';
import { ApiOkResponse, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AiSummaryService } from './ai-summary.service';
import { DashboardCacheService } from './dashboard-cache.service';
import { DashboardService } from './dashboard.service';
import { AiSummaryResponseDto } from './dto/ai-summary-response.dto';
import { AvailableClassesResponseDto } from './dto/available-classes-response.dto';
import { CacheStatusResponseDto } from './dto/cache-status-response.dto';
import {
  ChartDataPointDto,
  ChartDataResponseDto,
} from './dto/chart-data-response.dto';
import { DashboardQueryDto } from './dto/dashboard-query.dto';
import { KpiResponseDto } from './dto/kpi-response.dto';

@ApiTags('dashboard')
@Controller('dashboard')
export class DashboardController {
  constructor(
    private readonly service: DashboardService,
    private readonly aiSummaryService: AiSummaryService,
    private readonly cacheService: DashboardCacheService,
  ) {}

  /**
   * Returns aggregated KPI metrics scoped to the given class and date range.
   * Omitting query params returns unscoped aggregates across all data.
   * No PII is included in the response.
   */
  @Get('kpis')
  @ApiOperation({ summary: 'Get dashboard KPI metrics' })
  @ApiOkResponse({ type: KpiResponseDto })
  getKpis(@Query() query: DashboardQueryDto): Promise<KpiResponseDto> {
    return this.service.getKpis(query);
  }

  /**
   * Returns average grade per subject scoped to the given class and date range.
   * Omitting query params returns unscoped data across all classes and dates.
   */
  @Get('grades-by-subject')
  @ApiOperation({ summary: 'Get average grade per subject' })
  @ApiOkResponse({ type: [ChartDataPointDto] })
  getGradesBySubject(
    @Query() query: DashboardQueryDto,
  ): Promise<ChartDataPointDto[]> {
    return this.service.getGradesBySubject(query);
  }

  /**
   * Returns behavior incident count per calendar week scoped to the given class and date range.
   * Omitting query params returns unscoped data across all classes and dates.
   * Only negative incidents (eventValue === 1) are counted.
   */
  @Get('behavior-over-time')
  @ApiOperation({ summary: 'Get behavior incidents over time (per ISO week)' })
  @ApiOkResponse({ type: [ChartDataPointDto] })
  getBehaviorOverTime(
    @Query() query: DashboardQueryDto,
  ): Promise<ChartDataPointDto[]> {
    return this.service.getBehaviorOverTime(query);
  }

  /**
   * Returns aggregated chart data scoped to the given class and date range.
   * Omitting query params returns unscoped data across all classes and dates.
   * All labels use subject names, ISO week strings, or studentIds — no student names.
   */
  @Get('charts')
  @ApiOperation({ summary: 'Get dashboard chart data' })
  @ApiOkResponse({ type: ChartDataResponseDto })
  getChartData(
    @Query() query: DashboardQueryDto,
  ): Promise<ChartDataResponseDto> {
    return this.service.getChartData(query);
  }

  /**
   * Returns an AI-generated Hebrew executive summary of the current dashboard data.
   * Returns { summary: '' } if OpenAI is unavailable — never blocks the dashboard.
   * No PII is included in the prompt or the response.
   */
  @Get('summary')
  @ApiOperation({ summary: 'Get AI-generated executive summary in Hebrew' })
  @ApiOkResponse({ type: AiSummaryResponseDto })
  getSummary(@Query() query: DashboardQueryDto): Promise<AiSummaryResponseDto> {
    return this.aiSummaryService.generateSummary(query);
  }

  /**
   * Returns all unique class IDs available in the sheet.
   * Used by the frontend to populate the class selector dropdown.
   * No query parameters — always returns the complete list.
   */
  @Get('classes')
  @ApiOperation({ summary: 'Get all available class IDs' })
  @ApiOkResponse({ type: AvailableClassesResponseDto })
  getAvailableClasses(): Promise<AvailableClassesResponseDto> {
    return this.service.getAvailableClasses();
  }

  /**
   * Returns the timestamp of the last successful cache refresh.
   * The frontend uses this to display the "Last updated" indicator.
   * Returns null if the server has not completed a Google Sheets read yet.
   */
  @Get('cache-status')
  @ApiOperation({ summary: 'Get the last successful data refresh timestamp' })
  @ApiOkResponse({ type: CacheStatusResponseDto })
  getCacheStatus(): CacheStatusResponseDto {
    const ts = this.cacheService.getLastRefreshedAt();
    return { lastRefreshedAt: ts?.toISOString() ?? null };
  }

  /**
   * Triggers a full re-read from Google Sheets and updates the in-memory cache.
   * Protected by the x-sync-secret header — intended for GCP Cloud Scheduler only.
   *
   * GCP Cloud Scheduler config (set up by project lead):
   *   Schedule : 0 2 * * 0  (every Sunday at 02:00)
   *   Target   : POST https://<backend-url>/api/dashboard/sync
   *   Header   : x-sync-secret: <DASHBOARD_SYNC_SECRET from GCP Secret Manager>
   */
  @Post('sync')
  @ApiOperation({
    summary: 'Trigger weekly data refresh (GCP Cloud Scheduler target)',
  })
  @ApiOkResponse({ type: CacheStatusResponseDto })
  async sync(
    @Headers('x-sync-secret') secret: string,
  ): Promise<CacheStatusResponseDto> {
    const expected = process.env['DASHBOARD_SYNC_SECRET'];
    if (!expected || secret !== expected) {
      throw new UnauthorizedException('Invalid or missing sync secret.');
    }

    await this.cacheService.refreshCache();
    const ts = this.cacheService.getLastRefreshedAt();
    return { lastRefreshedAt: ts?.toISOString() ?? null };
  }
}
