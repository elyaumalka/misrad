import { Injectable, Logger } from '@nestjs/common';
import OpenAI from 'openai';
import { ChartDataPointDto } from './dto/chart-data-response.dto';
import { DashboardQueryDto } from './dto/dashboard-query.dto';
import { KpiResponseDto } from './dto/kpi-response.dto';
import { AiSummaryResponseDto } from './dto/ai-summary-response.dto';
import { DashboardService } from './dashboard.service';

@Injectable()
export class AiSummaryService {
  private readonly logger = new Logger(AiSummaryService.name);
  private readonly openai: OpenAI | null;

  constructor(private readonly dashboardService: DashboardService) {
    this.openai = process.env.OPENAI_API_KEY
      ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
      : null;
  }

  /**
   * Generates a 2–4 sentence Hebrew executive summary from current dashboard data.
   * Fetches KPIs and grade breakdowns from DashboardService, then sends to OpenAI.
   * Returns { summary: '' } on any error — never throws — enabling graceful degradation.
   * No PII (student names, IDs) is included in the prompt or logged.
   */
  async generateSummary(
    query: DashboardQueryDto,
  ): Promise<AiSummaryResponseDto> {
    if (!this.openai) {
      this.logger.warn('AiSummaryService: OPENAI_API_KEY is not configured');
      return { summary: '', error: 'missing_api_key' };
    }
    try {
      const [kpis, grades] = await Promise.all([
        this.dashboardService.getKpis(query),
        this.dashboardService.getGradesBySubject(query),
      ]);

      const response = await this.openai.chat.completions.create({
        model: 'gpt-4o-mini',
        temperature: 0.3,
        max_tokens: 300,
        messages: [
          { role: 'system', content: this.buildSystemPrompt(query) },
          { role: 'user', content: this.buildUserMessage(kpis, grades) },
        ],
      });

      const summary = response.choices[0]?.message?.content?.trim() ?? '';
      return { summary };
    } catch {
      this.logger.warn(
        'AiSummaryService: OpenAI call failed — returning empty summary',
      );
      return { summary: '' };
    }
  }

  private buildSystemPrompt(query: DashboardQueryDto): string {
    const opener = this.resolveOpener(query);
    return (
      'You are an educational data analyst writing a brief Hebrew executive summary for a school principal. ' +
      'Your goal is to surface the most significant insight from the data — not to echo numbers back. ' +
      'Write 2–4 sentences in the style of this example: ' +
      '"בתקופה הנבחרת נצפתה ירידה של 5% בציון הממוצע בכיתה ח-1, בעיקר במתמטיקה. ' +
      'במקביל, נרשמה עלייה של 15% במספר האירועים ההתנהגותיים השליליים." ' +
      `You MUST begin your response with: "${opener}" ` +
      'Rules: ' +
      '(1) Write only in Hebrew. ' +
      '(2) Identify the weakest subject by grade and mention it by name. ' +
      '(3) Connect attendance or behavior trends to academic performance where relevant. ' +
      '(4) Do NOT list raw numbers as bullet points — integrate them naturally into sentences. ' +
      '(5) Do NOT mention individual students. ' +
      '(6) Respond with the Hebrew summary text only.'
    );
  }

  /**
   * Derives the required sentence opener based on the active query filters.
   * Date range takes priority; then class filter; then no-filter fallback.
   */
  private resolveOpener(query: DashboardQueryDto): string {
    if (query.from || query.to) {
      return 'בתקופה הנבחרת';
    }
    if (query.classId) {
      return `בכיתה ${query.classId}`;
    }
    return 'בכלל הכיתות';
  }

  private buildUserMessage(
    kpis: KpiResponseDto,
    grades: ChartDataPointDto[],
  ): string {
    const sortedGrades = [...grades].sort((a, b) => a.value - b.value);
    const gradeLines = sortedGrades
      .map((g) => `  - ${g.label}: ${g.value}/100`)
      .join('\n');
    return [
      `Students in selected scope: ${kpis.totalStudents}`,
      `Overall average grade: ${kpis.averageGrade}/100`,
      `Attendance rate: ${kpis.attendanceRate}% (${kpis.absenceCount} absences recorded)`,
      `Negative behavior incidents: ${kpis.behaviorIncidentCount}`,
      `Average grade by subject (sorted lowest to highest):\n${gradeLines}`,
    ].join('\n');
  }
}
