import OpenAI from 'openai';
import { AiSummaryService } from './ai-summary.service';
import { DashboardService } from './dashboard.service';
import { KpiResponseDto } from './dto/kpi-response.dto';
import { ChartDataPointDto } from './dto/chart-data-response.dto';

// ── Mock the openai module ───────────────────────────────────────────────────

jest.mock('openai');

// ── Mock data ────────────────────────────────────────────────────────────────

const MOCK_KPIS: KpiResponseDto = {
  totalStudents: 30,
  averageGrade: 76.4,
  attendanceRate: 91.2,
  absenceCount: 8,
  behaviorIncidentCount: 3,
};

const MOCK_GRADES: ChartDataPointDto[] = [
  { label: 'מתמטיקה', value: 71.0 },
  { label: 'אנגלית', value: 84.2 },
];

// ── Helpers ──────────────────────────────────────────────────────────────────

function buildMockDashboardService(): jest.Mocked<
  Pick<DashboardService, 'getKpis' | 'getGradesBySubject'>
> {
  return {
    getKpis: jest.fn().mockResolvedValue(MOCK_KPIS),
    getGradesBySubject: jest.fn().mockResolvedValue(MOCK_GRADES),
  };
}

// ── Tests ────────────────────────────────────────────────────────────────────

describe('AiSummaryService', () => {
  let service: AiSummaryService;
  let mockDashboardService: jest.Mocked<
    Pick<DashboardService, 'getKpis' | 'getGradesBySubject'>
  >;
  let mockCreate: jest.Mock;

  beforeEach(() => {
    // AiSummaryService checks process.env.OPENAI_API_KEY in its constructor and
    // sets this.openai = null when the key is absent, bypassing the OpenAI class
    // entirely. Setting a placeholder key here ensures the constructor proceeds
    // to instantiate the mocked OpenAI class.
    process.env['OPENAI_API_KEY'] = 'test-key';

    mockDashboardService = buildMockDashboardService();

    mockCreate = jest.fn().mockResolvedValue({
      choices: [{ message: { content: 'סיכום לדוגמה בעברית.' } }],
    });

    (OpenAI as jest.MockedClass<typeof OpenAI>).mockImplementation(
      () =>
        ({
          chat: { completions: { create: mockCreate } },
        }) as unknown as OpenAI,
    );

    service = new AiSummaryService(
      mockDashboardService as unknown as DashboardService,
    );
  });

  afterEach(() => {
    delete process.env['OPENAI_API_KEY'];
    jest.clearAllMocks();
  });

  // ── Core behaviour ─────────────────────────────────────────────────────────

  it('returns the AI-generated Hebrew summary on success', async () => {
    const result = await service.generateSummary({});

    expect(result.summary).toBe('סיכום לדוגמה בעברית.');
    expect(mockCreate).toHaveBeenCalledWith(
      expect.objectContaining({
        model: 'gpt-4o-mini',
        temperature: 0.3,
        max_tokens: 300,
      }),
    );
    expect(mockDashboardService.getKpis).toHaveBeenCalledWith({});
    expect(mockDashboardService.getGradesBySubject).toHaveBeenCalledWith({});
  });

  it('returns empty summary when OpenAI throws — graceful degradation', async () => {
    mockCreate.mockRejectedValue(new Error('OpenAI API error'));

    const result = await service.generateSummary({});

    expect(result.summary).toBe('');
  });

  it('does not include student names or IDs in the OpenAI prompt', async () => {
    await service.generateSummary({});

    // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
    const messages: OpenAI.Chat.ChatCompletionMessageParam[] =
      // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
      mockCreate.mock.calls[0][0].messages;
    const userContent = messages.find((m) => m.role === 'user')
      ?.content as string;

    expect(userContent).not.toContain('studentId');
    expect(userContent).not.toContain('studentName');
    expect(userContent).not.toContain('Alex');
    expect(userContent).not.toContain('Jordan');
  });

  // ── Context-aware opener ───────────────────────────────────────────────────

  it('uses "בתקופה הנבחרת" opener when a date range is selected (from only)', async () => {
    await service.generateSummary({ from: '2025-09-01' });

    const systemContent = getSystemContent(mockCreate);
    expect(systemContent).toContain('"בתקופה הנבחרת"');
  });

  it('uses "בתקופה הנבחרת" opener when a date range is selected (to only)', async () => {
    await service.generateSummary({ to: '2025-09-30' });

    const systemContent = getSystemContent(mockCreate);
    expect(systemContent).toContain('"בתקופה הנבחרת"');
  });

  it('uses "בכיתה ח-1" opener when a class is selected with no date range', async () => {
    await service.generateSummary({ classId: 'ח-1' });

    const systemContent = getSystemContent(mockCreate);
    expect(systemContent).toContain('"בכיתה ח-1"');
  });

  it('uses "בכלל הכיתות" opener when no filters are selected', async () => {
    await service.generateSummary({});

    const systemContent = getSystemContent(mockCreate);
    expect(systemContent).toContain('"בכלל הכיתות"');
  });

  it('date range takes priority over class filter for opener', async () => {
    await service.generateSummary({
      classId: 'ח-1',
      from: '2025-09-01',
      to: '2025-09-30',
    });

    const systemContent = getSystemContent(mockCreate);
    expect(systemContent).toContain('"בתקופה הנבחרת"');
    expect(systemContent).not.toContain('"בכיתה ח-1"');
  });
});

// ── Utility ───────────────────────────────────────────────────────────────────

function getSystemContent(mockCreate: jest.Mock): string {
  // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
  const messages: OpenAI.Chat.ChatCompletionMessageParam[] =
    // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
    mockCreate.mock.calls[0][0].messages;
  return messages.find((m) => m.role === 'system')?.content as string;
}
