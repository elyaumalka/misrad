import {
  AttendanceEvent,
  BehaviorEvent,
  GradeEvent,
  Student,
} from '../../../common/interfaces';

/**
 * In-memory snapshot of all raw events read from Google Sheets.
 * Owned exclusively by DashboardCacheService — never leave the module boundary.
 * Contains no computed values; aggregation is performed by DashboardService on read.
 */
export interface DashboardSnapshot {
  grades: GradeEvent[];
  attendance: AttendanceEvent[];
  behavior: BehaviorEvent[];
  students: Student[];
}
