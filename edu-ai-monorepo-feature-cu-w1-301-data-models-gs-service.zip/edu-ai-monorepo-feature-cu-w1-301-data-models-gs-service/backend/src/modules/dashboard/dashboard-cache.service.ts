import {
  Injectable,
  Logger,
  OnApplicationBootstrap,
  OnApplicationShutdown,
  ServiceUnavailableException,
} from '@nestjs/common';
import { GoogleSheetsService } from '../../common/services/google-sheets.service';
import { DashboardSnapshot } from './interfaces/dashboard-snapshot.interface';

/**
 * Maintains a typed in-memory snapshot of all Google Sheets data.
 *
 * Refresh triggers (three layers of redundancy):
 *   1. Server startup  — onApplicationBootstrap() seeds the cache immediately.
 *   2. In-process timer — scheduleWeeklySundayRefresh() fires every Sunday at 02:00.
 *   3. GCP Cloud Scheduler — POST /dashboard/sync for cloud-coordinated multi-instance refresh.
 *
 * All dashboard services read exclusively from this snapshot, so Google Sheets
 * is never hit during an end-user HTTP request.
 */
@Injectable()
export class DashboardCacheService
  implements OnApplicationBootstrap, OnApplicationShutdown
{
  private readonly logger = new Logger(DashboardCacheService.name);

  private snapshot: DashboardSnapshot | null = null;
  private lastRefreshedAt: Date | null = null;
  /** Last error message from a failed cache refresh — exposed to callers when no snapshot exists. */
  private lastErrorMessage: string | null = null;
  /** Handle returned by setTimeout — kept so we can cancel it on shutdown. */
  private cronHandle: ReturnType<typeof setTimeout> | null = null;

  constructor(private readonly sheetsService: GoogleSheetsService) {}

  /**
   * Runs once after the DI container is fully initialised.
   * Seeds the cache from Google Sheets and arms the weekly Sunday timer.
   */
  async onApplicationBootstrap(): Promise<void> {
    await this.refreshCache();
    this.scheduleWeeklySundayRefresh();
  }

  /** Cancels the pending timer when the application is shutting down. */
  onApplicationShutdown(): void {
    if (this.cronHandle !== null) {
      clearTimeout(this.cronHandle);
      this.cronHandle = null;
      this.logger.log('Weekly refresh timer cancelled (shutdown).');
    }
  }

  /**
   * Reads all event types from Google Sheets and atomically replaces the snapshot.
   * Any error is caught internally — the previous snapshot (if any) is kept intact.
   * Called on startup, by the in-process timer, and by POST /dashboard/sync.
   */
  async refreshCache(): Promise<void> {
    try {
      const [grades, attendance, behavior, students] = await Promise.all([
        this.sheetsService.getAllGrades(),
        this.sheetsService.getAllAttendance(),
        this.sheetsService.getAllBehaviorEvents(),
        this.sheetsService.getStudents(),
      ]);

      this.snapshot = { grades, attendance, behavior, students };
      this.lastRefreshedAt = new Date();
      this.lastErrorMessage = null;

      this.logger.log(
        `Cache refreshed: grades=${grades.length}, attendance=${attendance.length}, ` +
          `behavior=${behavior.length}, students=${students.length}`,
      );
    } catch (error) {
      this.lastErrorMessage = (error as Error).message;
      this.logger.error(
        `Cache refresh failed — keeping previous snapshot. Error: ${(error as Error).message}`,
      );
    }
  }

  /**
   * Returns the current snapshot.
   * If no snapshot exists (startup read failed), attempts one live fetch before giving up.
   */
  async getData(): Promise<DashboardSnapshot> {
    if (!this.snapshot) {
      this.logger.warn('Snapshot is empty — attempting live fetch.');
      await this.refreshCache();
    }

    if (!this.snapshot) {
      throw new ServiceUnavailableException(
        this.lastErrorMessage ?? 'נתוני Google Sheets אינם זמינים ואין גרסה שמורה.',
      );
    }

    return this.snapshot;
  }

  /** Returns the timestamp of the last successful refresh, or null if never refreshed. */
  getLastRefreshedAt(): Date | null {
    return this.lastRefreshedAt;
  }

  // ── Weekly Sunday 02:00 timer ──────────────────────────────────────────────

  /**
   * Arms a one-shot setTimeout that fires at the next Sunday 02:00 (local server time).
   * After firing it refreshes the cache and immediately re-arms itself for the following
   * Sunday — producing an accurate weekly cadence without any external scheduler.
   */
  private scheduleWeeklySundayRefresh(): void {
    const delayMs = this.msUntilNextSunday2am();
    const nextRun = new Date(Date.now() + delayMs);

    this.logger.log(
      `Weekly refresh scheduled for ${nextRun.toISOString()} ` +
        `(in ${Math.round(delayMs / 3_600_000)}h).`,
    );

    // eslint-disable-next-line @typescript-eslint/no-misused-promises
    this.cronHandle = setTimeout(async () => {
      this.logger.log(
        'Weekly Sunday 02:00 refresh triggered by in-process timer.',
      );
      await this.refreshCache();
      this.scheduleWeeklySundayRefresh(); // arm for next Sunday
    }, delayMs);
  }

  /**
   * Calculates milliseconds from now until the next Sunday at 02:00:00 (local time).
   * Always returns a value in the range (0, 7 * 24 * 3600 * 1000].
   */
  private msUntilNextSunday2am(): number {
    const now = new Date();
    const next = new Date(now);

    // Advance to Sunday (day 0); if today is Sunday but 02:00 has passed, go to next Sunday.
    const daysUntilSunday = (7 - now.getDay()) % 7;
    next.setDate(now.getDate() + daysUntilSunday);
    next.setHours(2, 0, 0, 0);

    if (next.getTime() <= now.getTime()) {
      next.setDate(next.getDate() + 7);
    }

    return next.getTime() - now.getTime();
  }
}
