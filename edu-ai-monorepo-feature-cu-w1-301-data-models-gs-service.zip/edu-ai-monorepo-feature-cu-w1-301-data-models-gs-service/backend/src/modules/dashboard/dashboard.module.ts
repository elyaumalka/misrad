import { Module } from '@nestjs/common';
import { CommonModule } from '../../common/common.module';
import { AiSummaryService } from './ai-summary.service';
import { DashboardCacheService } from './dashboard-cache.service';
import { DashboardController } from './dashboard.controller';
import { DashboardService } from './dashboard.service';

@Module({
  imports: [CommonModule],
  controllers: [DashboardController],
  providers: [DashboardCacheService, DashboardService, AiSummaryService],
  // Services are not exported — dashboard data is accessed via its HTTP endpoints only
})
export class DashboardModule {}
