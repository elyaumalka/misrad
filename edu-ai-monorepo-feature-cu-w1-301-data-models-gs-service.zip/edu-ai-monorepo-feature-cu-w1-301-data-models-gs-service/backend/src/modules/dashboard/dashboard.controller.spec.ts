/**
 * HTTP-layer integration tests for DashboardController.
 *
 * Scope: verifies query-string parsing, DashboardQueryDto validation,
 * response shapes, and the sync-endpoint auth guard.
 * Business-logic correctness is covered by dashboard.integration.spec.ts —
 * service mocks here always return minimal stub values.
 *
 * Setup: NestJS test application with ValidationPipe (transform + whitelist),
 * mirroring the production main.ts configuration.
 */

import { INestApplication, ValidationPipe } from '@nestjs/common';
import { Test, TestingModule } from '@nestjs/testing';
import request = require('supertest');
import { AiSummaryService } from './ai-summary.service';
import { DashboardCacheService } from './dashboard-cache.service';
import { DashboardController } from './dashboard.controller';
import { DashboardService } from './dashboard.service';

// ── Stub responses ────────────────────────────────────────────────────────────

const STUB_KPIS = {
  totalStudents: 5,
  averageGrade: 72.6,
  attendanceRate: 50.0,
  absenceCount: 5,
  behaviorIncidentCount: 4,
};

const STUB_CHART_POINTS = [
  { label: 'מתמטיקה', value: 73.6 },
  { label: 'אנגלית', value: 70.0 },
];

const STUB_CHART_DATA = {
  gradesBySubject: [{ label: 'מתמטיקה', value: 73.6 }],
  weeklyAbsences: [{ label: '2025-W36', value: 3 }],
  behaviorByStudent: [{ label: 'S102', value: 2 }],
};

const STUB_SUMMARY = { summary: 'סיכום לדוגמה.' };

// ── Test suite ────────────────────────────────────────────────────────────────

describe('DashboardController (HTTP / query-string parsing)', () => {
  let app: INestApplication;
  let mockService: jest.Mocked<
    Pick<
      DashboardService,
      | 'getKpis'
      | 'getGradesBySubject'
      | 'getBehaviorOverTime'
      | 'getChartData'
      | 'getAvailableClasses'
    >
  >;
  let mockAiService: jest.Mocked<Pick<AiSummaryService, 'generateSummary'>>;
  let mockCache: jest.Mocked<
    Pick<DashboardCacheService, 'getLastRefreshedAt' | 'refreshCache'>
  >;

  beforeEach(async () => {
    mockService = {
      getKpis: jest.fn().mockResolvedValue(STUB_KPIS),
      getGradesBySubject: jest.fn().mockResolvedValue(STUB_CHART_POINTS),
      getBehaviorOverTime: jest.fn().mockResolvedValue(STUB_CHART_POINTS),
      getChartData: jest.fn().mockResolvedValue(STUB_CHART_DATA),
      getAvailableClasses: jest
        .fn()
        .mockResolvedValue({ classes: ['ח-1', 'ח-2'] }),
    };

    mockAiService = {
      generateSummary: jest.fn().mockResolvedValue(STUB_SUMMARY),
    };

    mockCache = {
      getLastRefreshedAt: jest
        .fn()
        .mockReturnValue(new Date('2025-09-01T02:00:00Z')),
      refreshCache: jest.fn().mockResolvedValue(undefined),
    };

    const module: TestingModule = await Test.createTestingModule({
      controllers: [DashboardController],
      providers: [
        { provide: DashboardService, useValue: mockService },
        { provide: AiSummaryService, useValue: mockAiService },
        { provide: DashboardCacheService, useValue: mockCache },
      ],
    }).compile();

    app = module.createNestApplication();
    // Mirror the ValidationPipe setup from main.ts:
    //   transform: true  — coerces raw query strings into DTO class instances
    //   whitelist: true  — strips any query params not declared in the DTO
    app.useGlobalPipes(
      new ValidationPipe({ transform: true, whitelist: true }),
    );
    await app.init();
  });

  afterEach(async () => {
    jest.clearAllMocks();
    await app.close();
  });

  // ── GET /dashboard/kpis ──────────────────────────────────────────────────────

  describe('GET /dashboard/kpis', () => {
    it('returns 200 with full KPI shape when no query params are supplied', async () => {
      const res = await request(app.getHttpServer())
        .get('/dashboard/kpis')
        .expect(200);

      expect(res.body).toMatchObject(STUB_KPIS);
    });

    it('forwards classId to the service', async () => {
      await request(app.getHttpServer())
        .get('/dashboard/kpis')
        .query({ classId: 'ח-1' })
        .expect(200);

      expect(mockService.getKpis).toHaveBeenCalledWith(
        expect.objectContaining({ classId: 'ח-1' }),
      );
    });

    it('forwards from and to date strings to the service', async () => {
      await request(app.getHttpServer())
        .get('/dashboard/kpis')
        .query({ from: '2025-09-01', to: '2025-09-30' })
        .expect(200);

      expect(mockService.getKpis).toHaveBeenCalledWith(
        expect.objectContaining({ from: '2025-09-01', to: '2025-09-30' }),
      );
    });

    it('forwards all three params simultaneously', async () => {
      await request(app.getHttpServer())
        .get('/dashboard/kpis')
        .query({ classId: 'ח-1', from: '2025-09-01', to: '2025-09-30' })
        .expect(200);

      expect(mockService.getKpis).toHaveBeenCalledWith(
        expect.objectContaining({
          classId: 'ח-1',
          from: '2025-09-01',
          to: '2025-09-30',
        }),
      );
    });

    it('returns 400 when from is not a valid ISO 8601 date', async () => {
      await request(app.getHttpServer())
        .get('/dashboard/kpis')
        .query({ from: 'not-a-date' })
        .expect(400);
    });

    it('returns 400 when to is in DD/MM/YYYY format (not ISO 8601)', async () => {
      await request(app.getHttpServer())
        .get('/dashboard/kpis')
        .query({ to: '15/09/2025' })
        .expect(400);
    });

    it('strips unknown query params — service is not called with undeclared fields', async () => {
      await request(app.getHttpServer())
        .get('/dashboard/kpis')
        .query({ classId: 'ח-1', undeclaredField: 'should-be-stripped' })
        .expect(200);

      const calledWith = mockService.getKpis.mock.calls[0][0] as Record<
        string,
        unknown
      >;
      expect(calledWith).not.toHaveProperty('undeclaredField');
    });
  });

  // ── GET /dashboard/grades-by-subject ────────────────────────────────────────

  describe('GET /dashboard/grades-by-subject', () => {
    it('returns 200 with an array of { label, value } points', async () => {
      const res = await request(app.getHttpServer())
        .get('/dashboard/grades-by-subject')
        .expect(200);

      expect(Array.isArray(res.body)).toBe(true);
      expect(res.body[0]).toMatchObject({
        label: expect.any(String),
        value: expect.any(Number),
      });
    });

    it('forwards classId to the service', async () => {
      await request(app.getHttpServer())
        .get('/dashboard/grades-by-subject')
        .query({ classId: 'ח-1' })
        .expect(200);

      expect(mockService.getGradesBySubject).toHaveBeenCalledWith(
        expect.objectContaining({ classId: 'ח-1' }),
      );
    });

    it('returns 400 when from is invalid', async () => {
      await request(app.getHttpServer())
        .get('/dashboard/grades-by-subject')
        .query({ from: 'bad-date' })
        .expect(400);
    });
  });

  // ── GET /dashboard/behavior-over-time ───────────────────────────────────────

  describe('GET /dashboard/behavior-over-time', () => {
    it('returns 200 with an array of { label, value } points', async () => {
      const res = await request(app.getHttpServer())
        .get('/dashboard/behavior-over-time')
        .expect(200);

      expect(Array.isArray(res.body)).toBe(true);
    });

    it('forwards date range to the service', async () => {
      await request(app.getHttpServer())
        .get('/dashboard/behavior-over-time')
        .query({ from: '2025-09-01', to: '2025-09-30' })
        .expect(200);

      expect(mockService.getBehaviorOverTime).toHaveBeenCalledWith(
        expect.objectContaining({ from: '2025-09-01', to: '2025-09-30' }),
      );
    });
  });

  // ── GET /dashboard/charts ────────────────────────────────────────────────────

  describe('GET /dashboard/charts', () => {
    it('returns 200 with ChartDataResponse shape', async () => {
      const res = await request(app.getHttpServer())
        .get('/dashboard/charts')
        .expect(200);

      expect(res.body).toHaveProperty('gradesBySubject');
      expect(res.body).toHaveProperty('weeklyAbsences');
      expect(res.body).toHaveProperty('behaviorByStudent');
      expect(Array.isArray(res.body.gradesBySubject)).toBe(true);
      expect(Array.isArray(res.body.weeklyAbsences)).toBe(true);
      expect(Array.isArray(res.body.behaviorByStudent)).toBe(true);
    });

    it('forwards classId and date range together', async () => {
      await request(app.getHttpServer())
        .get('/dashboard/charts')
        .query({ classId: 'ח-2', from: '2025-09-01' })
        .expect(200);

      expect(mockService.getChartData).toHaveBeenCalledWith(
        expect.objectContaining({ classId: 'ח-2', from: '2025-09-01' }),
      );
    });
  });

  // ── GET /dashboard/summary ──────────────────────────────────────────────────

  describe('GET /dashboard/summary', () => {
    it('returns 200 with a summary string', async () => {
      const res = await request(app.getHttpServer())
        .get('/dashboard/summary')
        .expect(200);

      expect(res.body).toHaveProperty('summary');
      expect(typeof res.body.summary).toBe('string');
    });

    it('forwards query params to AiSummaryService.generateSummary', async () => {
      await request(app.getHttpServer())
        .get('/dashboard/summary')
        .query({ classId: 'ח-1', from: '2025-09-01' })
        .expect(200);

      expect(mockAiService.generateSummary).toHaveBeenCalledWith(
        expect.objectContaining({ classId: 'ח-1', from: '2025-09-01' }),
      );
    });
  });

  // ── GET /dashboard/classes ──────────────────────────────────────────────────

  describe('GET /dashboard/classes', () => {
    it('returns 200 with a classes string array', async () => {
      const res = await request(app.getHttpServer())
        .get('/dashboard/classes')
        .expect(200);

      expect(res.body).toHaveProperty('classes');
      expect(Array.isArray(res.body.classes)).toBe(true);
      res.body.classes.forEach((c: unknown) => expect(typeof c).toBe('string'));
    });
  });

  // ── GET /dashboard/cache-status ─────────────────────────────────────────────

  describe('GET /dashboard/cache-status', () => {
    it('returns 200 with an ISO 8601 lastRefreshedAt string', async () => {
      const res = await request(app.getHttpServer())
        .get('/dashboard/cache-status')
        .expect(200);

      expect(res.body).toHaveProperty('lastRefreshedAt');
      expect(typeof res.body.lastRefreshedAt).toBe('string');
      // Verify the timestamp is a valid ISO 8601 string
      expect(new Date(res.body.lastRefreshedAt as string).toISOString()).toBe(
        res.body.lastRefreshedAt,
      );
    });

    it('returns lastRefreshedAt: null when the cache has not yet been seeded', async () => {
      mockCache.getLastRefreshedAt.mockReturnValueOnce(null);

      const res = await request(app.getHttpServer())
        .get('/dashboard/cache-status')
        .expect(200);

      expect(res.body.lastRefreshedAt).toBeNull();
    });
  });

  // ── POST /dashboard/sync ────────────────────────────────────────────────────

  describe('POST /dashboard/sync', () => {
    it('returns 401 when x-sync-secret header is absent', async () => {
      await request(app.getHttpServer()).post('/dashboard/sync').expect(401);
    });

    it('returns 401 when x-sync-secret header value is wrong', async () => {
      process.env['DASHBOARD_SYNC_SECRET'] = 'correct-secret';
      await request(app.getHttpServer())
        .post('/dashboard/sync')
        .set('x-sync-secret', 'wrong-secret')
        .expect(401);
      delete process.env['DASHBOARD_SYNC_SECRET'];
    });

    it('returns 200 and calls refreshCache when the correct secret is supplied', async () => {
      process.env['DASHBOARD_SYNC_SECRET'] = 'correct-secret';

      const res = await request(app.getHttpServer())
        .post('/dashboard/sync')
        .set('x-sync-secret', 'correct-secret')
        .expect(201); // NestJS default for @Post — no @HttpCode override on this endpoint

      expect(mockCache.refreshCache).toHaveBeenCalledTimes(1);
      expect(res.body).toHaveProperty('lastRefreshedAt');
      delete process.env['DASHBOARD_SYNC_SECRET'];
    });
  });
});
