import { Logger } from '@nestjs/common';
import { Test, TestingModule } from '@nestjs/testing';
import { EventType } from '../../common/enums/event-type.enum';
import {
  AttendanceEvent,
  BehaviorEvent,
  GradeEvent,
  Student,
} from '../../common/interfaces';
import { DashboardCacheService } from './dashboard-cache.service';
import { DashboardSnapshot } from './interfaces/dashboard-snapshot.interface';
import { DashboardService } from './dashboard.service';

// ── Mock data ────────────────────────────────────────────────────────────────

const MOCK_STUDENTS: Student[] = [
  { studentId: 'S101', studentName: 'Alex Morgan', classId: 'ח-1' },
  { studentId: 'S102', studentName: 'Jordan Lee', classId: 'ח-1' },
];

const MOCK_GRADES: GradeEvent[] = [
  {
    eventId: '1001',
    studentId: 'S101',
    studentName: 'Alex Morgan',
    classId: 'ח-1',
    eventDate: new Date(Date.UTC(2025, 8, 1)),
    eventType: EventType.GRADE,
    eventSubject: 'מתמטיקה',
    eventValue: 80,
  },
  {
    eventId: '1002',
    studentId: 'S102',
    studentName: 'Jordan Lee',
    classId: 'ח-1',
    eventDate: new Date(Date.UTC(2025, 8, 1)),
    eventType: EventType.GRADE,
    eventSubject: 'מתמטיקה',
    eventValue: 60,
  },
  {
    eventId: '1003',
    studentId: 'S101',
    studentName: 'Alex Morgan',
    classId: 'ח-1',
    eventDate: new Date(Date.UTC(2025, 8, 5)),
    eventType: EventType.GRADE,
    eventSubject: 'אנגלית',
    eventValue: 90,
  },
];

const MOCK_ATTENDANCE: AttendanceEvent[] = [
  {
    eventId: '2001',
    studentId: 'S101',
    studentName: 'Alex Morgan',
    classId: 'ח-1',
    eventDate: new Date(Date.UTC(2025, 8, 2)),
    eventType: EventType.ATTENDANCE,
    eventValue: 0, // present
  },
  {
    eventId: '2002',
    studentId: 'S102',
    studentName: 'Jordan Lee',
    classId: 'ח-1',
    eventDate: new Date(Date.UTC(2025, 8, 2)),
    eventType: EventType.ATTENDANCE,
    eventValue: 1, // absent
  },
  {
    eventId: '2003',
    studentId: 'S101',
    studentName: 'Alex Morgan',
    classId: 'ח-1',
    eventDate: new Date(Date.UTC(2025, 8, 9)),
    eventType: EventType.ATTENDANCE,
    eventValue: 1, // absent
  },
  {
    eventId: '2004',
    studentId: 'S102',
    studentName: 'Jordan Lee',
    classId: 'ח-1',
    eventDate: new Date(Date.UTC(2025, 8, 9)),
    eventType: EventType.ATTENDANCE,
    eventValue: 0, // present
  },
];

const MOCK_BEHAVIOR: BehaviorEvent[] = [
  {
    eventId: '3001',
    studentId: 'S102',
    studentName: 'Jordan Lee',
    classId: 'ח-1',
    eventDate: new Date(Date.UTC(2025, 8, 3)),
    eventType: EventType.BEHAVIOR,
    eventValue: 1,
    eventDescription: 'הפרעה בשיעור',
  },
  {
    eventId: '3002',
    studentId: 'S102',
    studentName: 'Jordan Lee',
    classId: 'ח-1',
    eventDate: new Date(Date.UTC(2025, 8, 10)),
    eventType: EventType.BEHAVIOR,
    eventValue: 1,
    eventDescription: 'הפרעה חוזרת',
  },
];

// ── Snapshot builder ─────────────────────────────────────────────────────────

/**
 * Builds a DashboardSnapshot with optional per-field overrides.
 * Unspecified fields default to the standard MOCK_* arrays above.
 */
function buildSnapshot(overrides: Partial<DashboardSnapshot> = {}): DashboardSnapshot {
  return {
    grades: overrides.grades ?? MOCK_GRADES,
    attendance: overrides.attendance ?? MOCK_ATTENDANCE,
    behavior: overrides.behavior ?? MOCK_BEHAVIOR,
    students: overrides.students ?? MOCK_STUDENTS,
  };
}

// ── Tests ─────────────────────────────────────────────────────────────────────

describe('DashboardService', () => {
  let service: DashboardService;
  let loggerSpy: jest.SpyInstance;
  let mockCacheService: { getData: jest.Mock };

  beforeEach(async () => {
    mockCacheService = {
      getData: jest.fn().mockResolvedValue(buildSnapshot()),
    };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        DashboardService,
        {
          provide: DashboardCacheService,
          useValue: mockCacheService,
        },
      ],
    }).compile();

    service = module.get<DashboardService>(DashboardService);

    loggerSpy = jest
      .spyOn(Logger.prototype, 'log')
      .mockImplementation(() => undefined);
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  /** Asserts that no log message contains any PII value from the mock data. */
  const assertNoPiiInLogs = (): void => {
    const piiValues = [
      ...MOCK_STUDENTS.flatMap((s) => [s.studentId, s.studentName]),
    ];
    // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
    const loggedMessages = loggerSpy.mock.calls.map((args) => String(args[0]));

    for (const message of loggedMessages) {
      for (const pii of piiValues) {
        expect(message).not.toContain(pii);
      }
    }
  };

  // ── getKpis ──────────────────────────────────────────────────────────────

  describe('getKpis', () => {
    it('should return the correct total number of students', async () => {
      const result = await service.getKpis();
      expect(result.totalStudents).toBe(MOCK_STUDENTS.length);
    });

    it('should calculate the correct average grade', async () => {
      // (80 + 60 + 90) / 3 = 76.7
      const result = await service.getKpis();
      expect(result.averageGrade).toBe(76.7);
    });

    it('should calculate the correct attendance rate', async () => {
      // 2 present out of 4 total = 50.0%
      const result = await service.getKpis();
      expect(result.attendanceRate).toBe(50.0);
    });

    it('should count the correct number of behavior incidents', async () => {
      const result = await service.getKpis();
      expect(result.behaviorIncidentCount).toBe(MOCK_BEHAVIOR.length);
    });

    it('should return 0 averageGrade when there are no grades', async () => {
      mockCacheService.getData.mockResolvedValueOnce(buildSnapshot({ grades: [] }));
      const result = await service.getKpis();
      expect(result.averageGrade).toBe(0);
    });

    it('should return 0 attendanceRate when there are no attendance events', async () => {
      mockCacheService.getData.mockResolvedValueOnce(buildSnapshot({ attendance: [] }));
      const result = await service.getKpis();
      expect(result.attendanceRate).toBe(0);
    });

    it('should return the correct absence count', async () => {
      // MOCK_ATTENDANCE has 2 absent records (eventValue === 1)
      const result = await service.getKpis();
      const expectedAbsences = MOCK_ATTENDANCE.filter(
        (a) => a.eventValue === 1,
      ).length;
      expect(result.absenceCount).toBe(expectedAbsences);
    });

    it('should not log any PII values', async () => {
      await service.getKpis();
      assertNoPiiInLogs();
    });
  });

  // ── getGradesBySubject ────────────────────────────────────────────────────

  describe('getGradesBySubject', () => {
    it('should return one entry per subject', async () => {
      const result = await service.getGradesBySubject();
      const subjects = result.map((p) => p.label);
      expect(subjects).toContain('מתמטיקה');
      expect(subjects).toContain('אנגלית');
    });

    it('should compute the correct average per subject', async () => {
      const result = await service.getGradesBySubject();
      const math = result.find((p) => p.label === 'מתמטיקה');
      // (80 + 60) / 2 = 70.0
      expect(math?.value).toBe(70.0);
    });

    it('should return an empty array when there are no grades', async () => {
      mockCacheService.getData.mockResolvedValueOnce(buildSnapshot({ grades: [] }));
      const result = await service.getGradesBySubject();
      expect(result).toHaveLength(0);
    });

    it('should not log any PII values', async () => {
      await service.getGradesBySubject();
      assertNoPiiInLogs();
    });
  });

  // ── getBehaviorOverTime ───────────────────────────────────────────────────

  describe('getBehaviorOverTime', () => {
    it('should return one entry per week that had incidents', async () => {
      // MOCK_BEHAVIOR: S102 on Sep 3 (W36) and Sep 10 (W37) → 2 weeks
      const result = await service.getBehaviorOverTime();
      expect(result).toHaveLength(2);
    });

    it('should count only events with eventValue === 1', async () => {
      mockCacheService.getData.mockResolvedValueOnce(
        buildSnapshot({
          behavior: [
            { ...MOCK_BEHAVIOR[0], eventValue: 0 }, // non-incident — must not count
            MOCK_BEHAVIOR[1],
          ],
        }),
      );
      const result = await service.getBehaviorOverTime();
      const total = result.reduce((sum, p) => sum + p.value, 0);
      expect(total).toBe(1);
    });

    it('should return entries sorted by ISO week label', async () => {
      const result = await service.getBehaviorOverTime();
      const labels = result.map((p) => p.label);
      expect(labels).toEqual([...labels].sort());
    });

    it('should return an empty array when there are no behavior events', async () => {
      mockCacheService.getData.mockResolvedValueOnce(buildSnapshot({ behavior: [] }));
      const result = await service.getBehaviorOverTime();
      expect(result).toHaveLength(0);
    });

    it('should not log any PII values', async () => {
      await service.getBehaviorOverTime();
      assertNoPiiInLogs();
    });
  });

  // ── getChartData ─────────────────────────────────────────────────────────

  describe('getChartData', () => {
    it('should return gradesBySubject with the correct subjects', async () => {
      const result = await service.getChartData();
      const subjects = result.gradesBySubject.map((p) => p.label);
      expect(subjects).toContain('מתמטיקה');
      expect(subjects).toContain('אנגלית');
    });

    it('should compute the correct average grade per subject', async () => {
      const result = await service.getChartData();
      const math = result.gradesBySubject.find((p) => p.label === 'מתמטיקה');
      // (80 + 60) / 2 = 70.0
      expect(math?.value).toBe(70.0);
    });

    it('should return weeklyAbsences sorted by week label', async () => {
      const result = await service.getChartData();
      const labels = result.weeklyAbsences.map((p) => p.label);
      expect(labels).toEqual([...labels].sort());
    });

    it('should count only absent records (eventValue === 1) in weeklyAbsences', async () => {
      const result = await service.getChartData();
      const totalAbsences = result.weeklyAbsences.reduce(
        (sum, p) => sum + p.value,
        0,
      );
      const expectedAbsences = MOCK_ATTENDANCE.filter(
        (a) => a.eventValue === 1,
      ).length;
      expect(totalAbsences).toBe(expectedAbsences);
    });

    it('should use studentId (not studentName) as label in behaviorByStudent', async () => {
      const result = await service.getChartData();
      const labels = result.behaviorByStudent.map((p) => p.label);
      const studentNames = MOCK_STUDENTS.map((s) => s.studentName);
      for (const label of labels) {
        expect(studentNames).not.toContain(label);
      }
    });

    it('should count behavior incidents correctly per student', async () => {
      const result = await service.getChartData();
      const s102 = result.behaviorByStudent.find((p) => p.label === 'S102');
      expect(s102?.value).toBe(2);
    });

    it('should not log any PII values', async () => {
      await service.getChartData();
      assertNoPiiInLogs();
    });
  });

  // ── getAvailableClasses ───────────────────────────────────────────────────

  describe('getAvailableClasses', () => {
    it('should return an object with a classes array', async () => {
      const result = await service.getAvailableClasses();
      expect(result).toHaveProperty('classes');
      expect(Array.isArray(result.classes)).toBe(true);
    });

    it('should deduplicate class IDs', async () => {
      // MOCK_STUDENTS has two students both in 'ח-1'
      const result = await service.getAvailableClasses();
      expect(result.classes).toHaveLength(1);
      expect(result.classes[0]).toBe('ח-1');
    });

    it('should return sorted class IDs', async () => {
      mockCacheService.getData.mockResolvedValueOnce(
        buildSnapshot({
          students: [
            { studentId: 'S103', studentName: 'Test User', classId: 'ח-2' },
            { studentId: 'S101', studentName: 'Alex Morgan', classId: 'ח-1' },
          ],
        }),
      );
      const result = await service.getAvailableClasses();
      expect(result.classes).toEqual(['ח-1', 'ח-2']);
    });

    it('should return an empty array when there are no students', async () => {
      mockCacheService.getData.mockResolvedValueOnce(buildSnapshot({ students: [] }));
      const result = await service.getAvailableClasses();
      expect(result.classes).toHaveLength(0);
    });

    it('should not log any PII values', async () => {
      await service.getAvailableClasses();
      assertNoPiiInLogs();
    });
  });
});

// ── Filtering tests (multi-class mock data) ───────────────────────────────────
//
// These tests use a separate module with two classes:
//   ח-1  — S101, S102  — events in September 2025
//   ח-2  — S103, S104  — events in October 2025
// This clean separation lets each filter dimension be tested in isolation.

const CLASS1 = 'ח-1';
const CLASS2 = 'ח-2';

const MULTI_STUDENTS: Student[] = [
  { studentId: 'S101', studentName: 'Alex Morgan', classId: CLASS1 },
  { studentId: 'S102', studentName: 'Jordan Lee', classId: CLASS1 },
  { studentId: 'S103', studentName: 'Riley Parker', classId: CLASS2 },
  { studentId: 'S104', studentName: 'Casey Brown', classId: CLASS2 },
];

const MULTI_GRADES: GradeEvent[] = [
  // ח-1 — September
  {
    eventId: '1001',
    studentId: 'S101',
    studentName: 'Alex Morgan',
    classId: CLASS1,
    eventDate: new Date(Date.UTC(2025, 8, 1)), // 01/09/2025
    eventType: EventType.GRADE,
    eventSubject: 'מתמטיקה',
    eventValue: 80,
  },
  {
    eventId: '1002',
    studentId: 'S102',
    studentName: 'Jordan Lee',
    classId: CLASS1,
    eventDate: new Date(Date.UTC(2025, 8, 5)), // 05/09/2025
    eventType: EventType.GRADE,
    eventSubject: 'מתמטיקה',
    eventValue: 60,
  },
  // ח-2 — October
  {
    eventId: '1003',
    studentId: 'S103',
    studentName: 'Riley Parker',
    classId: CLASS2,
    eventDate: new Date(Date.UTC(2025, 9, 1)), // 01/10/2025
    eventType: EventType.GRADE,
    eventSubject: 'מתמטיקה',
    eventValue: 90,
  },
  {
    eventId: '1004',
    studentId: 'S104',
    studentName: 'Casey Brown',
    classId: CLASS2,
    eventDate: new Date(Date.UTC(2025, 9, 10)), // 10/10/2025
    eventType: EventType.GRADE,
    eventSubject: 'אנגלית',
    eventValue: 70,
  },
];

const MULTI_ATTENDANCE: AttendanceEvent[] = [
  // ח-1 — September
  {
    eventId: '2001',
    studentId: 'S101',
    studentName: 'Alex Morgan',
    classId: CLASS1,
    eventDate: new Date(Date.UTC(2025, 8, 2)),
    eventType: EventType.ATTENDANCE,
    eventValue: 1, // absent
  },
  {
    eventId: '2002',
    studentId: 'S102',
    studentName: 'Jordan Lee',
    classId: CLASS1,
    eventDate: new Date(Date.UTC(2025, 8, 9)),
    eventType: EventType.ATTENDANCE,
    eventValue: 0, // present
  },
  // ח-2 — October
  {
    eventId: '2003',
    studentId: 'S103',
    studentName: 'Riley Parker',
    classId: CLASS2,
    eventDate: new Date(Date.UTC(2025, 9, 3)),
    eventType: EventType.ATTENDANCE,
    eventValue: 1, // absent
  },
  {
    eventId: '2004',
    studentId: 'S104',
    studentName: 'Casey Brown',
    classId: CLASS2,
    eventDate: new Date(Date.UTC(2025, 9, 3)),
    eventType: EventType.ATTENDANCE,
    eventValue: 1, // absent
  },
];

const MULTI_BEHAVIOR: BehaviorEvent[] = [
  // ח-1 — September
  {
    eventId: '3001',
    studentId: 'S101',
    studentName: 'Alex Morgan',
    classId: CLASS1,
    eventDate: new Date(Date.UTC(2025, 8, 3)),
    eventType: EventType.BEHAVIOR,
    eventValue: 1,
  },
  // ח-2 — October
  {
    eventId: '3002',
    studentId: 'S103',
    studentName: 'Riley Parker',
    classId: CLASS2,
    eventDate: new Date(Date.UTC(2025, 9, 5)),
    eventType: EventType.BEHAVIOR,
    eventValue: 1,
  },
];

/**
 * Builds a DashboardSnapshot from the multi-class mock data with optional overrides.
 */
function buildMultiSnapshot(
  overrides: Partial<DashboardSnapshot> = {},
): DashboardSnapshot {
  return {
    grades: overrides.grades ?? MULTI_GRADES,
    attendance: overrides.attendance ?? MULTI_ATTENDANCE,
    behavior: overrides.behavior ?? MULTI_BEHAVIOR,
    students: overrides.students ?? MULTI_STUDENTS,
  };
}

describe('DashboardService — filtering', () => {
  let service: DashboardService;
  let mockCacheService: { getData: jest.Mock };

  beforeEach(async () => {
    mockCacheService = {
      getData: jest.fn().mockResolvedValue(buildMultiSnapshot()),
    };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        DashboardService,
        {
          provide: DashboardCacheService,
          useValue: mockCacheService,
        },
      ],
    }).compile();

    service = module.get<DashboardService>(DashboardService);
    jest.spyOn(Logger.prototype, 'log').mockImplementation(() => undefined);
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  // ── getKpis — classId filter ────────────────────────────────────────────

  describe('getKpis — classId filter', () => {
    it('should return only students from the requested class', async () => {
      const result = await service.getKpis({ classId: CLASS1 });
      expect(result.totalStudents).toBe(2); // S101, S102
    });

    it('should compute averageGrade for the requested class only', async () => {
      // CLASS1 grades: 80 + 60 = 140 / 2 = 70.0
      const result = await service.getKpis({ classId: CLASS1 });
      expect(result.averageGrade).toBe(70.0);
    });

    it('should count absences for the requested class only', async () => {
      // CLASS1 attendance: 1 absent (S101), 1 present (S102)
      const result = await service.getKpis({ classId: CLASS1 });
      expect(result.absenceCount).toBe(1);
    });

    it('should count behavior incidents for the requested class only', async () => {
      // CLASS1 behavior: 1 incident (S101)
      const result = await service.getKpis({ classId: CLASS1 });
      expect(result.behaviorIncidentCount).toBe(1);
    });

    it('should return zero counts when classId matches no events', async () => {
      const result = await service.getKpis({ classId: 'ח-99' });
      expect(result.totalStudents).toBe(0);
      expect(result.averageGrade).toBe(0);
      expect(result.absenceCount).toBe(0);
      expect(result.behaviorIncidentCount).toBe(0);
    });
  });

  // ── getKpis — date range filter ─────────────────────────────────────────

  describe('getKpis — date range filter', () => {
    it('should include only events on or after the from date', async () => {
      // October events only (CLASS2)
      const result = await service.getKpis({ from: '2025-10-01' });
      expect(result.totalStudents).toBe(2); // S103, S104
    });

    it('should include only events on or before the to date', async () => {
      // September events only (CLASS1)
      const result = await service.getKpis({ to: '2025-09-30' });
      expect(result.totalStudents).toBe(2); // S101, S102
    });

    it('should include events on the exact from and to boundary dates', async () => {
      // Only CLASS2 grade on exactly 2025-10-01
      const result = await service.getKpis({
        from: '2025-10-01',
        to: '2025-10-01',
      });
      expect(result.averageGrade).toBe(90); // only S103 grade
    });

    it('should return zero counts when no events fall in the date range', async () => {
      const result = await service.getKpis({
        from: '2020-01-01',
        to: '2020-12-31',
      });
      expect(result.totalStudents).toBe(0);
      expect(result.absenceCount).toBe(0);
    });
  });

  // ── getKpis — combined classId + date range ──────────────────────────────

  describe('getKpis — combined classId and date range', () => {
    it('should apply both classId and date range simultaneously', async () => {
      // CLASS2 in October: S103 grade (90), S104 grade (70)
      const result = await service.getKpis({
        classId: CLASS2,
        from: '2025-10-01',
        to: '2025-10-31',
      });
      expect(result.totalStudents).toBe(2); // S103, S104
      // avg = (90 + 70) / 2 = 80.0
      expect(result.averageGrade).toBe(80.0);
    });

    it('should return empty when classId and date range do not overlap', async () => {
      // CLASS1 students have no October events
      const result = await service.getKpis({
        classId: CLASS1,
        from: '2025-10-01',
        to: '2025-10-31',
      });
      expect(result.totalStudents).toBe(0);
    });
  });

  // ── getGradesBySubject — filtering ───────────────────────────────────────

  describe('getGradesBySubject — classId filter', () => {
    it('should return only subjects from the requested class', async () => {
      // CLASS1 only has מתמטיקה
      const result = await service.getGradesBySubject({ classId: CLASS1 });
      const subjects = result.map((p) => p.label);
      expect(subjects).toContain('מתמטיקה');
      expect(subjects).not.toContain('אנגלית'); // אנגלית is CLASS2 only
    });

    it('should return empty array when classId matches no grades', async () => {
      const result = await service.getGradesBySubject({ classId: 'ח-99' });
      expect(result).toHaveLength(0);
    });
  });

  describe('getGradesBySubject — date range filter', () => {
    it('should exclude subjects from outside the date range', async () => {
      // September only: CLASS1 has מתמטיקה — CLASS2 אנגלית is October only
      const result = await service.getGradesBySubject({ to: '2025-09-30' });
      const subjects = result.map((p) => p.label);
      expect(subjects).toContain('מתמטיקה');
      expect(subjects).not.toContain('אנגלית');
    });

    it('should compute correct average limited to date range', async () => {
      // September only: CLASS1 math grades 80 + 60 = avg 70
      const result = await service.getGradesBySubject({ to: '2025-09-30' });
      const math = result.find((p) => p.label === 'מתמטיקה');
      expect(math?.value).toBe(70.0);
    });
  });

  // ── getBehaviorOverTime — filtering ──────────────────────────────────────

  describe('getBehaviorOverTime — classId filter', () => {
    it('should count incidents only for the requested class', async () => {
      // CLASS1 has 1 incident (S101 in Sep)
      const result = await service.getBehaviorOverTime({ classId: CLASS1 });
      const total = result.reduce((sum, p) => sum + p.value, 0);
      expect(total).toBe(1);
    });

    it('should return empty array when classId has no incidents', async () => {
      const result = await service.getBehaviorOverTime({ classId: 'ח-99' });
      expect(result).toHaveLength(0);
    });
  });

  describe('getBehaviorOverTime — date range filter', () => {
    it('should include only incidents within the date range', async () => {
      // October only: CLASS2 incident (S103)
      const result = await service.getBehaviorOverTime({ from: '2025-10-01' });
      const total = result.reduce((sum, p) => sum + p.value, 0);
      expect(total).toBe(1);
    });

    it('should return empty array when no incidents fall in the date range', async () => {
      const result = await service.getBehaviorOverTime({
        from: '2020-01-01',
        to: '2020-12-31',
      });
      expect(result).toHaveLength(0);
    });
  });

  // ── getChartData — classId filter ────────────────────────────────────────

  describe('getChartData — classId filter', () => {
    it('should return only subjects from the requested class', async () => {
      // CLASS1 only has מתמטיקה grades
      const result = await service.getChartData({ classId: CLASS1 });
      const subjects = result.gradesBySubject.map((p) => p.label);
      expect(subjects).toContain('מתמטיקה');
      expect(subjects).not.toContain('אנגלית'); // אנגלית is CLASS2 only
    });

    it('should count absences only for the requested class', async () => {
      // CLASS2 has 2 absences in October
      const result = await service.getChartData({ classId: CLASS2 });
      const totalAbsences = result.weeklyAbsences.reduce(
        (sum, p) => sum + p.value,
        0,
      );
      expect(totalAbsences).toBe(2);
    });

    it('should count behavior incidents only for the requested class', async () => {
      // CLASS1 has 1 incident (S101)
      const result = await service.getChartData({ classId: CLASS1 });
      expect(result.behaviorByStudent).toHaveLength(1);
      expect(result.behaviorByStudent[0].label).toBe('S101');
    });

    it('should return empty arrays when classId matches no events', async () => {
      const result = await service.getChartData({ classId: 'ח-99' });
      expect(result.gradesBySubject).toHaveLength(0);
      expect(result.weeklyAbsences).toHaveLength(0);
      expect(result.behaviorByStudent).toHaveLength(0);
    });
  });
});
