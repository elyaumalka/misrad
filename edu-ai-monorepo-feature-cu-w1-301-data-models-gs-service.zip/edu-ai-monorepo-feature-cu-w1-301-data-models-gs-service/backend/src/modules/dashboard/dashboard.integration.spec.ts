/**
 * Dashboard integration tests.
 *
 * Strategy: boot a real NestJS module containing the real DashboardCacheService
 * and DashboardService, but replace GoogleSheetsService with a controlled mock.
 * This tests the full data pipeline (Sheets mock → Cache → Service → KPI/Chart
 * calculation) without hitting any external APIs.
 *
 * Critical lifecycle notes:
 *   - moduleRef.init()  must be called to trigger onApplicationBootstrap()
 *     (which seeds the cache via refreshCache()).
 *   - moduleRef.close() must be called in afterAll to cancel the weekly
 *     setTimeout armed by scheduleWeeklySundayRefresh(), preventing test-runner
 *     hang.
 */

import { Provider } from '@nestjs/common';
import { Test, TestingModule } from '@nestjs/testing';
import { EventType } from '../../common/enums/event-type.enum';
import {
  AttendanceEvent,
  BehaviorEvent,
  GradeEvent,
  Student,
} from '../../common/interfaces';
import { GoogleSheetsService } from '../../common/services/google-sheets.service';
import { MOCK_SHEET_ROWS } from '../../common/services/mock-data/mock-sheet-rows';
import { AiSummaryService } from './ai-summary.service';
import { DashboardCacheService } from './dashboard-cache.service';
import { DashboardService } from './dashboard.service';

// ── Typed mock data derived from MOCK_SHEET_ROWS ──────────────────────────────
//
// DashboardCacheService expects the service to return domain objects, not raw
// sheet rows. We replicate the mapping logic here so the mock behaves like the
// real GoogleSheetsService after a successful read.

const parseDate = (ddMmYyyy: string): Date => {
  const parts = ddMmYyyy.split('/');
  return new Date(
    Date.UTC(Number(parts[2]), Number(parts[1]) - 1, Number(parts[0])),
  );
};

const TYPED_GRADES: GradeEvent[] = MOCK_SHEET_ROWS.filter(
  (r) => r.eventType === 'ציון',
).map((r) => ({
  eventId: r.eventId,
  studentId: r.studentId,
  studentName: r.studentName,
  classId: r.classId,
  eventDate: parseDate(r.eventDate),
  eventType: EventType.GRADE,
  eventSubject: r.eventSubject,
  eventValue: r.eventValue,
  eventDescription: r.eventDescription || undefined,
}));

const TYPED_ATTENDANCE: AttendanceEvent[] = MOCK_SHEET_ROWS.filter(
  (r) => r.eventType === 'נוכחות',
).map((r) => ({
  eventId: r.eventId,
  studentId: r.studentId,
  studentName: r.studentName,
  classId: r.classId,
  eventDate: parseDate(r.eventDate),
  eventType: EventType.ATTENDANCE,
  eventSubject: r.eventSubject || undefined,
  eventValue: r.eventValue,
  eventDescription: r.eventDescription || undefined,
}));

const TYPED_BEHAVIOR: BehaviorEvent[] = MOCK_SHEET_ROWS.filter(
  (r) => r.eventType === 'התנהגות',
).map((r) => ({
  eventId: r.eventId,
  studentId: r.studentId,
  studentName: r.studentName,
  classId: r.classId,
  eventDate: parseDate(r.eventDate),
  eventType: EventType.BEHAVIOR,
  eventSubject: r.eventSubject || undefined,
  eventValue: r.eventValue,
  eventDescription: r.eventDescription || undefined,
}));

const TYPED_STUDENTS: Student[] = Array.from(
  new Map(
    MOCK_SHEET_ROWS.map((r) => [
      r.studentId,
      { studentId: r.studentId, studentName: r.studentName, classId: r.classId },
    ]),
  ).values(),
);

// ── Expected values pre-computed from MOCK_SHEET_ROWS ─────────────────────────
//
// Keeping these at file scope makes test assertions self-documenting and
// automatically consistent if MOCK_SHEET_ROWS ever changes.

const CLASS1 = 'ח-1'; // students: S101, S102, S105
const CLASS2 = 'ח-2'; // students: S103, S104

// Grades
const ALL_GRADE_SUM = TYPED_GRADES.reduce((s, g) => s + g.eventValue, 0); // 508
const ALL_GRADE_AVG = Math.round((ALL_GRADE_SUM / TYPED_GRADES.length) * 10) / 10; // 72.6

const CLASS1_GRADES = TYPED_GRADES.filter((g) => g.classId === CLASS1);
const CLASS1_GRADE_AVG =
  Math.round(
    (CLASS1_GRADES.reduce((s, g) => s + g.eventValue, 0) / CLASS1_GRADES.length) * 10,
  ) / 10; // 71.4

// Attendance
const ALL_ABSENCES = TYPED_ATTENDANCE.filter((a) => a.eventValue === 1).length; // 5
const CLASS1_ATTENDANCE = TYPED_ATTENDANCE.filter((a) => a.classId === CLASS1);
const CLASS1_ABSENCES = CLASS1_ATTENDANCE.filter((a) => a.eventValue === 1).length; // 3

// Behavior
const CLASS1_BEHAVIOR_INCIDENTS = TYPED_BEHAVIOR.filter(
  (b) => b.classId === CLASS1 && b.eventValue === 1,
).length; // 4
const CLASS2_BEHAVIOR_INCIDENTS = TYPED_BEHAVIOR.filter(
  (b) => b.classId === CLASS2 && b.eventValue === 1,
).length; // 1

// Students
const CLASS1_STUDENTS = new Set(
  [...TYPED_GRADES, ...TYPED_ATTENDANCE, ...TYPED_BEHAVIOR]
    .filter((e) => e.classId === CLASS1)
    .map((e) => e.studentId),
).size; // 3

const CLASS2_STUDENTS = new Set(
  [...TYPED_GRADES, ...TYPED_ATTENDANCE, ...TYPED_BEHAVIOR]
    .filter((e) => e.classId === CLASS2)
    .map((e) => e.studentId),
).size; // 2

// ── Module factory ────────────────────────────────────────────────────────────

/**
 * Creates a testing module with real DashboardCacheService + DashboardService
 * and a mocked GoogleSheetsService. Calls init() to trigger lifecycle hooks.
 */
async function createModule(
  mockSheetsService: Partial<GoogleSheetsService>,
  extraProviders: Provider[] = [],
): Promise<TestingModule> {
  const moduleRef = await Test.createTestingModule({
    providers: [
      DashboardCacheService,
      DashboardService,
      { provide: GoogleSheetsService, useValue: mockSheetsService },
      ...extraProviders,
    ],
  }).compile();

  await moduleRef.init(); // triggers onApplicationBootstrap → refreshCache()
  return moduleRef;
}

/**
 * Generates a large typed dataset for performance testing.
 * Produces:
 *   - 500 grade events   (10 students × 5 subjects × 10 weeks)
 *   - 300 attendance events (10 students × 30 days)
 *   - 200 behavior events  (10 students × 20 weeks)
 * Total: 1 000 events across 3 classes and 10+ weeks — realistic school-year volume.
 */
function buildLargeDatasetMock(): jest.Mocked<
  Pick<
    GoogleSheetsService,
    'getAllGrades' | 'getAllAttendance' | 'getAllBehaviorEvents' | 'getStudents'
  >
> {
  const STUDENTS = 50;
  const CLASSES = ['ח-1', 'ח-2', 'ח-3'];
  const SUBJECTS = ['מתמטיקה', 'אנגלית', 'עברית', 'מדעים', 'היסטוריה'];

  // Spread events across 20 calendar weeks starting Sep 1 2025
  const weekStart = (weekIndex: number): Date =>
    new Date(Date.UTC(2025, 8, 1 + weekIndex * 7));

  const grades: GradeEvent[] = [];
  const attendance: AttendanceEvent[] = [];
  const behavior: BehaviorEvent[] = [];
  const studentMap = new Map<string, Student>();

  for (let s = 0; s < STUDENTS; s++) {
    const studentId = `PERF-S${String(s).padStart(3, '0')}`;
    const classId = CLASSES[s % CLASSES.length];
    studentMap.set(studentId, { studentId, studentName: `Student ${s}`, classId });

    // 10 grade events per student (one per subject per 2 weeks)
    for (let w = 0; w < 10; w++) {
      grades.push({
        eventId: `G-${studentId}-${w}`,
        studentId,
        studentName: `Student ${s}`,
        classId,
        eventDate: weekStart(w * 2),
        eventType: EventType.GRADE,
        eventSubject: SUBJECTS[w % SUBJECTS.length],
        eventValue: 50 + ((s + w * 7) % 51), // deterministic 50–100
      });
    }

    // 6 attendance events per student (one every 3 weeks)
    for (let w = 0; w < 6; w++) {
      attendance.push({
        eventId: `A-${studentId}-${w}`,
        studentId,
        studentName: `Student ${s}`,
        classId,
        eventDate: weekStart(w * 3),
        eventType: EventType.ATTENDANCE,
        eventValue: (s + w) % 4 === 0 ? 1 : 0, // ~25% absent
      });
    }

    // 4 behavior events per student (one every 5 weeks)
    for (let w = 0; w < 4; w++) {
      behavior.push({
        eventId: `B-${studentId}-${w}`,
        studentId,
        studentName: `Student ${s}`,
        classId,
        eventDate: weekStart(w * 5),
        eventType: EventType.BEHAVIOR,
        eventValue: (s + w) % 3 === 0 ? 1 : 0, // ~33% incidents
      });
    }
  }

  const students = Array.from(studentMap.values());

  return {
    getAllGrades: jest.fn().mockResolvedValue(grades),
    getAllAttendance: jest.fn().mockResolvedValue(attendance),
    getAllBehaviorEvents: jest.fn().mockResolvedValue(behavior),
    getStudents: jest.fn().mockResolvedValue(students),
  };
}

/** Returns a mock GoogleSheetsService that returns the full typed dataset. */
function buildValidMock(): jest.Mocked<
  Pick<
    GoogleSheetsService,
    'getAllGrades' | 'getAllAttendance' | 'getAllBehaviorEvents' | 'getStudents'
  >
> {
  return {
    getAllGrades: jest.fn().mockResolvedValue(TYPED_GRADES),
    getAllAttendance: jest.fn().mockResolvedValue(TYPED_ATTENDANCE),
    getAllBehaviorEvents: jest.fn().mockResolvedValue(TYPED_BEHAVIOR),
    getStudents: jest.fn().mockResolvedValue(TYPED_STUDENTS),
  };
}

// ── Test suites ───────────────────────────────────────────────────────────────

describe('Dashboard Integration Tests', () => {
  // Shared module used by the first three describe blocks (full data, scoping, filters).
  let sharedModule: TestingModule;
  let dashboardService: DashboardService;
  let cacheService: DashboardCacheService;

  beforeAll(async () => {
    sharedModule = await createModule(buildValidMock());
    dashboardService = sharedModule.get(DashboardService);
    cacheService = sharedModule.get(DashboardCacheService);
  });

  afterAll(async () => {
    await sharedModule.close(); // cancels scheduleWeeklySundayRefresh setTimeout
  });

  // ── Full data flow ──────────────────────────────────────────────────────────

  describe('Full data flow: GoogleSheetsService → DashboardCacheService → DashboardService', () => {
    it('cache loads data from the mocked GoogleSheetsService on startup without throwing', async () => {
      await expect(cacheService.getData()).resolves.toBeDefined();
    });

    it('getLastRefreshedAt() returns a Date after the module boots', () => {
      expect(cacheService.getLastRefreshedAt()).toBeInstanceOf(Date);
    });

    it('getKpis() returns the correct total student count', async () => {
      const kpis = await dashboardService.getKpis();
      expect(kpis.totalStudents).toBe(TYPED_STUDENTS.length);
    });

    it('getKpis() calculates the correct average grade across all events', async () => {
      const kpis = await dashboardService.getKpis();
      expect(kpis.averageGrade).toBe(ALL_GRADE_AVG);
    });

    it('getKpis() calculates the correct absence count', async () => {
      const kpis = await dashboardService.getKpis();
      expect(kpis.absenceCount).toBe(ALL_ABSENCES);
    });

    it('getChartData() gradesBySubject contains the expected subjects', async () => {
      const charts = await dashboardService.getChartData();
      const subjects = charts.gradesBySubject.map((p) => p.label);
      expect(subjects).toEqual(expect.arrayContaining(['מתמטיקה', 'אנגלית']));
    });

    it('getChartData() weeklyAbsences labels are sorted in ascending order', async () => {
      const charts = await dashboardService.getChartData();
      const labels = charts.weeklyAbsences.map((p) => p.label);
      expect(labels).toEqual([...labels].sort());
    });

    it('getBehaviorOverTime() returns incident totals grouped by ISO week', async () => {
      const behavior = await dashboardService.getBehaviorOverTime();
      // 5 behavior incidents across 2 calendar weeks → 2 data points
      expect(behavior).toHaveLength(2);
      behavior.forEach((point) => {
        expect(point.label).toMatch(/^\d{4}-W\d{2}$/);
        expect(point.value).toBeGreaterThan(0);
      });
    });

    it('getAvailableClasses() returns all class IDs present in the cache', async () => {
      const result = await dashboardService.getAvailableClasses();
      expect(result.classes).toContain(CLASS1);
      expect(result.classes).toContain(CLASS2);
      expect(result.classes).toHaveLength(2);
    });

    it('getLastRefreshedAt() returns a newer timestamp after a subsequent refreshCache() call', async () => {
      const firstTimestamp = cacheService.getLastRefreshedAt()!;
      expect(firstTimestamp).toBeInstanceOf(Date);

      // Wait 10ms to guarantee the system clock advances before the next refresh.
      await new Promise((resolve) => setTimeout(resolve, 10));

      await cacheService.refreshCache();

      const secondTimestamp = cacheService.getLastRefreshedAt()!;
      expect(secondTimestamp).toBeInstanceOf(Date);
      expect(secondTimestamp.getTime()).toBeGreaterThan(firstTimestamp.getTime());
    });
  });

  // ── Data scoping ────────────────────────────────────────────────────────────
  //
  // The backend enforces per-class isolation via the classId query parameter.
  // This mirrors the access a teacher gets: the frontend passes only their
  // assigned class IDs and the backend returns data exclusively for that class.

  describe('Data scoping: classId filter isolates per-class data', () => {
    describe(`CLASS1 (${CLASS1}) filter`, () => {
      it('returns only CLASS1 students', async () => {
        const kpis = await dashboardService.getKpis({ classId: CLASS1 });
        expect(kpis.totalStudents).toBe(CLASS1_STUDENTS);
      });

      it('calculates average grade using only CLASS1 grade events', async () => {
        const kpis = await dashboardService.getKpis({ classId: CLASS1 });
        expect(kpis.averageGrade).toBe(CLASS1_GRADE_AVG);
      });

      it('counts only CLASS1 absences', async () => {
        const kpis = await dashboardService.getKpis({ classId: CLASS1 });
        expect(kpis.absenceCount).toBe(CLASS1_ABSENCES);
      });

      it('counts only CLASS1 behavior incidents', async () => {
        const kpis = await dashboardService.getKpis({ classId: CLASS1 });
        expect(kpis.behaviorIncidentCount).toBe(CLASS1_BEHAVIOR_INCIDENTS);
      });

      it('CLASS1 filter does not expose CLASS2 students S103 or S104 — cross-class leakage check', async () => {
        // A teacher assigned to CLASS1 must be unable to see any CLASS2 data.
        // behaviorByStudent labels are studentIds. CLASS2 students (S103, S104)
        // must not appear in a CLASS1-scoped result.
        const charts = await dashboardService.getChartData({ classId: CLASS1 });
        const studentIds = charts.behaviorByStudent.map((p) => p.label);
        expect(studentIds).not.toContain('S103'); // CLASS2 student
        expect(studentIds).not.toContain('S104'); // CLASS2 student
      });

      it('KPI counts confirm no CLASS2 data leaked into CLASS1 result', async () => {
        const kpis = await dashboardService.getKpis({ classId: CLASS1 });
        // If CLASS2 data leaked: totalStudents would be 5, absenceCount 5, behaviorIncidentCount 5.
        expect(kpis.totalStudents).toBe(CLASS1_STUDENTS); // 3, not 5
        expect(kpis.absenceCount).toBe(CLASS1_ABSENCES); // 3, not 5
        expect(kpis.behaviorIncidentCount).toBe(CLASS1_BEHAVIOR_INCIDENTS); // 4, not 5
      });
    });

    describe(`CLASS2 (${CLASS2}) filter`, () => {
      it('returns only CLASS2 students', async () => {
        const kpis = await dashboardService.getKpis({ classId: CLASS2 });
        expect(kpis.totalStudents).toBe(CLASS2_STUDENTS);
      });

      it('counts only CLASS2 behavior incidents', async () => {
        const kpis = await dashboardService.getKpis({ classId: CLASS2 });
        expect(kpis.behaviorIncidentCount).toBe(CLASS2_BEHAVIOR_INCIDENTS);
      });

      it('CLASS2 filter does not expose CLASS1 students S101, S102, or S105', async () => {
        const charts = await dashboardService.getChartData({ classId: CLASS2 });
        const studentIds = charts.behaviorByStudent.map((p) => p.label);
        expect(studentIds).not.toContain('S101'); // CLASS1 student
        expect(studentIds).not.toContain('S102'); // CLASS1 student
        expect(studentIds).not.toContain('S105'); // CLASS1 student
      });
    });

    describe('Non-existent class filter', () => {
      it('returns zero totalStudents for an unknown classId', async () => {
        const kpis = await dashboardService.getKpis({ classId: 'ח-99' });
        expect(kpis.totalStudents).toBe(0);
        expect(kpis.averageGrade).toBe(0);
        expect(kpis.absenceCount).toBe(0);
        expect(kpis.behaviorIncidentCount).toBe(0);
        expect(kpis.attendanceRate).toBe(0);
      });

      it('returns empty arrays for all chart types when classId has no data', async () => {
        const charts = await dashboardService.getChartData({ classId: 'ח-99' });
        expect(charts.gradesBySubject).toHaveLength(0);
        expect(charts.weeklyAbsences).toHaveLength(0);
        expect(charts.behaviorByStudent).toHaveLength(0);
      });
    });
  });

  // ── Global filters ──────────────────────────────────────────────────────────

  describe('Global filters: date range applied across cached data', () => {
    it('from filter excludes events before the date — no grade events after Sep 5 in mock data', async () => {
      // All grade events in MOCK_SHEET_ROWS are on Sep 1 and Sep 5.
      // A from-filter of Sep 10 excludes all grades → averageGrade = 0.
      const kpis = await dashboardService.getKpis({ from: '2025-09-10' });
      expect(kpis.averageGrade).toBe(0);
    });

    it('to filter includes only Sep 1 events — 5 grade events, avg = 73.6', async () => {
      const kpis = await dashboardService.getKpis({ to: '2025-09-01' });
      // Grades on Sep 1: 88(S101), 74(S102), 91(S103), 60(S104), 55(S105) = 368/5 = 73.6
      expect(kpis.averageGrade).toBe(73.6);
      expect(kpis.totalStudents).toBe(5);
    });

    it('combined classId + date range applies both constraints simultaneously', async () => {
      const kpis = await dashboardService.getKpis({
        classId: CLASS1,
        from: '2025-09-01',
        to: '2025-09-01',
      });
      // CLASS1 grades on Sep 1: 88(S101), 74(S102), 55(S105) = 217/3 = 72.3
      expect(kpis.averageGrade).toBe(72.3);
      expect(kpis.totalStudents).toBe(3);
    });
  });

  // ── AI Summary graceful degradation ────────────────────────────────────────
  //
  // AiSummaryService reads OPENAI_API_KEY in its constructor. We clear it
  // before compiling the module so the service initialises with openai = null,
  // guaranteeing the graceful-degradation path is exercised.

  describe('AI Summary graceful degradation when OPENAI_API_KEY is absent', () => {
    let aiModule: TestingModule;
    let aiSummaryService: AiSummaryService;
    let aiDashboardService: DashboardService;
    let savedApiKey: string | undefined;

    beforeAll(async () => {
      savedApiKey = process.env['OPENAI_API_KEY'];
      delete process.env['OPENAI_API_KEY'];

      aiModule = await createModule(buildValidMock(), [AiSummaryService]);
      aiSummaryService = aiModule.get(AiSummaryService);
      aiDashboardService = aiModule.get(DashboardService);
    });

    afterAll(async () => {
      if (savedApiKey !== undefined) {
        process.env['OPENAI_API_KEY'] = savedApiKey;
      }
      await aiModule.close();
    });

    it('generateSummary returns empty summary and missing_api_key error', async () => {
      const result = await aiSummaryService.generateSummary({});
      expect(result.summary).toBe('');
      expect(result.error).toBe('missing_api_key');
    });

    it('generateSummary with classId filter also returns graceful empty response', async () => {
      const result = await aiSummaryService.generateSummary({ classId: CLASS1 });
      expect(result.summary).toBe('');
      expect(result.error).toBe('missing_api_key');
    });

    it('getKpis() returns correct values even when AI is unavailable', async () => {
      const kpis = await aiDashboardService.getKpis();
      // Full dataset — same expected values as the main flow tests.
      expect(kpis.totalStudents).toBe(TYPED_STUDENTS.length);
      expect(kpis.averageGrade).toBe(ALL_GRADE_AVG);
      expect(kpis.absenceCount).toBe(ALL_ABSENCES);
    });

    it('getGradesBySubject() and getBehaviorOverTime() are unaffected by missing API key', async () => {
      const [grades, behavior] = await Promise.all([
        aiDashboardService.getGradesBySubject(),
        aiDashboardService.getBehaviorOverTime(),
      ]);
      expect(grades.length).toBeGreaterThan(0);
      expect(behavior.length).toBeGreaterThan(0);
    });
  });

  // ── Cache resilience ────────────────────────────────────────────────────────

  describe('Resilience: cache keeps previous snapshot when refresh fails', () => {
    let resilientModule: TestingModule;
    let resilientCache: DashboardCacheService;
    let resilientDashboard: DashboardService;

    beforeAll(async () => {
      // First call (bootstrap): succeeds and populates snapshot.
      // Subsequent calls: throw to simulate a Sheets API failure.
      const failingMock = {
        getAllGrades: jest
          .fn()
          .mockResolvedValueOnce(TYPED_GRADES)
          .mockRejectedValue(new Error('Google Sheets column mismatch')),
        getAllAttendance: jest
          .fn()
          .mockResolvedValueOnce(TYPED_ATTENDANCE)
          .mockRejectedValue(new Error('Google Sheets column mismatch')),
        getAllBehaviorEvents: jest
          .fn()
          .mockResolvedValueOnce(TYPED_BEHAVIOR)
          .mockRejectedValue(new Error('Google Sheets column mismatch')),
        getStudents: jest
          .fn()
          .mockResolvedValueOnce(TYPED_STUDENTS)
          .mockRejectedValue(new Error('Google Sheets column mismatch')),
      };

      resilientModule = await createModule(failingMock);
      resilientCache = resilientModule.get(DashboardCacheService);
      resilientDashboard = resilientModule.get(DashboardService);
    });

    afterAll(async () => {
      await resilientModule.close();
    });

    it('refreshCache() catches the error silently without throwing', async () => {
      await expect(resilientCache.refreshCache()).resolves.toBeUndefined();
    });

    it('getData() returns the previous valid snapshot after a failed refresh', async () => {
      await resilientCache.refreshCache(); // second call — mock now throws internally
      const data = await resilientCache.getData();
      expect(data.grades).toHaveLength(TYPED_GRADES.length);
      expect(data.attendance).toHaveLength(TYPED_ATTENDANCE.length);
      expect(data.behavior).toHaveLength(TYPED_BEHAVIOR.length);
    });

    it('getKpis() still returns correct values from the preserved snapshot', async () => {
      const kpis = await resilientDashboard.getKpis();
      expect(kpis.totalStudents).toBe(TYPED_STUDENTS.length);
      expect(kpis.averageGrade).toBe(ALL_GRADE_AVG);
    });
  });

  // ── Empty sheet ─────────────────────────────────────────────────────────────

  describe('Empty sheet: all service methods return zeros/empty arrays', () => {
    let emptyModule: TestingModule;
    let emptyDashboard: DashboardService;
    let emptyCache: DashboardCacheService;

    beforeAll(async () => {
      const emptyMock = {
        getAllGrades: jest.fn().mockResolvedValue([]),
        getAllAttendance: jest.fn().mockResolvedValue([]),
        getAllBehaviorEvents: jest.fn().mockResolvedValue([]),
        getStudents: jest.fn().mockResolvedValue([]),
      };

      emptyModule = await createModule(emptyMock);
      emptyDashboard = emptyModule.get(DashboardService);
      emptyCache = emptyModule.get(DashboardCacheService);
    });

    afterAll(async () => {
      await emptyModule.close();
    });

    it('getData() resolves (does not throw) when the cache contains empty arrays', async () => {
      await expect(emptyCache.getData()).resolves.toBeDefined();
    });

    it('getKpis() returns all-zero metrics', async () => {
      const kpis = await emptyDashboard.getKpis();
      expect(kpis.totalStudents).toBe(0);
      expect(kpis.averageGrade).toBe(0);
      expect(kpis.attendanceRate).toBe(0);
      expect(kpis.absenceCount).toBe(0);
      expect(kpis.behaviorIncidentCount).toBe(0);
    });

    it('getChartData() returns empty arrays for all chart types', async () => {
      const charts = await emptyDashboard.getChartData();
      expect(charts.gradesBySubject).toHaveLength(0);
      expect(charts.weeklyAbsences).toHaveLength(0);
      expect(charts.behaviorByStudent).toHaveLength(0);
    });

    it('getAvailableClasses() returns an empty classes array', async () => {
      const result = await emptyDashboard.getAvailableClasses();
      expect(result.classes).toHaveLength(0);
    });
  });

  // ── Performance: 500+ rows ─────────────────────────────────────────────────
  //
  // Verifies that all three data-aggregation methods complete well within the
  // 3-second budget specified in the task (the full 3s includes network + frontend
  // render; pure server-side computation of 500 rows must be far faster).
  // Budget used here: 500 ms — generous enough to avoid CI flakiness while still
  // catching any accidental O(n²) regression.

  describe('Performance: all aggregation methods complete in under 500ms with 500+ rows', () => {
    const PERF_BUDGET_MS = 500;
    let perfModule: TestingModule;
    let perfDashboard: DashboardService;

    beforeAll(async () => {
      perfModule = await createModule(buildLargeDatasetMock());
      perfDashboard = perfModule.get(DashboardService);
    });

    afterAll(async () => {
      await perfModule.close();
    });

    it('getKpis() completes within budget for 500+ grade, attendance, and behavior rows', async () => {
      const start = Date.now();
      const kpis = await perfDashboard.getKpis();
      const elapsed = Date.now() - start;

      expect(kpis.totalStudents).toBeGreaterThanOrEqual(50);
      expect(elapsed).toBeLessThan(PERF_BUDGET_MS);
    });

    it('getGradesBySubject() completes within budget for 500+ grade rows', async () => {
      const start = Date.now();
      const grades = await perfDashboard.getGradesBySubject();
      const elapsed = Date.now() - start;

      expect(grades.length).toBeGreaterThan(0);
      expect(elapsed).toBeLessThan(PERF_BUDGET_MS);
    });

    it('getBehaviorOverTime() completes within budget for 500+ behavior rows spanning multiple weeks', async () => {
      const start = Date.now();
      const behavior = await perfDashboard.getBehaviorOverTime();
      const elapsed = Date.now() - start;

      expect(behavior.length).toBeGreaterThan(0);
      expect(elapsed).toBeLessThan(PERF_BUDGET_MS);
    });

  });
});
