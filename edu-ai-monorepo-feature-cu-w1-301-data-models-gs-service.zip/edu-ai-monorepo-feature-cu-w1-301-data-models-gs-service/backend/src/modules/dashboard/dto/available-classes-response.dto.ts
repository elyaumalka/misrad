import { ApiProperty } from '@nestjs/swagger';

export class AvailableClassesResponseDto {
  @ApiProperty({ type: [String], example: ['ח-1', 'ח-2'] })
  classes: string[];
}
