import { ApiProperty } from '@nestjs/swagger';

/**
 * A single labeled data point used in chart series.
 */
export class ChartDataPointDto {
  /** Display label for the data point (e.g., subject name, week label, studentId). */
  @ApiProperty({
    description: 'Display label (subject name, ISO week, or studentId)',
    example: 'מתמטיקה',
  })
  label: string;

  /** Numeric value for the data point. */
  @ApiProperty({
    description: 'Numeric value for the data point',
    example: 78.3,
  })
  value: number;
}

/**
 * Response shape for the GET /dashboard/charts endpoint.
 * All data is aggregated — no student names or raw PII is included.
 */
export class ChartDataResponseDto {
  /**
   * Average grade per subject.
   * label = subject name (e.g., "מתמטיקה"), value = average score (0–100).
   */
  @ApiProperty({
    type: [ChartDataPointDto],
    description:
      'Average grade per subject. label = subject name, value = avg score (0–100)',
  })
  gradesBySubject: ChartDataPointDto[];

  /**
   * Number of absences per calendar week.
   * label = ISO week string (e.g., "2025-W36"), value = absence count.
   */
  @ApiProperty({
    type: [ChartDataPointDto],
    description:
      'Absence count per calendar week. label = ISO week (e.g., "2025-W36"), value = count',
  })
  weeklyAbsences: ChartDataPointDto[];

  /**
   * Number of behavior incidents per student.
   * label = studentId (never studentName — PII-safe), value = incident count.
   */
  @ApiProperty({
    type: [ChartDataPointDto],
    description:
      'Behavior incident count per student. label = studentId (PII-safe), value = count',
  })
  behaviorByStudent: ChartDataPointDto[];
}
