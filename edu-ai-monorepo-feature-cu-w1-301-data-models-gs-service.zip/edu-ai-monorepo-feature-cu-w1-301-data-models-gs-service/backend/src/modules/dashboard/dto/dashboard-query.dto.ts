import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsDateString, IsOptional, IsString } from 'class-validator';

/**
 * Optional query parameters for dashboard endpoints.
 * All fields are optional — omitting them returns unscoped data across all classes and dates.
 *
 * Data scoping note: classId currently comes from the query string.
 * When Auth0/JWT is integrated, a guard will validate that the requesting
 * teacher is authorised for the supplied classId. No service changes will
 * be needed at that point — only a guard is added to the controller.
 */
export class DashboardQueryDto {
  /**
   * Scope results to a single class (e.g. "ח-1").
   * Omit to return data across all classes.
   */
  @ApiPropertyOptional({
    description: 'Filter results to a specific class ID (e.g. "ח-1")',
    example: 'ח-1',
  })
  @IsOptional()
  @IsString()
  classId?: string;

  /**
   * Start of the date range, inclusive (ISO 8601 date string, e.g. "2025-09-01").
   * Omit to include events from the beginning of the data.
   */
  @ApiPropertyOptional({
    description: 'Start of the date range, inclusive (ISO 8601)',
    example: '2025-09-01',
  })
  @IsOptional()
  @IsDateString()
  from?: string;

  /**
   * End of the date range, inclusive (ISO 8601 date string, e.g. "2025-09-30").
   * Omit to include events up to the most recent data.
   */
  @ApiPropertyOptional({
    description: 'End of the date range, inclusive (ISO 8601)',
    example: '2025-09-30',
  })
  @IsOptional()
  @IsDateString()
  to?: string;
}
