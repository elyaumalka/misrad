import { ApiProperty } from '@nestjs/swagger';

/**
 * Response shape for the GET /dashboard/kpis endpoint.
 * All values are aggregated across all students — no PII is included.
 */
export class KpiResponseDto {
  /** Total number of unique students in the system. */
  @ApiProperty({
    description: 'Total number of unique students in the system',
    example: 30,
  })
  totalStudents: number;

  /**
   * Mean score across all grade events, rounded to one decimal place.
   * Range: 0–100.
   */
  @ApiProperty({
    description: 'Mean score across all grade events (0–100, 1 decimal place)',
    example: 76.4,
  })
  averageGrade: number;

  /**
   * Percentage of attendance events where the student was present
   * (eventValue === 0), rounded to one decimal place.
   * Range: 0–100.
   */
  @ApiProperty({
    description:
      'Percentage of attendance records where the student was present (0–100, 1 decimal place)',
    example: 82.5,
  })
  attendanceRate: number;

  /**
   * Total count of absence events in the filtered scope (eventValue === 1).
   */
  @ApiProperty({
    description: 'Total count of absence events (eventValue === 1)',
    example: 3,
  })
  absenceCount: number;

  /**
   * Total count of behavior incidents across all students
   * (eventValue === 1).
   */
  @ApiProperty({
    description:
      'Total count of negative behavior incidents (eventValue === 1)',
    example: 5,
  })
  behaviorIncidentCount: number;
}
