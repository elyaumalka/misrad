import { ApiProperty } from '@nestjs/swagger';

/**
 * Response shape for the GET /dashboard/summary endpoint.
 * Contains an AI-generated Hebrew executive summary of the current dashboard data.
 * An empty string indicates that the AI is unavailable — the dashboard degrades gracefully.
 */
export class AiSummaryResponseDto {
  /**
   * AI-generated Hebrew executive summary (2–4 sentences).
   * Empty string when OpenAI is unavailable — callers must handle this case gracefully.
   */
  @ApiProperty({
    description:
      'AI-generated Hebrew executive summary of the dashboard data. ' +
      'Empty string if OpenAI is unavailable.',
    example:
      'בתקופה הנבחרת נצפתה ירידה של 5% בציון הממוצע, בעיקר במתמטיקה. במקביל, נרשמה עלייה של 15% במספר האירועים ההתנהגותיים השליליים.',
  })
  summary: string;

  /**
   * Error code indicating why the summary is unavailable.
   * "missing_api_key" — OPENAI_API_KEY is not configured on the server.
   */
  @ApiProperty({
    required: false,
    description: '"missing_api_key" when OPENAI_API_KEY is not configured.',
    example: 'missing_api_key',
  })
  error?: string;
}
