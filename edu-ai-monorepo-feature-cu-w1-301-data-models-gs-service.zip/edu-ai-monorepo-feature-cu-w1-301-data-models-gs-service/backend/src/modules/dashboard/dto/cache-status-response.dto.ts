import { ApiProperty } from '@nestjs/swagger';

/** Response for GET /dashboard/cache-status and POST /dashboard/sync. */
export class CacheStatusResponseDto {
  /**
   * ISO 8601 timestamp of the last successful cache refresh.
   * Null if the server has not yet completed a successful Google Sheets read.
   */
  @ApiProperty({
    nullable: true,
    example: '2025-04-06T02:00:00.000Z',
    description:
      'ISO 8601 timestamp of the last successful weekly sync, or null if never synced.',
  })
  lastRefreshedAt: string | null;
}
