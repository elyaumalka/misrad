import { Injectable, Logger } from '@nestjs/common';
import { DashboardCacheService } from './dashboard-cache.service';
import { AvailableClassesResponseDto } from './dto/available-classes-response.dto';
import {
  ChartDataPointDto,
  ChartDataResponseDto,
} from './dto/chart-data-response.dto';
import { DashboardQueryDto } from './dto/dashboard-query.dto';
import { KpiResponseDto } from './dto/kpi-response.dto';
import { DashboardSnapshot } from './interfaces/dashboard-snapshot.interface';

@Injectable()
export class DashboardService {
  private readonly logger = new Logger(DashboardService.name);

  constructor(private readonly cacheService: DashboardCacheService) {}

  /**
   * Computes KPI metrics scoped to the given class and date range.
   * Omitting query params returns unscoped aggregates across all data.
   * No PII is logged or returned.
   */
  async getKpis(query: DashboardQueryDto = {}): Promise<KpiResponseDto> {
    const {
      grades: allGrades,
      attendance: allAttendance,
      behavior: allBehavior,
    } = await this.cacheService.getData();

    const grades = this.filterEvents(allGrades, query);
    const attendance = this.filterEvents(allAttendance, query);
    const behavior = this.filterEvents(allBehavior, query);

    const studentIds = new Set([
      ...grades.map((e) => e.studentId),
      ...attendance.map((e) => e.studentId),
      ...behavior.map((e) => e.studentId),
    ]);
    const totalStudents = studentIds.size;

    const averageGrade =
      grades.length > 0
        ? Math.round(
            (grades.reduce((sum, g) => sum + g.eventValue, 0) / grades.length) *
              10,
          ) / 10
        : 0;

    const absenceCount = attendance.filter((a) => a.eventValue === 1).length;
    const attendanceRate =
      attendance.length > 0
        ? Math.round(
            ((attendance.length - absenceCount) / attendance.length) * 1000,
          ) / 10
        : 0;

    const behaviorIncidentCount = behavior.filter(
      (b) => b.eventValue === 1,
    ).length;

    this.logger.log(
      `getKpis: students=${totalStudents}, grades=${grades.length}, attendance=${attendance.length}, behavior=${behavior.length}`,
    );

    return {
      totalStudents,
      averageGrade,
      attendanceRate,
      absenceCount,
      behaviorIncidentCount,
    };
  }

  /**
   * Returns average grade per subject scoped to the given class and date range.
   * Omitting query params returns unscoped data across all classes and dates.
   */
  async getGradesBySubject(
    query: DashboardQueryDto = {},
  ): Promise<ChartDataPointDto[]> {
    const { grades: allGrades } = await this.cacheService.getData();
    const grades = this.filterEvents(allGrades, query);
    const result = this.aggregateGradesBySubject(grades);
    this.logger.log(
      `getGradesBySubject: subjects=${result.length}, grades=${grades.length}`,
    );
    return result;
  }

  /**
   * Returns behavior incident count per calendar week scoped to the given class and date range.
   * Omitting query params returns unscoped data across all classes and dates.
   * Only negative incidents (eventValue === 1) are counted.
   */
  async getBehaviorOverTime(
    query: DashboardQueryDto = {},
  ): Promise<ChartDataPointDto[]> {
    const { behavior: allBehavior } = await this.cacheService.getData();
    const behavior = this.filterEvents(allBehavior, query);
    const result = this.aggregateBehaviorOverTime(behavior);
    this.logger.log(
      `getBehaviorOverTime: weeks=${result.length}, events=${behavior.length}`,
    );
    return result;
  }

  /**
   * Builds chart-ready aggregated data scoped to the given class and date range.
   * Omitting query params returns unscoped data across all classes and dates.
   * Labels use subject names and ISO week strings — no student names.
   */
  async getChartData(
    query: DashboardQueryDto = {},
  ): Promise<ChartDataResponseDto> {
    const {
      grades: allGrades,
      attendance: allAttendance,
      behavior: allBehavior,
    } = await this.cacheService.getData();

    const grades = this.filterEvents(allGrades, query);
    const attendance = this.filterEvents(allAttendance, query);
    const behavior = this.filterEvents(allBehavior, query);

    const gradesBySubject = this.aggregateGradesBySubject(grades);
    const weeklyAbsences = this.aggregateWeeklyAbsences(attendance);
    const behaviorByStudent = this.aggregateBehaviorByStudent(behavior);

    this.logger.log(
      `getChartData: subjects=${gradesBySubject.length}, weeks=${weeklyAbsences.length}, studentsWithIncidents=${behaviorByStudent.length}`,
    );

    return { gradesBySubject, weeklyAbsences, behaviorByStudent };
  }

  /**
   * Returns the sorted list of unique class IDs present in the sheet.
   * Derived from student records — classId is not PII.
   */
  async getAvailableClasses(): Promise<AvailableClassesResponseDto> {
    const { students } = await this.cacheService.getData();
    const classSet = new Set<string>(students.map((s) => s.classId));
    const classes = Array.from(classSet).sort((a, b) =>
      a.localeCompare(b, 'he'),
    );
    this.logger.log(`getAvailableClasses: found ${classes.length} classes`);
    return { classes };
  }

  // ── Private filter helper ────────────────────────────────────────────────

  /**
   * Filters a typed event array by classId and/or date range.
   * Any omitted field in the query is treated as "no constraint".
   * Both from and to are inclusive.
   */
  private filterEvents<T extends { classId: string; eventDate: Date }>(
    events: T[],
    query: DashboardQueryDto,
  ): T[] {
    const from = query.from ? new Date(query.from) : null;
    const to = query.to ? new Date(query.to) : null;

    return events.filter((event) => {
      if (query.classId && event.classId !== query.classId) return false;
      if (from && event.eventDate < from) return false;
      if (to && event.eventDate > to) return false;
      return true;
    });
  }

  // ── Private aggregation helpers ─────────────────────────────────────────

  private aggregateGradesBySubject(
    grades: DashboardSnapshot['grades'],
  ): ChartDataPointDto[] {
    const subjectTotals = new Map<string, { sum: number; count: number }>();

    for (const grade of grades) {
      const existing = subjectTotals.get(grade.eventSubject) ?? {
        sum: 0,
        count: 0,
      };
      subjectTotals.set(grade.eventSubject, {
        sum: existing.sum + grade.eventValue,
        count: existing.count + 1,
      });
    }

    return Array.from(subjectTotals.entries()).map(
      ([label, { sum, count }]) => ({
        label,
        value: Math.round((sum / count) * 10) / 10,
      }),
    );
  }

  private aggregateWeeklyAbsences(
    attendance: DashboardSnapshot['attendance'],
  ): ChartDataPointDto[] {
    const weekCounts = new Map<string, number>();

    for (const record of attendance) {
      if (record.eventValue !== 1) continue;
      const weekLabel = this.toIsoWeekLabel(record.eventDate);
      weekCounts.set(weekLabel, (weekCounts.get(weekLabel) ?? 0) + 1);
    }

    return Array.from(weekCounts.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([label, value]) => ({ label, value }));
  }

  private aggregateBehaviorByStudent(
    events: DashboardSnapshot['behavior'],
  ): ChartDataPointDto[] {
    const counts = new Map<string, number>();

    for (const event of events) {
      if (event.eventValue !== 1) continue;
      // Use studentId as label — never studentName (PII)
      counts.set(event.studentId, (counts.get(event.studentId) ?? 0) + 1);
    }

    return Array.from(counts.entries()).map(([label, value]) => ({
      label,
      value,
    }));
  }

  private aggregateBehaviorOverTime(
    events: DashboardSnapshot['behavior'],
  ): ChartDataPointDto[] {
    const weekCounts = new Map<string, number>();

    for (const event of events) {
      if (event.eventValue !== 1) continue;
      const weekLabel = this.toIsoWeekLabel(event.eventDate);
      weekCounts.set(weekLabel, (weekCounts.get(weekLabel) ?? 0) + 1);
    }

    return Array.from(weekCounts.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([label, value]) => ({ label, value }));
  }

  /**
   * Converts a Date to an ISO week label in the format "YYYY-W##" (e.g., "2025-W36").
   */
  private toIsoWeekLabel(date: Date): string {
    const thursday = new Date(date);
    thursday.setDate(date.getDate() + 3 - ((date.getDay() + 6) % 7));
    const yearStart = new Date(thursday.getFullYear(), 0, 4);
    const weekNumber = Math.ceil(
      ((thursday.getTime() - yearStart.getTime()) / 86_400_000 +
        1 +
        ((yearStart.getDay() + 6) % 7)) /
        7,
    );
    return `${thursday.getFullYear()}-W${String(weekNumber).padStart(2, '0')}`;
  }
}
