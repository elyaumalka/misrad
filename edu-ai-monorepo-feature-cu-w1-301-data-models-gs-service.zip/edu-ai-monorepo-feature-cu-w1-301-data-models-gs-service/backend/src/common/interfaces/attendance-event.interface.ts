import { EventType } from '../enums/event-type.enum';

/**
 * An attendance record for a student on a specific date.
 * Maps to a Google Sheet row where EventType = 'נוכחות'.
 */
export interface AttendanceEvent {
  /** Unique event identifier (maps to sheet column: EventID) */
  eventId: string;

  /** @PII Student ID — reference only, do not log (maps to sheet column: StudentID) */
  studentId: string;

  /** @PII Student full name — do not log (maps to sheet column: StudentName) */
  studentName: string;

  /** Class the student belongs to (maps to sheet column: ClassID) */
  classId: string;

  /** Date of the event (maps to sheet column: EventDate) */
  eventDate: Date;

  /** Always EventType.ATTENDANCE for this interface (maps to sheet column: EventType) */
  eventType: EventType.ATTENDANCE;

  /** Subject context, if applicable (maps to sheet column: EventSubject — only required for Grade events per spec) */
  eventSubject?: string;

  /**
   * Attendance status (maps to sheet column: EventValue).
   * 1 = absent (חיסור), 0 = present (נוכחות)
   */
  eventValue: number;

  /** Optional short description, e.g. "חיסור מוצדק - מחלה" (maps to sheet column: EventDescription) */
  eventDescription?: string;
}
