import { EventType } from '../enums/event-type.enum';

/**
 * A grade entry for a student in a specific subject.
 * Maps to a Google Sheet row where EventType = 'ציון'.
 */
export interface GradeEvent {
  /** Unique event identifier (maps to sheet column: EventID) */
  eventId: string;

  /** @PII Student ID — reference only, do not log (maps to sheet column: StudentID) */
  studentId: string;

  /** @PII Student full name — do not log (maps to sheet column: StudentName) */
  studentName: string;

  /** Class the student belongs to (maps to sheet column: ClassID) */
  classId: string;

  /** Date of the event (maps to sheet column: EventDate) */
  eventDate: Date;

  /** Always EventType.GRADE for this interface (maps to sheet column: EventType) */
  eventType: EventType.GRADE;

  /** Subject name, e.g. "מתמטיקה" (maps to sheet column: EventSubject) */
  eventSubject: string;

  /** Numeric score between 0 and 100 (maps to sheet column: EventValue) */
  eventValue: number;

  /** Optional short description, e.g. "מבחן רבעוני" (maps to sheet column: EventDescription) */
  eventDescription?: string;
}
