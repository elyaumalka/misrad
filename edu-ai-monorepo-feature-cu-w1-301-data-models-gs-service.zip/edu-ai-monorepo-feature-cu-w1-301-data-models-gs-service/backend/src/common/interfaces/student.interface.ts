/**
 * Represents a unique student, derived from event rows in the Google Sheet.
 * All fields in this interface are PII — never log any of them.
 */
export interface Student {
  /** @PII Student ID number (e.g., "204587123") */
  studentId: string;

  /** @PII Student full name (e.g., "Alex Morgan") */
  studentName: string;

  /** Class the student belongs to (e.g., "ח-1") */
  classId: string;
}
