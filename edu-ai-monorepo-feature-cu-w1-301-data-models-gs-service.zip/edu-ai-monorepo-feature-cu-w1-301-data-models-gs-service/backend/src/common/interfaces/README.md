# Shared Data Models — Review & Approval Required

**Task:** CU-W1-301 | Data Models
**Status:** Awaiting approval from all four developers before closing
**⚠️ This task affects all modules — please review carefully and confirm approval**

---

## Overview

This folder defines the shared data structures used across the entire backend.
All interfaces map **1:1 to the Google Sheet columns** defined in the specification document (section 3.1).

---

## Files

| File | Description |
|---|---|
| `student.interface.ts` | Unique student identity record |
| `grade-event.interface.ts` | A grade entry (EventType = GRADE) |
| `attendance-event.interface.ts` | An attendance record (EventType = ATTENDANCE) |
| `behavior-event.interface.ts` | A behavior incident (EventType = BEHAVIOR) |
| `../enums/event-type.enum.ts` | Enum for the three event types |
| `index.ts` | Barrel export for all interfaces |

---

## Sheet Column Mapping

All event interfaces share the same 9 columns from the Google Sheet:

| Sheet Column | TypeScript Field | Type | Notes |
|---|---|---|---|
| EventID | `eventId` | `string` | Unique row identifier |
| StudentID | `studentId` | `string` | **@PII — do not log** |
| StudentName | `studentName` | `string` | **@PII — do not log** |
| ClassID | `classId` | `string` | |
| EventDate | `eventDate` | `string` | Format: DD/MM/YYYY |
| EventType | `eventType` | `EventType` (enum) | Discriminated union literal |
| EventSubject | `eventSubject` | `string` | Required on GradeEvent; optional on others (spec: only used for Grade) |
| EventValue | `eventValue` | `number` | See interpretation table below |
| EventDescription | `eventDescription` | `string?` | Optional — only optional field per spec |

### EventValue interpretation by event type

| EventType | Value | Meaning |
|---|---|---|
| GRADE | 0–100 | Numeric score |
| ATTENDANCE | 1 | Absent (חיסור) |
| ATTENDANCE | 0 | Present (נוכחות) |
| BEHAVIOR | 1 | Negative event (אירוע שלילי) |

---

## PII Fields

The following fields contain Personally Identifiable Information.
**Never log, expose in error messages, or store beyond the scope of a single request.**

- `studentId` — present on all event interfaces and `Student`
- `studentName` — present on all event interfaces and `Student`

---

## EventType Enum

```typescript
EventType.GRADE       // sheet value: 'ציון'
EventType.ATTENDANCE  // sheet value: 'נוכחות'
EventType.BEHAVIOR    // sheet value: 'התנהגות'
```

The mapping from Hebrew sheet string → enum is handled by the parsing/ingestion service — not by these interfaces.

---

## Usage

Import from the common barrel:

```typescript
import { GradeEvent, AttendanceEvent, BehaviorEvent, Student, EventType } from 'src/common';
```

---

## Approval

Please reply with your approval (or comments) before this task is closed.

- [ ] Developer 1 — approved
- [ ] Developer 2 — approved
- [ ] Developer 3 — approved
- [ ] Developer 4 — approved
