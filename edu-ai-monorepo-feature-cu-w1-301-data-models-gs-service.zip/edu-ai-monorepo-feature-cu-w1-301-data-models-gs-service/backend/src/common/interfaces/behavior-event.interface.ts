import { EventType } from '../enums/event-type.enum';

/**
 * A behavior incident recorded for a student.
 * Maps to a Google Sheet row where EventType = 'התנהגות'.
 */
export interface BehaviorEvent {
  /** Unique event identifier (maps to sheet column: EventID) */
  eventId: string;

  /** @PII Student ID — reference only, do not log (maps to sheet column: StudentID) */
  studentId: string;

  /** @PII Student full name — do not log (maps to sheet column: StudentName) */
  studentName: string;

  /** Class the student belongs to (maps to sheet column: ClassID) */
  classId: string;

  /** Date of the event (maps to sheet column: EventDate) */
  eventDate: Date;

  /** Always EventType.BEHAVIOR for this interface (maps to sheet column: EventType) */
  eventType: EventType.BEHAVIOR;

  /** Subject context, if applicable (maps to sheet column: EventSubject — only required for Grade events per spec) */
  eventSubject?: string;

  /**
   * Behavior indicator (maps to sheet column: EventValue).
   * 1 = negative event (אירוע שלילי)
   */
  eventValue: number;

  /** Optional short description, e.g. "הפרעה בשיעור" (maps to sheet column: EventDescription) */
  eventDescription?: string;
}
