import { Injectable, Logger } from '@nestjs/common';
import { google } from 'googleapis';
import { EventType } from '../enums/event-type.enum';
import {
  AttendanceEvent,
  BehaviorEvent,
  GradeEvent,
  Student,
} from '../interfaces';

/**
 * Mirrors one row in the Google Sheet exactly.
 * This type is private to the service — consumers never see it.
 * @PII — studentId and studentName fields. Never log these values.
 */
interface SheetRow {
  eventId: string;
  studentId: string;
  studentName: string;
  classId: string;
  eventDate: string; // DD/MM/YYYY as stored in the sheet
  eventType: string; // Hebrew string: 'ציון' | 'נוכחות' | 'התנהגות'
  eventSubject: string;
  eventValue: number;
  eventDescription: string;
}

/** Maps raw Hebrew sheet values to the EventType enum. */
const EVENT_TYPE_MAP: Record<string, EventType> = {
  ציון: EventType.GRADE,
  נוכחות: EventType.ATTENDANCE,
  התנהגות: EventType.BEHAVIOR,
};

/**
 * Column names in the exact order they must appear in the Google Sheet.
 * Used by validateHeaders() to detect structural changes early.
 */
const REQUIRED_COLUMNS = [
  'EventID',
  'StudentID',
  'StudentName',
  'ClassID',
  'EventDate',
  'EventType',
  'EventSubject',
  'EventValue',
  'EventDescription',
] as const;

@Injectable()
export class GoogleSheetsService {
  private readonly logger = new Logger(GoogleSheetsService.name);

  /**
   * Returns the raw sheet rows from the Google Sheets API.
   * ─────────────────────────────────────────────────────────────────────
   * Credentials are read from environment variables:
   *   GOOGLE_SERVICE_ACCOUNT_KEY — full service account JSON string
   *   GOOGLE_SHEETS_ID           — the spreadsheet ID
   * All parsing and mapping logic downstream stays identical regardless
   * of whether data comes from the live API or a test spy.
   * ─────────────────────────────────────────────────────────────────────
   */
  private async getRows(): Promise<SheetRow[]> {
    const keyJson = process.env['GOOGLE_SERVICE_ACCOUNT_KEY'];
    const spreadsheetId = process.env['GOOGLE_SHEETS_ID'];

    if (!keyJson || !spreadsheetId) {
      throw new Error(
        'Missing Google Sheets credentials: GOOGLE_SERVICE_ACCOUNT_KEY and GOOGLE_SHEETS_ID must be set',
      );
    }

    const credentials = JSON.parse(keyJson) as {
      client_email: string;
      private_key: string;
    };
    const sheets = this.buildSheetsClient(credentials);

    const tabName = process.env['GOOGLE_SHEETS_TAB_NAME'] ?? 'school-events';
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId,
      range: `${tabName}!A:I`,
    });

    const values = response.data.values;
    if (!values || values.length < 2) {
      this.logger.log('getRows: sheet returned no data rows');
      return [];
    }

    this.validateHeaders(values[0] as string[]);
    const dataRows = values
      .slice(1)
      .map((row) => this.mapRawRow(row as string[]));
    this.logger.log(`getRows: loaded ${dataRows.length} rows`);
    return dataRows;
  }

  /**
   * Constructs an authenticated read-only Google Sheets API client.
   * Scope is limited to spreadsheets.readonly — the sheet is never written to.
   */
  private buildSheetsClient(credentials: {
    client_email: string;
    private_key: string;
  }) {
    const auth = new google.auth.JWT({
      email: credentials.client_email,
      key: credentials.private_key,
      scopes: ['https://www.googleapis.com/auth/spreadsheets.readonly'],
    });
    return google.sheets({ version: 'v4', auth });
  }

  /**
   * Validates the sheet header row against REQUIRED_COLUMNS.
   * Throws a descriptive Hebrew error on the first column mismatch so that any
   * structural change to the sheet is surfaced immediately rather than
   * silently producing corrupted data downstream.
   * Logs only the column count on success — never logs column values.
   */
  private validateHeaders(headers: string[]): void {
    for (let i = 0; i < REQUIRED_COLUMNS.length; i++) {
      if (headers[i] !== REQUIRED_COLUMNS[i]) {
        const expected = REQUIRED_COLUMNS[i];
        const colNumber = i + 1;
        if (headers[i] === undefined) {
          throw new Error(
            `שגיאה במבנה גיליון Google Sheets: עמודה ${colNumber} חסרה – צפוי: "${expected}"`,
          );
        }
        throw new Error(
          `שגיאה במבנה גיליון Google Sheets: עמודה ${colNumber} שגויה – צפוי: "${expected}", התקבל: "${headers[i]}"`,
        );
      }
    }
    this.logger.log(
      `validateHeaders: ${REQUIRED_COLUMNS.length} columns validated`,
    );
  }

  /**
   * Maps a raw string array (one sheet row) to a typed SheetRow.
   * Column positions correspond 1-to-1 with REQUIRED_COLUMNS.
   * eventValue is coerced to a number; invalid cells default to 0.
   */
  private mapRawRow(row: string[]): SheetRow {
    const rawValue = Number(row[7]);
    return {
      eventId: row[0] ?? '',
      studentId: row[1] ?? '',
      studentName: row[2] ?? '',
      classId: row[3] ?? '',
      eventDate: row[4] ?? '',
      eventType: row[5] ?? '',
      eventSubject: row[6] ?? '',
      eventValue: Number.isFinite(rawValue) ? rawValue : 0,
      eventDescription: row[8] ?? '',
    };
  }

  /**
   * Returns the list of unique students derived from all event rows.
   * Logs only the count — never logs names or IDs.
   */
  async getStudents(): Promise<Student[]> {
    const rows = await this.getRows();
    const studentMap = new Map<string, Student>();

    for (const row of rows) {
      if (!studentMap.has(row.studentId)) {
        studentMap.set(row.studentId, {
          studentId: row.studentId,
          studentName: row.studentName,
          classId: row.classId,
        });
      }
    }

    const students = Array.from(studentMap.values());
    this.logger.log(`getStudents: returned ${students.length} records`);
    return students;
  }

  /**
   * Returns all grade events for a given student.
   * Logs only the count — never logs studentId or score values.
   */
  async getGrades(studentId: string): Promise<GradeEvent[]> {
    const rows = (await this.getRows()).filter(
      (row) =>
        row.studentId === studentId &&
        EVENT_TYPE_MAP[row.eventType] === EventType.GRADE,
    );

    const grades = this.mapToGradeEvents(rows);
    this.logger.log(`getGrades: returned ${grades.length} records`);
    return grades;
  }

  /**
   * Returns all grade events across all students.
   * Logs only the count — never logs studentId or score values.
   */
  async getAllGrades(): Promise<GradeEvent[]> {
    const rows = (await this.getRows()).filter(
      (row) => EVENT_TYPE_MAP[row.eventType] === EventType.GRADE,
    );

    const grades = this.mapToGradeEvents(rows);
    this.logger.log(`getAllGrades: returned ${grades.length} records`);
    return grades;
  }

  /**
   * Returns all attendance records for a given student.
   * Logs only the count — never logs studentId or absence details.
   */
  async getAttendance(studentId: string): Promise<AttendanceEvent[]> {
    const rows = (await this.getRows()).filter(
      (row) =>
        row.studentId === studentId &&
        EVENT_TYPE_MAP[row.eventType] === EventType.ATTENDANCE,
    );

    const attendance = this.mapToAttendanceEvents(rows);
    this.logger.log(`getAttendance: returned ${attendance.length} records`);
    return attendance;
  }

  /**
   * Returns all attendance records across all students.
   * Logs only the count — never logs studentId or absence details.
   */
  async getAllAttendance(): Promise<AttendanceEvent[]> {
    const rows = (await this.getRows()).filter(
      (row) => EVENT_TYPE_MAP[row.eventType] === EventType.ATTENDANCE,
    );

    const attendance = this.mapToAttendanceEvents(rows);
    this.logger.log(`getAllAttendance: returned ${attendance.length} records`);
    return attendance;
  }

  /**
   * Returns all behavior events for a given student.
   * Logs only the count — never logs studentId or incident details.
   */
  async getBehaviorEvents(studentId: string): Promise<BehaviorEvent[]> {
    const rows = (await this.getRows()).filter(
      (row) =>
        row.studentId === studentId &&
        EVENT_TYPE_MAP[row.eventType] === EventType.BEHAVIOR,
    );

    const events = this.mapToBehaviorEvents(rows);
    this.logger.log(`getBehaviorEvents: returned ${events.length} records`);
    return events;
  }

  /**
   * Returns all behavior events across all students.
   * Logs only the count — never logs studentId or incident details.
   */
  async getAllBehaviorEvents(): Promise<BehaviorEvent[]> {
    const rows = (await this.getRows()).filter(
      (row) => EVENT_TYPE_MAP[row.eventType] === EventType.BEHAVIOR,
    );

    const events = this.mapToBehaviorEvents(rows);
    this.logger.log(`getAllBehaviorEvents: returned ${events.length} records`);
    return events;
  }

  // ── Private mapping helpers ─────────────────────────────────────────────

  /**
   * Parses a DD/MM/YYYY string from the sheet into a JavaScript Date.
   * This is the single location where the raw sheet date format is consumed.
   * Throws a descriptive error if the value is missing or not in DD/MM/YYYY format.
   */
  private parseDate(ddMmYyyy: string): Date {
    const parts = ddMmYyyy.split('/');
    if (parts.length !== 3) {
      throw new Error(
        `Invalid date format in sheet — expected DD/MM/YYYY, got "${ddMmYyyy}"`,
      );
    }
    const day = Number(parts[0]);
    const month = Number(parts[1]);
    const year = Number(parts[2]);
    if (
      !Number.isFinite(day) ||
      !Number.isFinite(month) ||
      !Number.isFinite(year)
    ) {
      throw new Error(
        `Non-numeric date parts in sheet — expected DD/MM/YYYY, got "${ddMmYyyy}"`,
      );
    }
    return new Date(Date.UTC(year, month - 1, day));
  }

  private mapToGradeEvents(rows: SheetRow[]): GradeEvent[] {
    return rows.map((row) => ({
      eventId: row.eventId,
      studentId: row.studentId,
      studentName: row.studentName,
      classId: row.classId,
      eventDate: this.parseDate(row.eventDate),
      eventType: EventType.GRADE,
      eventSubject: row.eventSubject,
      eventValue: row.eventValue,
      eventDescription: row.eventDescription || undefined,
    }));
  }

  private mapToAttendanceEvents(rows: SheetRow[]): AttendanceEvent[] {
    return rows.map((row) => ({
      eventId: row.eventId,
      studentId: row.studentId,
      studentName: row.studentName,
      classId: row.classId,
      eventDate: this.parseDate(row.eventDate),
      eventType: EventType.ATTENDANCE,
      eventSubject: row.eventSubject || undefined,
      eventValue: row.eventValue,
      eventDescription: row.eventDescription || undefined,
    }));
  }

  private mapToBehaviorEvents(rows: SheetRow[]): BehaviorEvent[] {
    return rows.map((row) => ({
      eventId: row.eventId,
      studentId: row.studentId,
      studentName: row.studentName,
      classId: row.classId,
      eventDate: this.parseDate(row.eventDate),
      eventType: EventType.BEHAVIOR,
      eventSubject: row.eventSubject || undefined,
      eventValue: row.eventValue,
      eventDescription: row.eventDescription || undefined,
    }));
  }
}
