import { Logger } from '@nestjs/common';
import { Test, TestingModule } from '@nestjs/testing';
import { EventType } from '../enums/event-type.enum';
import { MOCK_SHEET_ROWS } from './mock-data/mock-sheet-rows';
import { GoogleSheetsService } from './google-sheets.service';

describe('GoogleSheetsService', () => {
  let service: GoogleSheetsService;
  let loggerSpy: jest.SpyInstance;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [GoogleSheetsService],
    }).compile();

    service = module.get<GoogleSheetsService>(GoogleSheetsService);

    // Bypass the real Google Sheets API — all tests run against mock data.
    // This spy must be established before the logger spy so that the
    // getRows() log message ('getRows: loaded N rows') is captured.
    jest
      .spyOn(
        service as unknown as { getRows: () => Promise<unknown> },
        'getRows',
      )
      .mockResolvedValue(MOCK_SHEET_ROWS);

    // Spy on the logger to verify no PII leaks into logs
    loggerSpy = jest
      .spyOn(Logger.prototype, 'log')
      .mockImplementation(() => undefined);
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  // ── Helpers ─────────────────────────────────────────────────────────────

  /** Returns all PII values present in the mock data. */
  const getPiiValues = (): string[] =>
    MOCK_SHEET_ROWS.flatMap((row) => [row.studentId, row.studentName]);

  /** Asserts that none of the logged messages contain any PII value. */
  const assertNoPiiInLogs = (): void => {
    // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
    const loggedMessages = loggerSpy.mock.calls.map((args) => String(args[0]));
    const piiValues = getPiiValues();

    for (const message of loggedMessages) {
      for (const pii of piiValues) {
        expect(message).not.toContain(pii);
      }
    }
  };

  // ── getStudents ──────────────────────────────────────────────────────────

  describe('getStudents', () => {
    it('should return an array of students', async () => {
      const result = await service.getStudents();
      expect(Array.isArray(result)).toBe(true);
    });

    it('should return the correct number of unique students', async () => {
      const uniqueIds = new Set(MOCK_SHEET_ROWS.map((r) => r.studentId));
      const result = await service.getStudents();
      expect(result).toHaveLength(uniqueIds.size);
    });

    it('should return objects with the required Student fields', async () => {
      const result = await service.getStudents();
      for (const student of result) {
        expect(student).toHaveProperty('studentId');
        expect(student).toHaveProperty('studentName');
        expect(student).toHaveProperty('classId');
      }
    });

    it('should not log any PII values', async () => {
      await service.getStudents();
      assertNoPiiInLogs();
    });
  });

  // ── getGrades ────────────────────────────────────────────────────────────

  describe('getGrades', () => {
    const testStudentId = 'S101';

    it('should return an array of grade events', async () => {
      const result = await service.getGrades(testStudentId);
      expect(Array.isArray(result)).toBe(true);
    });

    it('should return only grade events for the requested student', async () => {
      const expectedCount = MOCK_SHEET_ROWS.filter(
        (r) => r.studentId === testStudentId && r.eventType === 'ציון',
      ).length;

      const result = await service.getGrades(testStudentId);
      expect(result).toHaveLength(expectedCount);
    });

    it('should return objects with the required GradeEvent fields', async () => {
      const result = await service.getGrades(testStudentId);
      for (const event of result) {
        expect(event).toHaveProperty('eventId');
        expect(event).toHaveProperty('studentId');
        expect(event).toHaveProperty('studentName');
        expect(event).toHaveProperty('classId');
        expect(event).toHaveProperty('eventDate');
        expect(event).toHaveProperty('eventSubject');
        expect(event).toHaveProperty('eventValue');
        expect(event.eventType).toBe(EventType.GRADE);
      }
    });

    it('should return eventDate as a Date instance', async () => {
      const result = await service.getGrades(testStudentId);
      for (const event of result) {
        expect(event.eventDate).toBeInstanceOf(Date);
      }
    });

    it('should return an empty array for a student with no grades', async () => {
      const result = await service.getGrades('NONEXISTENT');
      expect(result).toHaveLength(0);
    });

    it('should not log any PII values', async () => {
      await service.getGrades(testStudentId);
      assertNoPiiInLogs();
    });
  });

  // ── getAllGrades ─────────────────────────────────────────────────────────

  describe('getAllGrades', () => {
    it('should return all grade events across all students', async () => {
      const expectedCount = MOCK_SHEET_ROWS.filter(
        (r) => r.eventType === 'ציון',
      ).length;

      const result = await service.getAllGrades();
      expect(result).toHaveLength(expectedCount);
    });

    it('should set eventType to GRADE on every record', async () => {
      const result = await service.getAllGrades();
      for (const event of result) {
        expect(event.eventType).toBe(EventType.GRADE);
      }
    });

    it('should not log any PII values', async () => {
      await service.getAllGrades();
      assertNoPiiInLogs();
    });
  });

  // ── getAttendance ────────────────────────────────────────────────────────

  describe('getAttendance', () => {
    const testStudentId = 'S105';

    it('should return an array of attendance events', async () => {
      const result = await service.getAttendance(testStudentId);
      expect(Array.isArray(result)).toBe(true);
    });

    it('should return only attendance events for the requested student', async () => {
      const expectedCount = MOCK_SHEET_ROWS.filter(
        (r) => r.studentId === testStudentId && r.eventType === 'נוכחות',
      ).length;

      const result = await service.getAttendance(testStudentId);
      expect(result).toHaveLength(expectedCount);
    });

    it('should return objects with the required AttendanceEvent fields', async () => {
      const result = await service.getAttendance(testStudentId);
      for (const event of result) {
        expect(event).toHaveProperty('eventId');
        expect(event).toHaveProperty('studentId');
        expect(event).toHaveProperty('studentName');
        expect(event).toHaveProperty('classId');
        expect(event).toHaveProperty('eventDate');
        expect(event).toHaveProperty('eventValue');
        expect(event.eventType).toBe(EventType.ATTENDANCE);
      }
    });

    it('should preserve eventValue as a number', async () => {
      const result = await service.getAttendance(testStudentId);
      for (const event of result) {
        expect(typeof event.eventValue).toBe('number');
      }
    });

    it('should contain at least one absence record (eventValue === 1)', async () => {
      const result = await service.getAttendance(testStudentId);
      const absentCount = result.filter((e) => e.eventValue === 1).length;
      expect(absentCount).toBeGreaterThan(0);
    });

    it('should return eventDate as a Date instance', async () => {
      const result = await service.getAttendance(testStudentId);
      for (const event of result) {
        expect(event.eventDate).toBeInstanceOf(Date);
      }
    });

    it('should return an empty array for a student with no attendance records', async () => {
      const result = await service.getAttendance('NONEXISTENT');
      expect(result).toHaveLength(0);
    });

    it('should not log any PII values', async () => {
      await service.getAttendance(testStudentId);
      assertNoPiiInLogs();
    });
  });

  // ── getAllAttendance ──────────────────────────────────────────────────────

  describe('getAllAttendance', () => {
    it('should return all attendance events across all students', async () => {
      const expectedCount = MOCK_SHEET_ROWS.filter(
        (r) => r.eventType === 'נוכחות',
      ).length;

      const result = await service.getAllAttendance();
      expect(result).toHaveLength(expectedCount);
    });

    it('should set eventType to ATTENDANCE on every record', async () => {
      const result = await service.getAllAttendance();
      for (const event of result) {
        expect(event.eventType).toBe(EventType.ATTENDANCE);
      }
    });

    it('should not log any PII values', async () => {
      await service.getAllAttendance();
      assertNoPiiInLogs();
    });
  });

  // ── getBehaviorEvents ────────────────────────────────────────────────────

  describe('getBehaviorEvents', () => {
    const testStudentId = 'S102';

    it('should return an array of behavior events', async () => {
      const result = await service.getBehaviorEvents(testStudentId);
      expect(Array.isArray(result)).toBe(true);
    });

    it('should return only behavior events for the requested student', async () => {
      const expectedCount = MOCK_SHEET_ROWS.filter(
        (r) => r.studentId === testStudentId && r.eventType === 'התנהגות',
      ).length;

      const result = await service.getBehaviorEvents(testStudentId);
      expect(result).toHaveLength(expectedCount);
    });

    it('should return objects with the required BehaviorEvent fields', async () => {
      const result = await service.getBehaviorEvents(testStudentId);
      for (const event of result) {
        expect(event).toHaveProperty('eventId');
        expect(event).toHaveProperty('studentId');
        expect(event).toHaveProperty('studentName');
        expect(event).toHaveProperty('classId');
        expect(event).toHaveProperty('eventDate');
        expect(event).toHaveProperty('eventValue');
        expect(event.eventType).toBe(EventType.BEHAVIOR);
      }
    });

    it('should preserve eventValue as a number', async () => {
      const result = await service.getBehaviorEvents(testStudentId);
      for (const event of result) {
        expect(typeof event.eventValue).toBe('number');
      }
    });

    it('should contain at least one negative incident (eventValue === 1)', async () => {
      const result = await service.getBehaviorEvents(testStudentId);
      const negativeCount = result.filter((e) => e.eventValue === 1).length;
      expect(negativeCount).toBeGreaterThan(0);
    });

    it('should return eventDate as a Date instance', async () => {
      const result = await service.getBehaviorEvents(testStudentId);
      for (const event of result) {
        expect(event.eventDate).toBeInstanceOf(Date);
      }
    });

    it('should return an empty array for a student with no behavior events', async () => {
      const result = await service.getBehaviorEvents('NONEXISTENT');
      expect(result).toHaveLength(0);
    });

    it('should not log any PII values', async () => {
      await service.getBehaviorEvents(testStudentId);
      assertNoPiiInLogs();
    });
  });

  // ── getAllBehaviorEvents ──────────────────────────────────────────────────

  describe('getAllBehaviorEvents', () => {
    it('should return all behavior events across all students', async () => {
      const expectedCount = MOCK_SHEET_ROWS.filter(
        (r) => r.eventType === 'התנהגות',
      ).length;

      const result = await service.getAllBehaviorEvents();
      expect(result).toHaveLength(expectedCount);
    });

    it('should set eventType to BEHAVIOR on every record', async () => {
      const result = await service.getAllBehaviorEvents();
      for (const event of result) {
        expect(event.eventType).toBe(EventType.BEHAVIOR);
      }
    });

    it('should not log any PII values', async () => {
      await service.getAllBehaviorEvents();
      assertNoPiiInLogs();
    });
  });

  // ── validateHeaders ──────────────────────────────────────────────────────

  describe('validateHeaders', () => {
    /** Calls the private validateHeaders method directly via type casting. */
    const callValidateHeaders = (
      svc: GoogleSheetsService,
      headers: string[],
    ): void => {
      (
        svc as unknown as { validateHeaders: (h: string[]) => void }
      ).validateHeaders(headers);
    };

    const VALID_HEADERS = [
      'EventID',
      'StudentID',
      'StudentName',
      'ClassID',
      'EventDate',
      'EventType',
      'EventSubject',
      'EventValue',
      'EventDescription',
    ];

    it('should not throw when all columns are present in the correct order', () => {
      expect(() => callValidateHeaders(service, VALID_HEADERS)).not.toThrow();
    });

    it('should throw when a required column is missing', () => {
      const headersWithMissingColumn = VALID_HEADERS.slice(0, -1); // drop last column
      expect(() =>
        callValidateHeaders(service, headersWithMissingColumn),
      ).toThrow(/EventDescription/);
    });

    it('should throw when a column name is misspelled', () => {
      const misspelled = [...VALID_HEADERS];
      misspelled[0] = 'Event_ID'; // wrong casing / underscore
      expect(() => callValidateHeaders(service, misspelled)).toThrow(
        /עמודה 1/,
      );
    });

    it('should throw when columns are in the wrong order', () => {
      const swapped = [...VALID_HEADERS];
      [swapped[0], swapped[1]] = [swapped[1], swapped[0]]; // swap EventID ↔ StudentID
      expect(() => callValidateHeaders(service, swapped)).toThrow(/עמודה 1/);
    });

    it('should include both the expected and actual column name in the error message', () => {
      const wrong = [...VALID_HEADERS];
      wrong[2] = 'Name'; // StudentName → Name
      expect(() => callValidateHeaders(service, wrong)).toThrow(
        /צפוי: "StudentName".*התקבל: "Name"/,
      );
    });

    it('should not log any column values — only the count', () => {
      callValidateHeaders(service, VALID_HEADERS);
      const loggedMessages = loggerSpy.mock.calls.map((args) =>
        // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
        String(args[0]),
      );
      for (const msg of loggedMessages) {
        for (const col of VALID_HEADERS) {
          expect(msg).not.toContain(col);
        }
      }
    });
  });

  // ── parseDate ─────────────────────────────────────────────────────────────

  describe('parseDate', () => {
    /** Calls the private parseDate method directly via type casting. */
    const callParseDate = (svc: GoogleSheetsService, value: string): Date =>
      (svc as unknown as { parseDate: (v: string) => Date }).parseDate(value);

    it('should parse a valid DD/MM/YYYY string into a Date', () => {
      const result = callParseDate(service, '15/09/2025');
      expect(result).toBeInstanceOf(Date);
      expect(result.getFullYear()).toBe(2025);
      expect(result.getMonth()).toBe(8); // 0-indexed
      expect(result.getDate()).toBe(15);
    });

    it('should throw when the value is an empty string', () => {
      expect(() => callParseDate(service, '')).toThrow(/DD\/MM\/YYYY/);
    });

    it('should throw when the value has too few parts', () => {
      expect(() => callParseDate(service, '15/09')).toThrow(/DD\/MM\/YYYY/);
    });

    it('should throw when the value contains non-numeric parts', () => {
      expect(() => callParseDate(service, 'aa/bb/cccc')).toThrow(
        /DD\/MM\/YYYY/,
      );
    });

    it('should throw when the format is YYYY-MM-DD instead of DD/MM/YYYY', () => {
      expect(() => callParseDate(service, '2025-09-15')).toThrow(
        /DD\/MM\/YYYY/,
      );
    });
  });

  // ── Data scenarios ────────────────────────────────────────────────────────
  //
  // Three explicit scenarios that verify the full getRows() → public method
  // pipeline under different sheet conditions:
  //   A. Normal data   — all columns present, data is fully typed
  //   B. Bad column    — renamed/missing column throws with the exact name
  //   C. Empty sheet   — no data rows → all methods return [] without throwing

  describe('data scenarios', () => {
    /** Re-usable helper to call the private validateHeaders method. */
    const callValidateHeaders = (
      svc: GoogleSheetsService,
      headers: string[],
    ): void => {
      (
        svc as unknown as { validateHeaders: (h: string[]) => void }
      ).validateHeaders(headers);
    };

    const VALID_HEADERS = [
      'EventID',
      'StudentID',
      'StudentName',
      'ClassID',
      'EventDate',
      'EventType',
      'EventSubject',
      'EventValue',
      'EventDescription',
    ];

    // ── Scenario A: normal data ─────────────────────────────────────────────
    // The outer beforeEach already mocks getRows() with MOCK_SHEET_ROWS, so
    // these tests run against the full, well-formed dataset.

    describe('Scenario A: normal data — all columns valid', () => {
      it('should return typed GradeEvent objects with Date instances and correct eventType', async () => {
        const expectedCount = MOCK_SHEET_ROWS.filter(
          (r) => r.eventType === 'ציון',
        ).length;
        const grades = await service.getAllGrades();

        expect(grades).toHaveLength(expectedCount);
        for (const g of grades) {
          expect(g.eventDate).toBeInstanceOf(Date);
          expect(g.eventType).toBe(EventType.GRADE);
          expect(typeof g.eventValue).toBe('number');
          expect(g.classId).toBeTruthy();
        }
      });

      it('should return typed AttendanceEvent objects with numeric eventValue', async () => {
        const expectedCount = MOCK_SHEET_ROWS.filter(
          (r) => r.eventType === 'נוכחות',
        ).length;
        const attendance = await service.getAllAttendance();

        expect(attendance).toHaveLength(expectedCount);
        for (const a of attendance) {
          expect(a.eventDate).toBeInstanceOf(Date);
          expect(a.eventType).toBe(EventType.ATTENDANCE);
          expect(typeof a.eventValue).toBe('number');
        }
      });

      it('should return typed BehaviorEvent objects with correct structure', async () => {
        const expectedCount = MOCK_SHEET_ROWS.filter(
          (r) => r.eventType === 'התנהגות',
        ).length;
        const events = await service.getAllBehaviorEvents();

        expect(events).toHaveLength(expectedCount);
        for (const b of events) {
          expect(b.eventDate).toBeInstanceOf(Date);
          expect(b.eventType).toBe(EventType.BEHAVIOR);
          expect(b.classId).toBeTruthy();
        }
      });

      it('should return unique Student records derived from all event rows', async () => {
        const expectedCount = new Set(MOCK_SHEET_ROWS.map((r) => r.studentId))
          .size;
        const students = await service.getStudents();

        expect(students).toHaveLength(expectedCount);
        for (const s of students) {
          expect(s).toHaveProperty('studentId');
          expect(s).toHaveProperty('studentName');
          expect(s).toHaveProperty('classId');
        }
      });
    });

    // ── Scenario B: missing or renamed column ───────────────────────────────
    // validateHeaders() is called inside getRows() on the real header row.
    // Tests call it directly to verify the error message content precisely.

    describe('Scenario B: missing or renamed column — throws with exact column name', () => {
      it('should throw an error containing the expected column name when EventDate is renamed', () => {
        const badHeaders = [...VALID_HEADERS];
        badHeaders[4] = 'Date'; // EventDate → Date
        expect(() => callValidateHeaders(service, badHeaders)).toThrow(
          /EventDate/,
        );
      });

      it('should throw an error containing both the expected and actual column names', () => {
        const badHeaders = [...VALID_HEADERS];
        badHeaders[1] = 'student_id'; // StudentID → student_id
        expect(() => callValidateHeaders(service, badHeaders)).toThrow(
          /צפוי: "StudentID".*התקבל: "student_id"/,
        );
      });

      it('should throw mentioning the first missing column when the header row is too short', () => {
        const shortHeaders = VALID_HEADERS.slice(0, 6); // drops EventSubject, EventValue, EventDescription
        expect(() => callValidateHeaders(service, shortHeaders)).toThrow(
          /EventSubject/,
        );
      });

      it('should indicate the column is missing when the column is absent', () => {
        const shortHeaders = VALID_HEADERS.slice(0, 8); // drops EventDescription only
        expect(() => callValidateHeaders(service, shortHeaders)).toThrow(
          /EventDescription/,
        );
        expect(() => callValidateHeaders(service, shortHeaders)).toThrow(
          /חסרה/,
        );
      });
    });

    // ── Scenario C: empty sheet ─────────────────────────────────────────────
    // getRows() returns [] when the sheet has only a header row or no rows at
    // all (values.length < 2). All public methods must return [] silently.

    describe('Scenario C: empty sheet — all methods return [] without throwing', () => {
      beforeEach(() => {
        // Override the outer beforeEach spy for this scenario only.
        jest
          .spyOn(
            service as unknown as { getRows: () => Promise<unknown> },
            'getRows',
          )
          .mockResolvedValue([]);
      });

      it('getAllGrades should resolve to an empty array', async () => {
        await expect(service.getAllGrades()).resolves.toHaveLength(0);
      });

      it('getAllAttendance should resolve to an empty array', async () => {
        await expect(service.getAllAttendance()).resolves.toHaveLength(0);
      });

      it('getAllBehaviorEvents should resolve to an empty array', async () => {
        await expect(service.getAllBehaviorEvents()).resolves.toHaveLength(0);
      });

      it('getStudents should resolve to an empty array', async () => {
        await expect(service.getStudents()).resolves.toHaveLength(0);
      });
    });
  });
});
