/**
 * Represents the three types of student events tracked in the Google Sheet.
 * The sheet stores these as Hebrew strings — the service maps them to this enum.
 *
 * Sheet value → Enum:
 *   'ציון'       → EventType.GRADE
 *   'נוכחות'     → EventType.ATTENDANCE
 *   'התנהגות'    → EventType.BEHAVIOR
 */
export enum EventType {
  GRADE = 'GRADE',
  ATTENDANCE = 'ATTENDANCE',
  BEHAVIOR = 'BEHAVIOR',
}
