import { Module } from '@nestjs/common';
import { GoogleSheetsService } from './services/google-sheets.service';

/**
 * Shared module providing cross-cutting services used by all feature modules.
 *
 * Usage: import CommonModule in any feature module that needs GoogleSheetsService:
 *   @Module({ imports: [CommonModule] })
 *   export class YourFeatureModule {}
 *
 * Each feature module imports CommonModule directly — app.module.ts imports
 * the feature modules, not CommonModule.
 */
@Module({
  providers: [GoogleSheetsService],
  exports: [GoogleSheetsService],
})
export class CommonModule {}
