import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  AiSummaryResponse,
  AvailableClassesResponse,
  CacheStatusResponse,
  ChartDataPoint,
  DashboardQuery,
  KpiResponse,
} from '../interfaces/dashboard.interfaces';

const API_BASE = '/api/dashboard';

@Injectable()
export class DashboardService {
  constructor(private readonly http: HttpClient) {}

  /**
   * Returns aggregated KPI metrics scoped to the given query filters.
   */
  getKpis(query: DashboardQuery = {}): Observable<KpiResponse> {
    return this.http.get<KpiResponse>(`${API_BASE}/kpis`, {
      params: this.buildParams(query),
    });
  }

  /**
   * Returns average grade per subject, scoped to the given query filters.
   */
  getGradesBySubject(query: DashboardQuery = {}): Observable<ChartDataPoint[]> {
    return this.http.get<ChartDataPoint[]>(`${API_BASE}/grades-by-subject`, {
      params: this.buildParams(query),
    });
  }

  /**
   * Returns behavior incident count per ISO week, scoped to the given query filters.
   */
  getBehaviorOverTime(query: DashboardQuery = {}): Observable<ChartDataPoint[]> {
    return this.http.get<ChartDataPoint[]>(`${API_BASE}/behavior-over-time`, {
      params: this.buildParams(query),
    });
  }

  /**
   * Returns the list of available class IDs for the class selector dropdown.
   */
  getAvailableClasses(): Observable<AvailableClassesResponse> {
    return this.http.get<AvailableClassesResponse>(`${API_BASE}/classes`);
  }

  /**
   * Returns an AI-generated Hebrew executive summary for the given query filters.
   * Returns { summary: '' } if the AI is unavailable — caller must handle gracefully.
   */
  getSummary(query: DashboardQuery = {}): Observable<AiSummaryResponse> {
    return this.http.get<AiSummaryResponse>(`${API_BASE}/summary`, {
      params: this.buildParams(query),
    });
  }

  /**
   * Returns the timestamp of the last successful weekly data refresh.
   * Used by the dashboard to display the "Last updated" indicator.
   */
  getCacheStatus(): Observable<CacheStatusResponse> {
    return this.http.get<CacheStatusResponse>(`${API_BASE}/cache-status`);
  }

  /** Builds HttpParams from a query object, skipping undefined fields. */
  private buildParams(query: DashboardQuery): HttpParams {
    let params = new HttpParams();
    if (query.classId) params = params.set('classId', query.classId);
    if (query.from) params = params.set('from', query.from);
    if (query.to) params = params.set('to', query.to);
    return params;
  }
}
