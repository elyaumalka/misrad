/** KPI aggregates returned by GET /api/dashboard/kpis */
export interface KpiResponse {
  totalStudents: number;
  averageGrade: number;
  attendanceRate: number;
  absenceCount: number;
  behaviorIncidentCount: number;
}

/** Single labeled data point used in chart series */
export interface ChartDataPoint {
  label: string;
  value: number;
}

/** Query parameters shared across all dashboard endpoints */
export interface DashboardQuery {
  classId?: string;
  from?: string;
  to?: string;
}

/** Response from GET /api/dashboard/classes */
export interface AvailableClassesResponse {
  classes: string[];
}

/** Response from GET /api/dashboard/summary */
export interface AiSummaryResponse {
  /** AI-generated Hebrew executive summary. Empty string if AI unavailable. */
  summary: string;
  /** "missing_api_key" when OPENAI_API_KEY is not configured on the backend. */
  error?: string;
}

/** Response from GET /api/dashboard/cache-status */
export interface CacheStatusResponse {
  /**
   * ISO 8601 timestamp of the last successful weekly data refresh.
   * Null if the server has not yet completed a Google Sheets read.
   */
  lastRefreshedAt: string | null;
}
