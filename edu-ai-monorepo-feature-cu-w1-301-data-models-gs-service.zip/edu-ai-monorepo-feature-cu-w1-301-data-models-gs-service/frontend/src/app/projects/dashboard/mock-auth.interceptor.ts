// TODO: Remove before staging – Mock Auth only
import { HttpInterceptorFn } from '@angular/common/http'; // TODO: Remove before staging – Mock Auth only
import { isDevMode } from '@angular/core'; // TODO: Remove before staging – Mock Auth only

/** Mock JWT added to every outbound HTTP request in dev mode. */ // TODO: Remove before staging – Mock Auth only
const MOCK_BEARER_TOKEN = 'Bearer mock.jwt.dev-user-001.teacher'; // TODO: Remove before staging – Mock Auth only

/**
 * Functional HTTP interceptor that injects a fake Authorization header
 * in development mode only. Has zero effect in production builds.
 */ // TODO: Remove before staging – Mock Auth only
export const mockAuthInterceptor: HttpInterceptorFn = (req, next) => { // TODO: Remove before staging – Mock Auth only
  if (!isDevMode()) { // TODO: Remove before staging – Mock Auth only
    return next(req); // TODO: Remove before staging – Mock Auth only
  } // TODO: Remove before staging – Mock Auth only

  const authedReq = req.clone({ // TODO: Remove before staging – Mock Auth only
    setHeaders: { Authorization: MOCK_BEARER_TOKEN }, // TODO: Remove before staging – Mock Auth only
  }); // TODO: Remove before staging – Mock Auth only

  return next(authedReq); // TODO: Remove before staging – Mock Auth only
}; // TODO: Remove before staging – Mock Auth only
