import { Component, isDevMode, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { forkJoin, Subscription } from 'rxjs';
import { BaseChartDirective } from 'ng2-charts';
import { ChartData, ChartOptions } from 'chart.js';

import { DashboardService } from './services/dashboard.service';
import { DashboardHeaderComponent } from './dashboard-header/dashboard-header.component';
import { KpiCardComponent } from '../../shared/components/kpi-card/kpi-card.component';
import { MockUser, mockUser } from './mock-user'; // TODO: Remove before staging – Mock Auth only
import {
  AiSummaryResponse,
  AvailableClassesResponse,
  CacheStatusResponse,
  ChartDataPoint,
  DashboardQuery,
  KpiResponse,
} from './interfaces/dashboard.interfaces';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule, BaseChartDirective, KpiCardComponent, DashboardHeaderComponent],
  providers: [DashboardService],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss',
})
export class DashboardComponent implements OnInit, OnDestroy {
  query: DashboardQuery = { classId: '' };
  kpis: KpiResponse | null = null;
  availableClasses: string[] = [];
  isLoading = false;
  errorMessage: string | null = null;
  // null = not yet loaded, '' = AI unavailable (section hidden), 'text' = display
  summary: string | null = null;
  summaryError: string | null = null;
  isSummaryLoading = false;
  /** ISO 8601 string of the last successful data refresh, or null if unavailable. */
  lastRefreshedAt: string | null = null;
  /** True once KPIs have loaded, totalStudents > 0, and at least one chart dataset has data for the current filter. */
  hasData = false;
  private summarySubscription: Subscription | null = null;
  // TODO: Remove before staging – Mock Auth only – replace with this.authService.getCurrentUser()
  readonly currentUser: MockUser | null = isDevMode() ? mockUser : null; // TODO: Remove before staging – Mock Auth only
  /** True when the active user has the admin/principal role. */ // TODO: Remove before staging – Mock Auth only
  readonly isAdmin: boolean = this.currentUser?.role === 'admin'; // TODO: Remove before staging – Mock Auth only

  gradesChartData: ChartData<'bar'> = { labels: [], datasets: [] };
  behaviorChartData: ChartData<'line'> = { labels: [], datasets: [] };

  readonly barChartOptions: ChartOptions<'bar'> = {
    responsive: true,
    plugins: {
      legend: { display: false },
      title: { display: true, text: 'ממוצע ציונים לפי מקצוע' },
    },
    scales: {
      y: { min: 0, max: 100 },
    },
  };

  readonly lineChartOptions: ChartOptions<'line'> = {
    responsive: true,
    plugins: {
      legend: { display: false },
      title: { display: true, text: 'אירועי התנהגות לאורך זמן' },
    },
    scales: {
      y: { beginAtZero: true, ticks: { stepSize: 1 } },
    },
  };

  // Design token: --color-primary-dark (#0d1b2a)
  private readonly CHART_COLOR_PRIMARY_DARK_75 = 'rgba(13, 27, 42, 0.75)';
  private readonly CHART_COLOR_PRIMARY_DARK_100 = 'rgba(13, 27, 42, 1)';
  // Design token: --color-info (#1565c0)
  private readonly CHART_COLOR_INFO_100 = 'rgba(21, 101, 192, 1)';
  private readonly CHART_COLOR_INFO_10 = 'rgba(21, 101, 192, 0.1)';

  constructor(private readonly dashboardService: DashboardService) {}

  ngOnInit(): void {
    // TODO: Remove before staging – Mock Auth only – replace with authService pre-selection when Auth0 is ready
    if (this.currentUser && this.currentUser.role !== 'admin' && this.currentUser.assignedClasses.length > 0) {
      this.query.classId = this.currentUser.assignedClasses[0]; // TODO: Remove before staging – Mock Auth only
    }

    this.dashboardService.getAvailableClasses().subscribe({
      next: (response: AvailableClassesResponse) => {
        const classes = response.classes.filter((c) => c.trim() !== '');
        if (!this.currentUser || this.currentUser.role === 'admin') {
          this.availableClasses = classes;
        } else {
          const assignedSet = new Set(this.currentUser.assignedClasses);
          this.availableClasses = classes.filter((c) => assignedSet.has(c));
        }
      },
      error: () => {
        this.availableClasses = [];
      },
    });

    this.dashboardService.getCacheStatus().subscribe({
      next: ({ lastRefreshedAt }: CacheStatusResponse) => {
        this.lastRefreshedAt = lastRefreshedAt;
      },
      error: () => {
        this.lastRefreshedAt = null;
      },
    });

    this.loadAll();
  }

  /** Called when the user clicks Apply in the filter bar. */
  onApplyFilter(): void {
    if (this.query.from && this.query.to && this.query.from > this.query.to) {
      this.errorMessage = 'טווח התאריכים שנבחר אינו תקין: תאריך ההתחלה חייב להיות לפני תאריך הסיום.';
      return;
    }
    this.loadAll();
  }

  /** Called when the user clicks Clear in the filter bar. */
  onClearFilter(): void {
    this.query = { classId: '' };
    this.loadAll();
  }

  private loadAll(): void {
    this.isLoading = true;
    this.errorMessage = null;
    this.hasData = false;
    this.summary = null;
    this.summaryError = null;
    this.isSummaryLoading = false;
    this.summarySubscription?.unsubscribe();

    forkJoin({
      kpis: this.dashboardService.getKpis(this.query),
      grades: this.dashboardService.getGradesBySubject(this.query),
      behavior: this.dashboardService.getBehaviorOverTime(this.query),
    }).subscribe({
      next: ({ kpis, grades, behavior }) => {
        this.kpis = kpis;
        this.gradesChartData = this.toBarChartData(grades);
        this.behaviorChartData = this.toLineChartData(behavior);
        this.isLoading = false;
        this.hasData = kpis.totalStudents > 0 && (grades.length > 0 || behavior.length > 0);

        if (!this.hasData) {
          // Empty state UI is shown via *ngIf="!isLoading && !hasData".
          // AI summary is not relevant when there is no data.
          return;
        }

        this.loadSummary();
      },
      error: (err: HttpErrorResponse) => {
        const serverMessage = (err.error as { message?: string })?.message;
        this.errorMessage = serverMessage ?? 'שגיאה בטעינת הנתונים. אנא נסה שנית.';
        this.isLoading = false;
      },
    });
  }

  ngOnDestroy(): void {
    this.summarySubscription?.unsubscribe();
  }

  private loadSummary(): void {
    this.summarySubscription?.unsubscribe();
    this.isSummaryLoading = true;
    this.summary = null;
    this.summaryError = null;

    this.summarySubscription = this.dashboardService.getSummary(this.query).subscribe({
      next: ({ summary, error }: AiSummaryResponse) => {
        this.summaryError = error === 'missing_api_key'
          ? 'הסיכום אינו זמין: מפתח OpenAI לא מוגדר.'
          : null;
        this.summary = summary;
        this.isSummaryLoading = false;
      },
      error: () => {
        this.summary = '';
        this.summaryError = 'שגיאה בטעינת הסיכום. אנא נסה שנית.';
        this.isSummaryLoading = false;
      },
    });
  }

  private toBarChartData(points: ChartDataPoint[]): ChartData<'bar'> {
    return {
      labels: points.map((p) => p.label),
      datasets: [
        {
          data: points.map((p) => p.value),
          backgroundColor: this.CHART_COLOR_PRIMARY_DARK_75,
          borderColor: this.CHART_COLOR_PRIMARY_DARK_100,
          borderWidth: 1,
        },
      ],
    };
  }

  private toLineChartData(points: ChartDataPoint[]): ChartData<'line'> {
    return {
      labels: points.map((p) => p.label),
      datasets: [
        {
          data: points.map((p) => p.value),
          borderColor: this.CHART_COLOR_INFO_100,
          backgroundColor: this.CHART_COLOR_INFO_10,
          fill: true,
          tension: 0.3,
          pointRadius: 4,
        },
      ],
    };
  }
}
