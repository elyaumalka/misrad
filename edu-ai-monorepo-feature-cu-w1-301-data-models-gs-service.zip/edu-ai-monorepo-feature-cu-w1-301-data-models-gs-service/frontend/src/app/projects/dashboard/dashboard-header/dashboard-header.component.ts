import { Component, Input, OnChanges } from '@angular/core';
import { CommonModule } from '@angular/common';

const ROLE_LABELS: Record<'teacher' | 'admin', string> = {
  teacher: 'מורה בבית הספר',
  admin: 'מנהל/ת בית הספר',
};

@Component({
  selector: 'app-dashboard-header',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dashboard-header.component.html',
  styleUrl: './dashboard-header.component.scss',
})
export class DashboardHeaderComponent implements OnChanges {
  /** Full display name of the logged-in user. */
  @Input({ required: true }) name!: string;

  /** Role of the logged-in user — determines the subtitle shown under the name. */
  @Input({ required: true }) role!: 'teacher' | 'admin';

  /** First character of the user's name, displayed inside the avatar circle. */
  avatarInitial = '';

  /** Hebrew role label derived from the role input. */
  roleLabel = '';

  ngOnChanges(): void {
    this.avatarInitial = this.name?.charAt(0) ?? '';
    this.roleLabel = ROLE_LABELS[this.role] ?? '';
  }
}
