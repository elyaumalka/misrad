// TODO: Remove before staging – Mock Data only

/** Shape of the mock authenticated user used for dev-only role simulation. */
export interface MockUser {
  readonly userId: string;
  readonly name: string;
  readonly role: 'teacher' | 'admin';
  readonly assignedClasses: readonly string[];
}

/** Teacher responsible for ח-1 and ח-2. */ // TODO: Remove before staging – Mock Data only
const mockTeacher1: MockUser = {
  // TODO: Remove before staging – Mock Data only
  userId: 'dev-user-001', // TODO: Remove before staging – Mock Data only
  name: 'לאה כץ', // TODO: Remove before staging – Mock Data only
  role: 'teacher', // TODO: Remove before staging – Mock Data only
  assignedClasses: ['ח-1', 'ח-2'], // TODO: Remove before staging – Mock Data only
}; // TODO: Remove before staging – Mock Data only

/** Teacher responsible for ח-3 and ח-4. */ // TODO: Remove before staging – Mock Data only
const mockTeacher2: MockUser = {
  // TODO: Remove before staging – Mock Data only
  userId: 'dev-user-002', // TODO: Remove before staging – Mock Data only
  name: 'תמר כהן', // TODO: Remove before staging – Mock Data only
  role: 'teacher', // TODO: Remove before staging – Mock Data only
  assignedClasses: ['ח-3', 'ח-4'], // TODO: Remove before staging – Mock Data only
}; // TODO: Remove before staging – Mock Data only

/** Principal with access to all classes. */ // TODO: Remove before staging – Mock Data only
const mockAdmin: MockUser = {
  // TODO: Remove before staging – Mock Data only
  userId: 'dev-admin-001', // TODO: Remove before staging – Mock Data only
  name: 'מירי כהן', // TODO: Remove before staging – Mock Data only
  role: 'admin', // TODO: Remove before staging – Mock Data only
  assignedClasses: [], // TODO: Remove before staging – Mock Data only
}; // TODO: Remove before staging – Mock Data only

/**
 * The currently active mock user. Switch to test different roles:
 *   mockTeacher1 → sees ח-1 and ח-2 only
 *   mockTeacher2 → sees ח-3 and ח-4 only
 *   mockAdmin    → sees all classes + "כל הכיתות" option
 */ // TODO: Remove before staging – Mock Data only
export const mockUser: MockUser = mockAdmin; // TODO: Remove before staging – Mock Data only
