import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http'; // TODO: Remove before staging – Mock Auth only
import { provideCharts, withDefaultRegisterables } from 'ng2-charts';

import { routes } from './app.routes';
import { mockAuthInterceptor } from './projects/dashboard/mock-auth.interceptor'; // TODO: Remove before staging – Mock Auth only

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes),
    provideHttpClient(withInterceptors([mockAuthInterceptor])), // TODO: Remove before staging – Mock Auth only
    provideCharts(withDefaultRegisterables()),
  ],
};
