-- ============================================================
-- Index Requests — CU-W4-101
-- Submit to project lead for migration execution.
-- Run with CONCURRENTLY to avoid table locks in production.
-- ============================================================

-- Table: processed_data (Google Sheets cached records)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_processed_data_student_id
  ON processed_data (student_id);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_processed_data_class_id
  ON processed_data (class_id);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_processed_data_event_date
  ON processed_data (event_date);

-- Composite index for the most common combined filter (class + date range)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_processed_data_class_date
  ON processed_data (class_id, event_date DESC);
