// 🔒 Managed by project lead — fill values from .env provided by lead
export const environment = {
  production: false,
  apiUrl: 'http://localhost:3000',
  auth0: {
    domain: '',       // AUTH0_DOMAIN from .env
    clientId: '',     // AUTH0_CLIENT_ID from .env
    audience: '',     // AUTH0_AUDIENCE from .env
  },
};
