// 🔒 Production values injected via GCP Secrets Manager — do not edit manually
export const environment = {
  production: true,
  apiUrl: '',
  auth0: {
    domain: '',
    clientId: '',
    audience: '',
  },
};
