import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { User } from '@auth0/auth0-angular';
import { Observable } from 'rxjs';
import { map } from 'rxjs';

import { AuthService } from '../../../core/auth/auth.service';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss',
})
export class HeaderComponent {
  readonly userName$: Observable<string>;

  constructor(private authService: AuthService) {
    this.userName$ = this.authService.user$.pipe(
      map((user: User | null | undefined) => user?.name ?? user?.email ?? '')
    );
  }

  onLogout(): void {
    this.authService.logout();
  }
}
