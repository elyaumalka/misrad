import { Routes } from '@angular/router';
import { authGuard } from './core/auth/auth.guard';

export const routes: Routes = [
  {
    path: 'login',
    loadComponent: () =>
      import('./core/auth/login/login.component').then(m => m.LoginComponent),
  },
  {
    path: '',
    canActivate: [authGuard],
    loadChildren: () => import('./home/home.routes').then(m => m.routes),
  },
  {
    path: 'dashboard',
    canActivate: [authGuard],
    loadChildren: () =>
      import('./projects/dashboard/dashboard.routes').then(m => m.routes),
  },
  {
    path: 'chatbot',
    canActivate: [authGuard],
    loadChildren: () =>
      import('./projects/chatbot/chatbot.routes').then(m => m.routes),
  },
  {
    path: 'report-generator',
    canActivate: [authGuard],
    loadChildren: () =>
      import('./projects/report-generator/report-generator.routes').then(
        m => m.routes
      ),
  },
  {
    path: 'risk-report',
    canActivate: [authGuard],
    loadChildren: () =>
      import('./projects/risk-report/risk-report.routes').then(m => m.routes),
  },
  {
    path: 'student-profile',
    canActivate: [authGuard],
    loadChildren: () =>
      import('./projects/student-profile/student-profile.routes').then(
        m => m.routes
      ),
  },
];
