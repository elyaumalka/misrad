import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService as Auth0Service, User } from '@auth0/auth0-angular';
import { Observable } from 'rxjs';

export type UserRole = 'admin' | 'teacher' | 'counselor' | 'staff';

/** Must match the namespace configured in the Auth0 Action */
const ROLES_CLAIM = 'https://edu-ai.app/roles';

const ROLE_ROUTES: Record<UserRole, string> = {
  admin: '/dashboard',
  teacher: '/dashboard',
  counselor: '/risk-report',
  staff: '/chatbot',
};

@Injectable({ providedIn: 'root' })
export class AuthService {
  readonly isAuthenticated$: Observable<boolean>;
  readonly isLoading$: Observable<boolean>;
  readonly user$: Observable<User | null | undefined>;
  readonly error$: Observable<Error>;

  constructor(private auth0: Auth0Service, private router: Router) {
    this.isAuthenticated$ = this.auth0.isAuthenticated$;
    this.isLoading$ = this.auth0.isLoading$;
    this.user$ = this.auth0.user$;
    this.error$ = this.auth0.error$;
  }

  /** Extracts the primary role from the Auth0 JWT custom claim */
  getRole(user: User): UserRole | null {
    const claims = user as Record<string, unknown>;
    const roles = claims[ROLES_CLAIM] as string[] | undefined;
    if (!roles || roles.length === 0) return null;
    return roles[0] as UserRole;
  }

  /** Navigates the user to the route matching their role */
  redirectByRole(user: User): void {
    const role = this.getRole(user);
    const route = role !== null ? ROLE_ROUTES[role] : '/';
    this.router.navigate([route]);
  }

  /** Initiates Auth0 Universal Login redirect */
  login(): void {
    this.auth0.loginWithRedirect();
  }

  /** Clears JWT session and redirects to login page */
  logout(): void {
    this.auth0.logout({
      logoutParams: { returnTo: window.location.origin + '/login' },
    });
  }
}
