import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { User } from '@auth0/auth0-angular';
import { Observable, Subscription } from 'rxjs';
import { filter, switchMap, take } from 'rxjs';

import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss',
})
export class LoginComponent implements OnInit, OnDestroy {
  readonly isLoading$: Observable<boolean>;
  readonly authError$: Observable<Error>;

  private readonly subscription = new Subscription();

  constructor(private authService: AuthService) {
    this.isLoading$ = this.authService.isLoading$;
    this.authError$ = this.authService.error$;
  }

  ngOnInit(): void {
    // After Auth0 callback, detect authentication and redirect by role
    const redirect$ = this.authService.isLoading$.pipe(
      filter(loading => !loading),
      take(1),
      switchMap(() => this.authService.isAuthenticated$.pipe(take(1))),
      filter(isAuthenticated => isAuthenticated),
      switchMap(() =>
        this.authService.user$.pipe(
          filter((user): user is User => user != null),
          take(1)
        )
      )
    );

    this.subscription.add(
      redirect$.subscribe(user => this.authService.redirectByRole(user))
    );
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  onLogin(): void {
    this.authService.login();
  }
}
