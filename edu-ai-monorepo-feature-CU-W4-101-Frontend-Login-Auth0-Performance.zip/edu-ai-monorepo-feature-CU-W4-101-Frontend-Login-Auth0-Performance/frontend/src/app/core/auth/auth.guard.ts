import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService as Auth0Service } from '@auth0/auth0-angular';
import { filter, map, switchMap, take } from 'rxjs';

/**
 * Protects routes from unauthenticated access.
 * Waits for Auth0 to finish loading before checking auth state.
 * Redirects to /login if not authenticated.
 */
export const authGuard: CanActivateFn = () => {
  const auth0 = inject(Auth0Service);
  const router = inject(Router);

  return auth0.isLoading$.pipe(
    filter(loading => !loading),
    take(1),
    switchMap(() => auth0.isAuthenticated$.pipe(take(1))),
    map(isAuthenticated => {
      if (isAuthenticated) return true;
      router.navigate(['/login']);
      return false;
    })
  );
};
