import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService as Auth0Service } from '@auth0/auth0-angular';
import { catchError, switchMap, throwError } from 'rxjs';

import { environment } from '../../../environments/environment';

/**
 * Attaches a Bearer JWT token to every outgoing API request.
 * Redirects to /login if the token is expired or unavailable.
 */
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const auth0 = inject(Auth0Service);
  const router = inject(Router);

  if (!req.url.startsWith(environment.apiUrl)) {
    return next(req);
  }

  return auth0.getAccessTokenSilently().pipe(
    switchMap(token => {
      const authorizedReq = req.clone({
        setHeaders: { Authorization: `Bearer ${token}` },
      });
      return next(authorizedReq).pipe(
        catchError(error => {
          if (error.status === 401) {
            router.navigate(['/login']);
          }
          return throwError(() => error);
        })
      );
    }),
    catchError(() => {
      router.navigate(['/login']);
      return throwError(() => new Error('Session expired'));
    })
  );
};
