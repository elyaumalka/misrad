import { validate } from 'class-validator';
import { plainToInstance } from 'class-transformer';
import { PaginationDto } from './pagination.dto';

describe('PaginationDto', () => {
  it('should apply default values', () => {
    const dto = new PaginationDto();
    expect(dto.page).toBe(1);
    expect(dto.limit).toBe(20);
  });

  it('should pass validation with valid params', async () => {
    const dto = plainToInstance(PaginationDto, { page: 2, limit: 50 });
    const errors = await validate(dto);
    expect(errors).toHaveLength(0);
  });

  it('should pass validation at max limit of 100', async () => {
    const dto = plainToInstance(PaginationDto, { page: 1, limit: 100 });
    const errors = await validate(dto);
    expect(errors).toHaveLength(0);
  });

  it('should reject limit above 100', async () => {
    const dto = plainToInstance(PaginationDto, { page: 1, limit: 101 });
    const errors = await validate(dto);
    const limitError = errors.find(e => e.property === 'limit');
    expect(limitError).toBeDefined();
  });

  it('should reject page below 1', async () => {
    const dto = plainToInstance(PaginationDto, { page: 0, limit: 20 });
    const errors = await validate(dto);
    const pageError = errors.find(e => e.property === 'page');
    expect(pageError).toBeDefined();
  });

  it('should reject limit below 1', async () => {
    const dto = plainToInstance(PaginationDto, { page: 1, limit: 0 });
    const errors = await validate(dto);
    const limitError = errors.find(e => e.property === 'limit');
    expect(limitError).toBeDefined();
  });

  it('should pass with missing params (uses defaults)', async () => {
    const dto = plainToInstance(PaginationDto, {});
    const errors = await validate(dto);
    expect(errors).toHaveLength(0);
  });
});
