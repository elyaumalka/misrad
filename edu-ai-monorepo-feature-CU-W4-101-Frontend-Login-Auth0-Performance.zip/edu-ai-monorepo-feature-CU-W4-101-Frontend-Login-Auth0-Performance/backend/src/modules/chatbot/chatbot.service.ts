import { Injectable, Logger } from '@nestjs/common';

import { PaginationDto } from '../../common/dto/pagination.dto';
import { PaginatedResponseDto } from '../../common/dto/paginated-response.dto';

@Injectable()
export class ChatbotService {
  private readonly logger = new Logger(ChatbotService.name);

  /**
   * Returns a paginated list of chatbot conversation records.
   * Real data will be sourced from the RAG pipeline.
   */
  findAll(
    pagination: PaginationDto,
  ): PaginatedResponseDto<Record<string, unknown>> {
    this.logger.log(
      `findAll called — page=${pagination.page}, limit=${pagination.limit}`,
    );
    return new PaginatedResponseDto([], 0, pagination.page, pagination.limit);
  }
}
