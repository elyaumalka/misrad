import { Column, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';

/**
 * Stores processed Google Sheets data for fast querying.
 * Indexes on student_id, class_id, and event_date cover the most frequent
 * filter patterns across dashboard and risk-report endpoints.
 *
 * NOTE: Entity registered by project lead in TypeORM config after migration.
 */
@Entity('processed_data')
@Index(['studentId'])
@Index(['classId'])
@Index(['eventDate'])
export class ProcessedDataEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'student_id' })
  studentId: string;

  @Column({ name: 'class_id' })
  classId: string;

  @Column({ type: 'timestamp', name: 'event_date' })
  eventDate: Date;

  @Column({ type: 'jsonb', nullable: true })
  payload: Record<string, unknown> | null;

  @Column({ type: 'timestamp', name: 'synced_at', default: () => 'NOW()' })
  syncedAt: Date;
}
