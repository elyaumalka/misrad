import { Test, TestingModule } from '@nestjs/testing';
import { DashboardController } from './dashboard.controller';
import { DashboardService } from './dashboard.service';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { PaginatedResponseDto } from '../../common/dto/paginated-response.dto';

describe('DashboardController', () => {
  let controller: DashboardController;
  let service: DashboardService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [DashboardController],
      providers: [DashboardService],
    }).compile();

    controller = module.get<DashboardController>(DashboardController);
    service = module.get<DashboardService>(DashboardService);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  it('should return a PaginatedResponseDto', () => {
    const pagination: PaginationDto = { page: 1, limit: 20 };
    const result = controller.findAll(pagination);
    expect(result).toBeInstanceOf(PaginatedResponseDto);
  });

  it('should reflect the requested page and limit in the response', () => {
    const pagination: PaginationDto = { page: 3, limit: 50 };
    const result = controller.findAll(pagination);
    expect(result.page).toBe(3);
    expect(result.limit).toBe(50);
  });

  it('should return an empty data array for stub service', () => {
    const pagination: PaginationDto = { page: 1, limit: 20 };
    const result = controller.findAll(pagination);
    expect(result.data).toEqual([]);
    expect(result.total).toBe(0);
  });

  it('should delegate to service with the correct pagination params', () => {
    const pagination: PaginationDto = { page: 2, limit: 10 };
    const spy = jest.spyOn(service, 'findAll');
    controller.findAll(pagination);
    expect(spy).toHaveBeenCalledWith(pagination);
  });
});
