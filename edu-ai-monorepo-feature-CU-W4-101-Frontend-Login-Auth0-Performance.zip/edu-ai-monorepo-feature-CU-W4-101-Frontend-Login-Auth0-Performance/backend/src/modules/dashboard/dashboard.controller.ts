import { Controller, Get, Query, UsePipes, ValidationPipe } from '@nestjs/common';
import { ApiQuery, ApiTags } from '@nestjs/swagger';

import { DashboardService } from './dashboard.service';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { PaginatedResponseDto } from '../../common/dto/paginated-response.dto';

@ApiTags('dashboard')
@Controller('dashboard')
export class DashboardController {
  constructor(private readonly service: DashboardService) {}

  /**
   * Returns a paginated list of dashboard records.
   * Maximum 100 rows per request.
   */
  @Get()
  @UsePipes(new ValidationPipe({ transform: true }))
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  findAll(
    @Query() pagination: PaginationDto,
  ): PaginatedResponseDto<Record<string, unknown>> {
    return this.service.findAll(pagination);
  }
}
