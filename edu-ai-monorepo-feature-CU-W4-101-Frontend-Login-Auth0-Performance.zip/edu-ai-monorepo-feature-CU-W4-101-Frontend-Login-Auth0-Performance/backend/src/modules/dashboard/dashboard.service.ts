import { Injectable, Logger } from '@nestjs/common';

import { PaginationDto } from '../../common/dto/pagination.dto';
import { PaginatedResponseDto } from '../../common/dto/paginated-response.dto';

@Injectable()
export class DashboardService {
  private readonly logger = new Logger(DashboardService.name);

  /**
   * Returns a paginated list of dashboard records.
   * Real data will be sourced from Google Sheets via the sheets processor.
   */
  findAll(
    pagination: PaginationDto,
  ): PaginatedResponseDto<Record<string, unknown>> {
    this.logger.log(
      `findAll called — page=${pagination.page}, limit=${pagination.limit}`,
    );
    return new PaginatedResponseDto([], 0, pagination.page, pagination.limit);
  }
}
