import { Controller, Get, Query, UsePipes, ValidationPipe } from '@nestjs/common';
import { ApiQuery, ApiTags } from '@nestjs/swagger';

import { RiskReportService } from './risk-report.service';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { PaginatedResponseDto } from '../../common/dto/paginated-response.dto';

@ApiTags('risk-report')
@Controller('risk-report')
export class RiskReportController {
  constructor(private readonly service: RiskReportService) {}

  /**
   * Returns a paginated list of risk report records.
   * Maximum 100 rows per request.
   */
  @Get()
  @UsePipes(new ValidationPipe({ transform: true }))
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  findAll(
    @Query() pagination: PaginationDto,
  ): PaginatedResponseDto<Record<string, unknown>> {
    return this.service.findAll(pagination);
  }
}
