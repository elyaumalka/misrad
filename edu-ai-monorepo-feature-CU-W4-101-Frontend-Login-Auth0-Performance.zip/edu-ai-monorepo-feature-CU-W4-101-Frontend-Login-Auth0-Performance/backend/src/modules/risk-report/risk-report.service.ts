import { Injectable, Logger } from '@nestjs/common';

import { PaginationDto } from '../../common/dto/pagination.dto';
import { PaginatedResponseDto } from '../../common/dto/paginated-response.dto';

@Injectable()
export class RiskReportService {
  private readonly logger = new Logger(RiskReportService.name);

  /**
   * Returns a paginated list of risk report records.
   * Real data will be sourced from the rules-based scoring engine.
   */
  findAll(
    pagination: PaginationDto,
  ): PaginatedResponseDto<Record<string, unknown>> {
    this.logger.log(
      `findAll called — page=${pagination.page}, limit=${pagination.limit}`,
    );
    return new PaginatedResponseDto([], 0, pagination.page, pagination.limit);
  }
}
