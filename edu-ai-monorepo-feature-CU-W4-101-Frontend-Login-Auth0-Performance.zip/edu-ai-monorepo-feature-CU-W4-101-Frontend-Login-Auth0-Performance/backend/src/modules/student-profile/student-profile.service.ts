import { Injectable, Logger } from '@nestjs/common';

import { PaginationDto } from '../../common/dto/pagination.dto';
import { PaginatedResponseDto } from '../../common/dto/paginated-response.dto';

@Injectable()
export class StudentProfileService {
  private readonly logger = new Logger(StudentProfileService.name);

  /**
   * Returns a paginated list of student profiles.
   * Real data will be sourced from the student data aggregation layer.
   */
  findAll(
    pagination: PaginationDto,
  ): PaginatedResponseDto<Record<string, unknown>> {
    this.logger.log(
      `findAll called — page=${pagination.page}, limit=${pagination.limit}`,
    );
    return new PaginatedResponseDto([], 0, pagination.page, pagination.limit);
  }
}
