import { Controller, Get, Query, UsePipes, ValidationPipe } from '@nestjs/common';
import { ApiQuery, ApiTags } from '@nestjs/swagger';

import { StudentProfileService } from './student-profile.service';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { PaginatedResponseDto } from '../../common/dto/paginated-response.dto';

@ApiTags('student-profile')
@Controller('student-profile')
export class StudentProfileController {
  constructor(private readonly service: StudentProfileService) {}

  /**
   * Returns a paginated list of student profiles.
   * Maximum 100 rows per request.
   */
  @Get()
  @UsePipes(new ValidationPipe({ transform: true }))
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  findAll(
    @Query() pagination: PaginationDto,
  ): PaginatedResponseDto<Record<string, unknown>> {
    return this.service.findAll(pagination);
  }
}
