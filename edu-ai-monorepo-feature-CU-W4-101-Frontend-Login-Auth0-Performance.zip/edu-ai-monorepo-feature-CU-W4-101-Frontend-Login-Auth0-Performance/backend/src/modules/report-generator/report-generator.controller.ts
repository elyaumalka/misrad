import { Controller, Get, Query, UsePipes, ValidationPipe } from '@nestjs/common';
import { ApiQuery, ApiTags } from '@nestjs/swagger';

import { ReportGeneratorService } from './report-generator.service';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { PaginatedResponseDto } from '../../common/dto/paginated-response.dto';

@ApiTags('report-generator')
@Controller('report-generator')
export class ReportGeneratorController {
  constructor(private readonly service: ReportGeneratorService) {}

  /**
   * Returns a paginated list of generated reports.
   * Maximum 100 rows per request.
   */
  @Get()
  @UsePipes(new ValidationPipe({ transform: true }))
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  findAll(
    @Query() pagination: PaginationDto,
  ): PaginatedResponseDto<Record<string, unknown>> {
    return this.service.findAll(pagination);
  }
}
